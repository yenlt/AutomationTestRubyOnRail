/*
 File:
    get_process_macro.c
 Copyright:
    Copyright (C) 2004 TOSHIBA CORPORATION. All Rights Reserved.
 Product:
    AnalyzeMe
 Abstract:
    �v���Ώۂɒ�`���������}�N���̖��O�𒊏o����
 Author:
    tong-huixin
 Date:
    2004/08/15
 REVISION HISTORY:
    2004/08/18        tong-huixin      1st Revision�@
*/

/*
    $AnalyzeMe 1.0.0.1$
*/

#include "common.h"
#include "get_process_macro.h"

extern char g_szNVPath[MAX_PATH];
extern char g_szOVPath[MAX_PATH];

ST_ProcMacro **g_pProcMacro = NULL;
ST_ProcMacro **g_pOVProcMacro = NULL;

int g_iProcMacroCount = 0;
int g_iOVProcMacroCount = 0;



/**
*  GetProcMacro
*  �����}�N�����擾����
*  @param  io_pAnzInfo  AnalyzeMe�Ǘ����
*  @return  
*          ANZ_SUCCESS:����I��                                      
*          ANZ_ERROR  :�ُ�I��
*  @author zhang-gh
*/
int GetProcMacro(ST_AnalyzeMe *io_pAnzInfo,int in_iMeasureType)
{
    /* �ϐ��錾 */
    int   the_iLoop1;           /* LOOP�p */
    int   the_iRet;             /* Return�l */
    int  the_iFileNameLen;      /* File���̒��� */
    char the_cCurChar;          /* �J�����gChar */
    char *the_pFileCont;        /* �ʏ�v��File�̓��e */
    char *the_pNV_FileCont;     /* �����v���̐V��File�̓��e */
    char *the_pOV_FileCont;     /* �����v���̋���File�̓��e */
    char the_szFileName[MAX_PATH] = {0};/* �J�����g�J��File�� */
    FILE *the_fp;                     /* �J��File�̃n���h�� */
    ST_ProcMacro **the_pLastProcMacro;/* �OFile�̖������}�N����Node */
    ST_ProcMacro **the_pNV_LastProcMacro;/* �V�őOFile�̖������}�N����Node */
    ST_ProcMacro **the_pOV_LastProcMacro;/* ���őOFile�̖������}�N����Node */
    ST_MeasureFile *the_pFileInfo;    /* �J�����g�v��File��� */

    /* �ϐ������� */
    the_pFileCont = NULL;        /* �ʏ�v��File�̓��e */
    the_pNV_FileCont = NULL;     /* �����v���̐V��File�̓��e */
    the_pOV_FileCont = NULL;     /* �����v���̋���File�̓��e */
    the_fp = NULL;               /* �J��File�̃n���h�� */
    the_pLastProcMacro = NULL;   /* �OFile�̖������}�N����Node */
    the_pNV_LastProcMacro = NULL;/* �V�őOFile�̖������}�N����Node */
    the_pOV_LastProcMacro = NULL;/* ���őOFile�̖������}�N����Node */
    the_pFileInfo = NULL;        /* �J�����g�v��File��� */

    if(in_iMeasureType == ANZ_COMMON_MEASURE){
        /* �J�����g�v��File�����擾���� */
        the_pFileInfo = io_pAnzInfo->m_msfile;
        AnzMalloc(the_pLastProcMacro,ST_ProcMacro**,sizeof(ST_ProcMacro *));
        memset(the_pLastProcMacro,0,sizeof(ST_ProcMacro *));
        /* �S�v���Ώ�File����LOOP */
        for(the_iLoop1 = 0; the_iLoop1 < io_pAnzInfo->m_allFileNum;the_iLoop1++ ){
            /* �v���Ώ�File��Ǎ��� */
            if(the_pFileInfo->m_fileSize == 0){
                /* ���v��File�����擾���A��File���v������ */
                the_pFileInfo = the_pFileInfo->m_next;
                continue;
            }
            the_pFileCont = NULL;
            AnzMalloc(the_pFileCont,char*,the_pFileInfo->m_fileSize + 1);
            if(the_pFileCont == NULL){
                the_iRet = ANZ_ERR_MEMORY_FAILED;
                goto EXIT;
            }
            memset(the_pFileCont,'\0',the_pFileInfo->m_fileSize +1);
            /* �ʏ�v������Ƃ��Athe_pFileInfo->m_fileName��FullPath��File���ł��� */
            /* File���J�� */
            the_fp = fopen(the_pFileInfo->m_fileName,"rb");
            if(the_fp == NULL){
                the_iRet = ANZ_FILEOPEN_FAILED;
                goto EXIT;
            }
            /* File��Ǎ��� */
            fread(the_pFileCont,sizeof(char),
                  the_pFileInfo->m_fileSize,the_fp);
            fclose(the_fp);
            /* �ʏ�v��File�̏����}�N�����擾���� */
            the_iRet = GetCurFileProcMacro(io_pAnzInfo,
                                            the_pFileCont,
                                            ANZ_CM_FILE,
                                            the_pLastProcMacro);
            if(the_iRet == ANZ_ERROR){
                goto EXIT;
            }
            /* �Ǎ���File�̃�������������� */
            if(the_pFileCont != NULL){
                free(the_pFileCont);
                the_pFileCont = NULL;
            }
            /* ���v��File�����擾���A��File���v������ */
            the_pFileInfo = the_pFileInfo->m_next;
        }
    }
    if(in_iMeasureType == ANZ_TREND_MEASURE){
        /* �J�����g�v��File�����擾���� */
        the_pFileInfo = io_pAnzInfo->m_msfile;
        AnzMalloc(the_pNV_LastProcMacro,ST_ProcMacro**,sizeof(ST_ProcMacro *));
        memset(the_pNV_LastProcMacro,0,sizeof(ST_ProcMacro *));
        AnzMalloc(the_pOV_LastProcMacro,ST_ProcMacro**,sizeof(ST_ProcMacro *));
        memset(the_pOV_LastProcMacro,0,sizeof(ST_ProcMacro *));
        /* �S�v���Ώ�File����LOOP */
        for(the_iLoop1 = 0; the_iLoop1 < io_pAnzInfo->m_allFileNum;the_iLoop1++ ){
            /* File�y�A�����݂���ꍇ */
            if(the_pFileInfo->m_state == ANZ_PAIR_NOCHANGE){
                /* �V�Ōv���Ώ�File��Ǎ��� */
                if(the_pFileInfo->m_fileSize == 0){
                    /* ���ł̌v��File�����擾���A���ł�File���v������ */
                    goto OV_PRC;
                }
                the_pNV_FileCont = NULL;
                AnzMalloc(the_pNV_FileCont,char*,the_pFileInfo->m_fileSize + 1);
                if(the_pNV_FileCont == NULL){
                    the_iRet = ANZ_ERR_MEMORY_FAILED;
                    goto EXIT;
                }
                memset(the_pNV_FileCont,'\0',the_pFileInfo->m_fileSize + 1);
                /* FullPath��File������� */
                the_iFileNameLen = strlen(g_szNVPath) 
                                   + strlen(the_pFileInfo->m_fileName);
                if(the_iFileNameLen > MAX_PATH){
                    the_iRet = ANZ_ERROR;
                    goto EXIT;
                }
                /* ������"\"�ł͂Ȃ��ꍇ�Ag_szNVPath�̌��"\"��ǉ����� */
                if(strcmp(g_szNVPath,"") != 0){
                    the_cCurChar = *(g_szNVPath + strlen(g_szNVPath) - 1);
        #ifdef __GNUC__
                    if(the_cCurChar != '/'){
                        strcat(g_szNVPath,"/");
                    }
        #else
                    if(the_cCurChar != '\\'){
                        strcat(g_szNVPath,"\\");
                    }
        #endif
                }
                memset(the_szFileName,'\0',MAX_PATH);
                strcat(the_szFileName,g_szNVPath);
                strcat(the_szFileName,the_pFileInfo->m_fileName);
                /* File���J�� */
                the_fp = fopen(the_szFileName ,"rb");
                if(the_fp == NULL){
                    the_iRet = ANZ_FILEOPEN_FAILED;
                    goto EXIT;
                }
                /* File��Ǎ��� */
                fread(the_pNV_FileCont,sizeof(char),
                      the_pFileInfo->m_fileSize,the_fp);
                fclose(the_fp);
                /* �V�Ōv��File�̏����}�N�����擾���� */
                the_iRet = GetCurFileProcMacro(io_pAnzInfo,
                                                the_pNV_FileCont,
                                                ANZ_NV_FILE,
                                                the_pNV_LastProcMacro);
                if(the_iRet == ANZ_ERROR){
                    goto EXIT;
                }
                /* �Ǎ���File�̃�������������� */
                if(the_pNV_FileCont != NULL){
                    free(the_pNV_FileCont);
                    the_pNV_FileCont = NULL;
                }
    OV_PRC:;
                the_iLoop1++;/* LOOP�pthe_iLoop1��1���v���X����� */
                if(the_pFileInfo->m_ov_FileSize == 0){
                    /* ���v��File�����擾���A��File���v������ */
                    the_pFileInfo = the_pFileInfo->m_next;
                    continue;
                }
                /* ���Ōv���Ώ�File��Ǎ��� */
                the_pOV_FileCont = NULL;
                AnzMalloc(the_pOV_FileCont,char*,the_pFileInfo->m_ov_FileSize + 1);
                if(the_pOV_FileCont == NULL){
                    the_iRet = ANZ_ERR_MEMORY_FAILED;
                    goto EXIT;
                }
                memset(the_pOV_FileCont,'\0',the_pFileInfo->m_ov_FileSize + 1);
                /* FullPath��File������� */
                the_iFileNameLen = strlen(g_szOVPath) + strlen(the_pFileInfo->m_fileName);
                if(the_iFileNameLen > MAX_PATH){
                    the_iRet = ANZ_ERROR;
                    goto EXIT;
                }
                /* ������"\"�ł͂Ȃ��ꍇ�Ag_szNVPath�̌��"\"��ǉ����� */
                if(strcmp(g_szOVPath,"") != 0){
                    the_cCurChar = *(g_szOVPath + strlen(g_szOVPath) - 1);
        #ifdef __GNUC__         
                    if(the_cCurChar != '/'){
                        strcat(g_szOVPath,"/");
                    }
        #else
                    if(the_cCurChar != '\\'){
                        strcat(g_szOVPath,"\\");
                    }
        #endif
                }
                memset(the_szFileName,'\0',MAX_PATH);
                strcat(the_szFileName,g_szOVPath);
                strcat(the_szFileName,the_pFileInfo->m_fileName);
                /* File���J�� */
                the_fp = fopen(the_szFileName ,"rb");
                if(the_fp == NULL){
                    the_iRet = ANZ_FILEOPEN_FAILED;
                    goto EXIT;
                }
                /* File��Ǎ��� */
                fread(the_pOV_FileCont,sizeof(char),
                      the_pFileInfo->m_ov_FileSize,the_fp);
                fclose(the_fp);
                /* ���Ōv��File�̏����}�N�����擾���� */
                the_iRet = GetCurFileProcMacro(io_pAnzInfo,
                                                the_pOV_FileCont,
                                                ANZ_OV_FILE,
                                                the_pOV_LastProcMacro);
                if(the_iRet == ANZ_ERROR){
                    goto EXIT;
                }
                /* �Ǎ���File�̃�������������� */
                if(the_pOV_FileCont != NULL){
                    free(the_pOV_FileCont);
                    the_pOV_FileCont = NULL;
                }
            }
            /* �V�ň��͋��Ōv���Ώ�File�݂̂����݂���ꍇ */
            if(the_pFileInfo->m_state == ANZ_PAIR_NEW || 
                the_pFileInfo->m_state == ANZ_PAIR_DELETE){
                switch(the_pFileInfo->m_state){
                case ANZ_PAIR_NEW:
                    if(the_pFileInfo->m_fileSize == 0){
                        /* ���v��File�����擾���A��File���v������ */
                        the_pFileInfo = the_pFileInfo->m_next;
                        continue;
                    }
                    /* �V�Ōv���Ώ�File��Ǎ��� */
                    the_pNV_FileCont = NULL;
                    AnzMalloc(the_pNV_FileCont,char*,the_pFileInfo->m_fileSize + 1);
                    if(the_pNV_FileCont == NULL){
                        the_iRet = ANZ_ERR_MEMORY_FAILED;
                        goto EXIT;
                    }
                    memset(the_pNV_FileCont,'\0',the_pFileInfo->m_fileSize + 1);
                    /* FullPath��File������� */
                    the_iFileNameLen = strlen(g_szNVPath) + strlen(the_pFileInfo->m_fileName);
                    if(the_iFileNameLen > MAX_PATH){
                        the_iRet = ANZ_ERROR;
                        goto EXIT;
                    }
                    /* ������"\"�ł͂Ȃ��ꍇ�Ag_szNVPath�̌��"\"��ǉ����� */
                    if(strcmp(g_szNVPath,"") != 0){
                        the_cCurChar = *(g_szNVPath + strlen(g_szNVPath) - 1);
        #ifdef __GNUC__
                        if(the_cCurChar != '/'){
                            strcat(g_szNVPath,"/");
                        }
        #else
                        if(the_cCurChar != '\\'){
                            strcat(g_szNVPath,"\\");
                        }
        #endif
                    }
                    memset(the_szFileName,'\0',MAX_PATH);
                    strcat(the_szFileName,g_szNVPath);
                    strcat(the_szFileName,the_pFileInfo->m_fileName);
                    /* File���J�� */
                    the_fp = fopen(the_szFileName ,"rb");
                    if(the_fp == NULL){
                        the_iRet = ANZ_FILEOPEN_FAILED;
                        goto EXIT;
                    }
                    /* File��Ǎ��� */
                    fread(the_pNV_FileCont,sizeof(char),
                          the_pFileInfo->m_fileSize,the_fp);
                    fclose(the_fp);
                    /* �V�Ōv��File�̏����}�N�����擾���� */
                    the_iRet = GetCurFileProcMacro(io_pAnzInfo,
                                                    the_pNV_FileCont,
                                                    ANZ_NV_FILE,
                                                    the_pNV_LastProcMacro);
                    if(the_iRet == ANZ_ERROR){
                        goto EXIT;
                    }
                    /* �Ǎ���File�̃�������������� */
                    if(the_pNV_FileCont != NULL){
                        free(the_pNV_FileCont);
                        the_pNV_FileCont = NULL;
                    }
                    break;
                case ANZ_PAIR_DELETE:
                    /* ���Ōv���Ώ�File��Ǎ��� */
                    if(the_pFileInfo->m_ov_FileSize == 0){
                        /* ���v��File�����擾���A��File���v������ */
                        the_pFileInfo = the_pFileInfo->m_next;
                        continue;
                    }
                    the_pOV_FileCont = NULL;
                    AnzMalloc(the_pOV_FileCont,char*,the_pFileInfo->m_ov_FileSize + 1);
                    if(the_pOV_FileCont == NULL){
                        the_iRet = ANZ_ERR_MEMORY_FAILED;
                        goto EXIT;
                    }
                    memset(the_pOV_FileCont,'\0',
                           the_pFileInfo->m_ov_FileSize + 1);
                    /* FullPath��File������� */
                    the_iFileNameLen = strlen(g_szOVPath)
                                       + strlen(the_pFileInfo->m_fileName);
                    if(the_iFileNameLen > MAX_PATH){
                        the_iRet = ANZ_ERROR;
                        goto EXIT;
                    }
                    /* ������"\"�ł͂Ȃ��ꍇ�Ag_szOVPath�̌��"\"��ǉ����� */
                    if(strcmp(g_szOVPath,"") != 0){
                        the_cCurChar = *(g_szOVPath + strlen(g_szOVPath) - 1);
        #ifdef __GNUC__
                        if(the_cCurChar != '/'){
                            strcat(g_szOVPath,"/");
                        }
        #else
                        if(the_cCurChar != '\\'){
                            strcat(g_szOVPath,"\\");
                        }
        #endif
                    }
                    memset(the_szFileName,'\0',MAX_PATH);
                    strcat(the_szFileName,g_szOVPath);
                    strcat(the_szFileName,the_pFileInfo->m_fileName);
                    /* File���J�� */
                    the_fp = fopen(the_szFileName ,"rb");
                    if(the_fp == NULL){
                        the_iRet = ANZ_FILEOPEN_FAILED;
                        goto EXIT;
                    }
                    /* File��Ǎ��� */
                    fread(the_pOV_FileCont,sizeof(char),
                          the_pFileInfo->m_ov_FileSize,the_fp);
                    fclose(the_fp);
                    /* ���Ōv��File�̏����}�N�����擾���� */
                    the_iRet = GetCurFileProcMacro(io_pAnzInfo,
                                                    the_pOV_FileCont,
                                                    ANZ_OV_FILE,
                                                    the_pOV_LastProcMacro);
                    if(the_iRet == ANZ_ERROR){
                        goto EXIT;
                    }
                    /* �Ǎ���File�̃�������������� */
                    if(the_pOV_FileCont != NULL){
                        free(the_pOV_FileCont);
                        the_pOV_FileCont = NULL;
                    }
                    break;
                default:
                    break;
                }
            }
            /* ���v��File�����擾���A��File���v������ */
            the_pFileInfo = the_pFileInfo->m_next;
        }
    }
    if (io_pAnzInfo->m_procMacro != NULL){
        the_iRet = CreateProcMacroArray(io_pAnzInfo->m_procMacro,
                                        ANZ_CM_FILE);
        if (the_iRet != ANZ_SUCCESS){
            goto EXIT;
        }
    }
    if (io_pAnzInfo->m_ov_procMacro != NULL){
        the_iRet = CreateProcMacroArray(io_pAnzInfo->m_ov_procMacro,
                                        ANZ_OV_FILE);
        if (the_iRet != ANZ_SUCCESS){
            goto EXIT;
        }
    }
EXIT:;
     /* �ʏ�v��File�̓��e�̉�� */
     if(the_pFileCont != NULL){
        free(the_pFileCont);
        the_pFileCont = NULL;
     }
     /* �����v���̐V��File�̓��e�̉�� */
     if(the_pNV_FileCont != NULL){
        free(the_pNV_FileCont);
        the_pNV_FileCont = NULL;
     }
     /* �����v���̋���File�̓��e�̉�� */
     if(the_pOV_FileCont != NULL){
        free(the_pOV_FileCont);
        the_pOV_FileCont = NULL;
     }
     /* �OFile�̖������}�N����Node�̉�� */
     if(the_pLastProcMacro != NULL){
        free(the_pLastProcMacro);
        the_pLastProcMacro = NULL;
     }
     /* �V�őOFile�̖������}�N����Node�̉�� */
     if(the_pNV_LastProcMacro != NULL){
        free(the_pNV_LastProcMacro);
        the_pNV_LastProcMacro = NULL;
     }
     /* ���őOFile�̖������}�N����Node�̉�� */
     if(the_pOV_LastProcMacro != NULL){
        free(the_pOV_LastProcMacro);
        the_pOV_LastProcMacro = NULL;
     }
     
     return the_iRet;
}

/**
*  GetCurFileProcMacro
*  �J�����gFile�̏����}�N�����擾����
*  @param
*          in_anzInfo          AnalyzeMe�Ǘ����
*          in_pFileCont        �J�����g�v��File���
*          in_verFlag          �J�����g�t�@�C���̔� 
*          io_procMacroNode    �OFile�̖������}�N����Node
*  @return
*          ANZ_SUCCESS ����I�� 
*          ANZ_ERROR   �ُ�I��
*  @author tong-huixin
*/
int GetCurFileProcMacro(ST_AnalyzeMe *io_pAnzInfo,
                        char *in_pFileCont,
                        const int in_iVerFlag,
                        ST_ProcMacro **io_procMacroNode)
{
    int  the_iRet = ANZ_SUCCESS;        /*Return�l*/
    int  the_iProcMacroNum = 0;         /*�����}�N����*/
    int  the_iSeriesBlankNum = 0;       /*�A���̋󔒐�*/
    int  the_iComtNum = 0;              /*�R�����g��*/
    int  the_iPrevSeriesBlankNum = 0;   /* �O�A���󔒐� */
    char the_cCurChar;                  /*�J�����g����*/
    char *the_pFileCont = NULL;         /*�J�����gFile�̓��e*/
    char *the_pTempProcMacroStr = NULL; /*�����}�N���̖���Point*/
    bool the_bPreprocFlag = false;      /*�����}�N���̃t���O*/
    bool the_bDefFlag = false;          /*Define�ł���t���O*/
    bool the_bBracketFlag = false;      /*���ʂ̃t���O*/
    bool the_bProcMacroFlag = false;
    char the_szProcMacroStr[MAX_PROC_MACRO_NAME] = {0};/*�����}�N���̖�*/
    ST_ProcMacro *the_pPrevProcMacro = NULL;/*�����}�N�����̑ONode*/
    ST_ProcMacro *the_pCurProcMacro = NULL;/*�����}�N�����̃J�����gNode*/
  
    enum {
        NORMAL,        /*NORMAL��Ԃ�\�� */
        C_COMMENT,     /*"/*"�R�����g��Ԃ�\�� */
        CC_COMMENT,    /* "//"�R�����g��Ԃ�\�� */
    }state = NORMAL;
    
    the_pFileCont = in_pFileCont;
    the_pTempProcMacroStr = the_szProcMacroStr;

    do{
        the_cCurChar = *the_pFileCont++;
        switch(state)
        {
        case NORMAL:
            if (the_cCurChar != ' '  &&
                the_cCurChar != '\t' &&
                the_cCurChar != '/'  &&
                the_cCurChar != '('  &&
                the_bProcMacroFlag == true){
                state = CC_COMMENT;
                break;
            }
            switch(the_cCurChar)
            {
            case '#':
                if (the_bPreprocFlag == true && the_bDefFlag == false){
                    memset(the_szProcMacroStr,0,MAX_PROC_MACRO_NAME);
                    the_pTempProcMacroStr = the_szProcMacroStr;
                    state = CC_COMMENT;
                    break;
                }
                if ((the_pFileCont - (1 + the_iSeriesBlankNum + the_iPrevSeriesBlankNum + the_iComtNum)) == in_pFileCont ||
                    *(the_pFileCont - (2 + the_iSeriesBlankNum + the_iPrevSeriesBlankNum + the_iComtNum)) == '\n'){
                    the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                    the_iSeriesBlankNum = 0;
                    the_iComtNum = 0;
                    the_bPreprocFlag = true;
                    the_bDefFlag = false;
                    the_bProcMacroFlag = false;
                    break;
                }
                /*�J�����g�̓v���v���Z�X�s�ł͂Ȃ�*/
                else {
                    the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                    the_iSeriesBlankNum = 0;
                    the_iComtNum = 0;
                    break;
                }
                break;
            case ' ':
                if (the_bDefFlag == true && strlen(the_szProcMacroStr) > 0){
                    the_bProcMacroFlag = true;
                }
                if (the_bPreprocFlag == true && the_bDefFlag == false
                    && strlen(the_szProcMacroStr) > 0){
                    if (strcmp(the_szProcMacroStr,"define") == 0){
                        the_bDefFlag = true;
                        memset(the_szProcMacroStr,0,MAX_PROC_MACRO_NAME);
                        the_pTempProcMacroStr = the_szProcMacroStr;
                    }
                    else {
                        memset(the_szProcMacroStr,0,MAX_PROC_MACRO_NAME);
                        the_pTempProcMacroStr = the_szProcMacroStr;
                        state = CC_COMMENT;
                    }
                }
                the_iSeriesBlankNum++;
                break;
            case '\t':
                if (the_bDefFlag == true && strlen(the_szProcMacroStr) > 0){
                    the_bProcMacroFlag = true;
                }
                if (the_bPreprocFlag == true && the_bDefFlag == false
                    && strlen(the_szProcMacroStr) > 0){
                    if (strcmp(the_szProcMacroStr,"define") == 0){
                        the_bDefFlag = true;
                        memset(the_szProcMacroStr,0,MAX_PROC_MACRO_NAME);
                        the_pTempProcMacroStr = the_szProcMacroStr;
                    }
                    else {
                        memset(the_szProcMacroStr,0,MAX_PROC_MACRO_NAME);
                        the_pTempProcMacroStr = the_szProcMacroStr;
                        state = CC_COMMENT;
                    }
                }
                the_iSeriesBlankNum++;
                break;
            case '(':
                the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                the_iSeriesBlankNum = 0;
                if (the_bPreprocFlag == true && the_bDefFlag == true
                    && strlen(the_szProcMacroStr) > 0 ){
                    the_bBracketFlag = true;
                    the_bProcMacroFlag = false;
                    AnzMalloc(the_pCurProcMacro,ST_ProcMacro*,sizeof(ST_ProcMacro));
                    if (the_pCurProcMacro == NULL){
                        the_iRet = ANZ_ERR_MEMORY_FAILED;
                        goto ERR;
                    }
                    else {
                        memset(the_pCurProcMacro,'\0',sizeof(ST_ProcMacro));
                        if(in_iVerFlag == ANZ_NV_FILE ||
                            in_iVerFlag == ANZ_CM_FILE){
                            g_iProcMacroCount++;
                            if (io_pAnzInfo->m_procMacro == NULL){
                                io_pAnzInfo->m_procMacro = the_pCurProcMacro;
                                the_pPrevProcMacro = io_pAnzInfo->m_procMacro;
                            }
                            else {
                                the_pPrevProcMacro = *io_procMacroNode;
                                the_pPrevProcMacro->m_next = the_pCurProcMacro;
                                the_pPrevProcMacro = the_pPrevProcMacro->m_next;
                            }
                        }
                        else {
                            g_iOVProcMacroCount++;
                            if (io_pAnzInfo->m_ov_procMacro == NULL){
                                io_pAnzInfo->m_ov_procMacro = the_pCurProcMacro;
                                the_pPrevProcMacro = io_pAnzInfo->m_ov_procMacro;
                            }
                            else {
                                the_pPrevProcMacro = *io_procMacroNode;
                                the_pPrevProcMacro->m_next = the_pCurProcMacro;
                                the_pPrevProcMacro = the_pPrevProcMacro->m_next;
                            }
                        }
                        AnzMalloc(the_pCurProcMacro->m_procName ,char*,strlen(the_szProcMacroStr)+1);
                        memset(the_pCurProcMacro->m_procName,0,strlen(the_szProcMacroStr)+1);
                        strcpy(the_pCurProcMacro->m_procName,the_szProcMacroStr);
                        memset(the_szProcMacroStr,0,MAX_PROC_MACRO_NAME);
                        the_pTempProcMacroStr = the_szProcMacroStr;
                        state = CC_COMMENT;
                        *io_procMacroNode = the_pCurProcMacro;
                        break;
                    }
                }
                if (the_bPreprocFlag == true && the_bDefFlag == false){
                    
                    memset(the_szProcMacroStr,0,MAX_PROC_MACRO_NAME);
                    the_pTempProcMacroStr = the_szProcMacroStr;
                    state = CC_COMMENT;
                }
            case '/':
                the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                the_iSeriesBlankNum = 0;
                switch(*the_pFileCont)
                {
                case '/':
                    state = CC_COMMENT;
                    the_pFileCont++;
                    break;
                case '*':
                    state = C_COMMENT;
                    the_pFileCont++;
                    break;
                default:
                    if (the_bProcMacroFlag == true){
                        state = CC_COMMENT;
                        break;
                    }
                    if (the_bPreprocFlag == true ){
                        *the_pTempProcMacroStr++ = the_cCurChar;
                    }
                    break;

                }
            case '\r':
                the_iSeriesBlankNum++;
                break;
            case '\n':
                the_bPreprocFlag = false;
                the_bDefFlag = false;
                the_bBracketFlag = false;
                the_bProcMacroFlag = false;
                the_iPrevSeriesBlankNum = 0;
                the_iSeriesBlankNum = 0;
                the_iComtNum = 0;
                memset(the_szProcMacroStr,0,MAX_PROC_MACRO_NAME);
                the_pTempProcMacroStr = the_szProcMacroStr;
                break;
            default:
                if (the_bPreprocFlag == true ){
                    *the_pTempProcMacroStr++ = the_cCurChar;
                }
                the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                the_iSeriesBlankNum = 0;
                break;
            }
            break;
        case CC_COMMENT:
            if (the_cCurChar == '\n'){
                state = NORMAL;
                the_bPreprocFlag = false;
                the_bDefFlag = false;
                the_bBracketFlag = false;
                the_bProcMacroFlag = false;
                the_iPrevSeriesBlankNum = 0;
                the_iSeriesBlankNum = 0;
                the_iComtNum = 0;
                memset(the_szProcMacroStr,0,MAX_PROC_MACRO_NAME);
                the_pTempProcMacroStr = the_szProcMacroStr;
            }
            break;
        case C_COMMENT:
            if (the_cCurChar == '*' && *the_pFileCont == '/'){
                state = NORMAL;
                the_pFileCont++;
                the_iComtNum += 2;
                break;
            }
            if (the_cCurChar == '\n'){
                the_bPreprocFlag = false;
                the_bDefFlag = false;
                the_bBracketFlag = false;
                the_bProcMacroFlag = false;
                the_iPrevSeriesBlankNum = 0;
                the_iSeriesBlankNum = 0;
                the_iComtNum = 0;
                memset(the_szProcMacroStr,0,MAX_PROC_MACRO_NAME);
                the_pTempProcMacroStr = the_szProcMacroStr;
                break;
            }
            the_iComtNum++;
            break;
        }
    }while(the_cCurChar != '\0');
ERR:
    return the_iRet;
}


/**
*  CreateProcMacroArray
*  �o�͂���}�N���̃����N���X�g��z��ɓ����āA�����Ƀ\�[�g����
*  @param
*           in_pHead            �����N���X�g�̃w�b�_�|�C���g
*           in_iCount           �����N���X�g�̃m�[�h��
*  @return
*          ture or false
*  @author luo-jirong
*/
int CreateProcMacroArray(ST_ProcMacro * in_pHead,
                         int in_iVerFlag) 
{
    int the_iNum = 0;                   /* �A�J�E���g */
    int in_iCount = 0;
    ST_ProcMacro **the_pArr = NULL;     /* ���L�z�� */
    ST_ProcMacro *the_pNode = NULL;     /* �ꎞ�z�� */

    ASSERT(in_pHead != NULL);

    if(in_iVerFlag == ANZ_NV_FILE ||
        in_iVerFlag == ANZ_CM_FILE){
        in_iCount = g_iProcMacroCount;
    }
    if(in_iVerFlag == ANZ_OV_FILE){
        in_iCount = g_iOVProcMacroCount;    
    }

    AnzMalloc(the_pArr,ST_ProcMacro**,sizeof(ST_ProcMacro*) * (in_iCount+1));
    if(the_pArr == NULL) {
        return ANZ_ERR_MEMORY_FAILED;
    }
    memset(the_pArr,0,sizeof(ST_ProcMacro*) * (in_iCount + 1));
    
    /* �����Ƀm�[�h��z��ɓ��� */
    the_pNode = in_pHead;
    while(the_pNode != NULL) {
        the_pArr[the_iNum] = the_pNode;
        the_pNode = the_pNode->m_next;
        the_iNum++;
    }
    ASSERT(the_iNum == in_iCount);

    /* �����\�[�g */
    qsort((void *)the_pArr,the_iNum,
        sizeof(ST_ProcMacro *),CompareProcMacroNode);

    if(in_iVerFlag == ANZ_NV_FILE ||
        in_iVerFlag == ANZ_CM_FILE){
        g_pProcMacro = the_pArr;
    }
    if(in_iVerFlag == ANZ_OV_FILE){
        g_pOVProcMacro = the_pArr;  
    }
    return ANZ_SUCCESS;
}

/**
*  CompareProcMacroNode
*  qsort�p��r�֐� 
*  @param
*          in_pNode1        node1
*          in_pNode2        node2
*  @return
*          stricmp�̔�r����
*  @author luo-jirong
*/
static int CompareProcMacroNode( const void *in_pNode1, const void *in_pNode2) 
{ 
    ASSERT(in_pNode1 != NULL && in_pNode2 != NULL);
    return strcmp((*(ST_ProcMacro **)in_pNode1)->m_procName,
                    (*(ST_ProcMacro **)in_pNode2)->m_procName);
} 


/**
*  IsFoundInProcMacro
*  in_pKey���|�C���g���镶���񂪃}�N�����������N���X�g�ɑ��݂��邩�ǂ�������������B
*  @param
*           in_pArrNode     �}�N�����z��
*           in_pKey         �������镶����
*           in_iCount       �z��Ƀm�[�h�̌�
*  @return
*          ture or false
*  @author luo-jirong
*/
bool IsFoundInProcMacro(ST_ProcMacro **in_pArrNode,const char *in_pKey,int in_iCount)
{
    ST_ProcMacro *the_pNode = NULL;     /* �J�����g�m�[�h */
    int the_iLeft = 0;                  /* �񕪂Ō������鍶���E */
    int the_iRight = in_iCount - 1;     /* �񕪂Ō�������E���E */
    int the_iMid = 0;                   /* �񕪂Ō������钆�ʒu */
    int the_iRes = 0;                   /* ��r���錋�� */

    while(the_iLeft <= the_iRight) {
        the_iMid = (the_iLeft + the_iRight) / 2;            /* ���ʒu���v�Z���� */
        the_pNode = in_pArrNode[the_iMid];                  
        the_iRes = strcmp(in_pKey,the_pNode->m_procName);   /* ��r���錋�ʂ��擾���� */
        if(the_iRes == 0) {
            return true;
        }
        if(the_iRes < 0) {
            the_iRight = the_iMid - 1;
            continue;
        }
        else {
            the_iLeft = the_iMid + 1;
            continue;
        }
    }
    
    return false;
}
