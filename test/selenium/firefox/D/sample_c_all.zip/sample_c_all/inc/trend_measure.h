/*
 File:
      trend_measure.h
 Copyright:
      Copyright (C) 2004 TOSHIBA CORPORATION. All Rights Reserved.
 Product:
      AnalyzeMe
 Abstract:
      �����v���̊֐����`����
 Author:
      zhang-gh
 Date:
      2004/08/20
 REVISION HISTORY:

*/

/*
    $AnalyzeMe 1.0.0.1$
*/

#ifndef TREND_MEASURE_H
#define TREND_MEASURE_H

#include "analyzeme_type.h"

/****************/
/* �֐��錾     */
/****************/
int TrendMeasure(ST_AnalyzeMe *io_pAnzInfo);
int Trend1Measure(const ST_MeasureFile *in_pFileInfo);
int Trend2Measure(const ST_MeasureFile *in_pFileInfo);

#endif /* end of TREND_MEASURE_H */
