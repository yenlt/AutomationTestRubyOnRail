/*
 File:
      common_measure.h
 Copyright:
      Copyright (C) 2004 TOSHIBA CORPORATION. All Rights Reserved.
 Product:
      AnalyzeMe
 Abstract:
      ���ʌv���̊֐����`����
 Author:
      zhang-gh
 Date:
      2004/08/20
 REVISION HISTORY:

*/

/*
    $AnalyzeMe 1.0.0.1$
*/

#ifndef COMMMON_MEASURE_H
#define COMMMON_MEASURE_H

#include "analyzeme_type.h"

/****************/
/* �֐��錾     */
/****************/
int CommomMeasure(ST_AnalyzeMe *io_pAnzInfo);
#endif  /* end of  COMMMON_MEASURE_H */
