/*
 File:
      preprocess1.h
 Copyright:
      Copyright (C) 2004 TOSHIBA CORPORATION. All Rights Reserved.
 Product:
      AnalyzeMe
 Abstract:
      �O����(1)�̊֐���錾����
 Author:
      tong-huixin
 Date:
      2004/08/20
 REVISION HISTORY:

*/

/*
    $AnalyzeMe 1.0.0.1$
*/

#ifndef GET_PROCESS_MACRO_H
#define GET_PROCESS_MACRO_H

#include "analyzeme_type.h"

int GetCurFileProcMacro(ST_AnalyzeMe *io_pAnzInfo,
						char *in_pFileCont,
						const int in_iVerFlag,
						ST_ProcMacro **io_procMacroNode);

int GetProcMacro(ST_AnalyzeMe *io_pAnzInfo,int in_iMeasureType);

int CreateProcMacroArray(ST_ProcMacro * in_pHead,int in_iVerFlag);
static int CompareProcMacroNode( const void *in_pNode1, const void *in_pNode2) ;
bool IsFoundInProcMacro(ST_ProcMacro **in_pArrNode,const char *in_pKey,int in_iCount);
#endif  /* end for ifndef GET_PROCESS_MACRO_H */
