/*
 File:
      make_file_list.h
 Copyright:
      Copyright (C) 2004 TOSHIBA CORPORATION. All Rights Reserved.
 Product:
      AnalyzeMe
 Abstract:
      �R�}���h���C���ɓ��͂����v���ΏۂŌv���Ώ�File��List�̍쐬���s���B
 Author:
      luo-jirong
 Date:
      2004/08/18
 REVISION HISTORY:
      2004/08/18        luo-jirong      1st Revision
*/

/*
    $AnalyzeMe 1.0.0.1$
*/

#ifndef MAKE_FILE_LIST_H
#define MAKE_FILE_LIST_H

#include "analyzeme_type.h"

static bool CheckPartDir(char *in_pPartDir,char *in_pPattern);
static bool CheckPattern(const char* in_pFileName,const char* in_pCurPath,const char* in_pFilePattern,int in_iType);
static int SearchDirToFileList(const ST_AnalyzeMe *in_pAnzInfo,const char *in_pCurDir,const int in_iVerFlag);
static int CombFileList(ST_MeasureFile *io_trendNVHead,ST_MeasureFile *io_trendOVHead);
static int CompareNode(const void *in_newNode,const void *in_oldNode);
int MakeMeasureFilesList(ST_AnalyzeMe * io_anzInfo,const char ** in_measureItem);
#ifdef __GNUC__
	static int SearchDirToFileList_GCC(const ST_AnalyzeMe *in_pAnzInfo, const char *in_pCurDir,const char* in_pParentDir,const int in_iMeasureType,const int in_iVerFlag);
#else
	static int SearchDirToFileList_WIN(const ST_AnalyzeMe *in_pAnzInfo, const char *in_pCurDir,const char* in_pParentDir,const int in_iMeasureType,const int in_iVerFlag);
#endif

#endif /* end of MAKE_FILE_LIST */
