/*
 File:
      preprocess1.c
 Copyright:
      Copyright (C) 2004 TOSHIBA CORPORATION. All Rights Reserved.
 Product:
      AnalyzeMe
 Abstract:
     �v���O�K�v�ȏ������s��
 Author:
      tong-huixin
 Date:
      2004/08/15
 REVISION HISTORY:

*/

/*
    $AnalyzeMe1.0.0.1$
*/

#include "common.h"
#include "output.h"
#include "preprocess1.h"

ST_Error    *g_pErrLstHead = NULL; /* Error����List��Head Node��Point */
ST_Error    *g_pErrLstPrev = NULL; /* �J�����gError���̑ONode��Point */

extern ST_FileLOC     *g_fileLOC;   /* file_LOC.csv */
extern ST_FileTrend1  *g_fileTrend1;/* file_metrics.csv */
extern char g_szNVPath[MAX_PATH];
extern char g_szOVPath[MAX_PATH];
static int g_iIfNum = 0;   /* #IF�̐� */
char g_iPreprocValue[MAX_IFNUM][MAX_ELIFNUM];
static char g_szArrUndef[MAX_UNDEFNUM][MAX_UNDEFCONT];
static int g_iUndefNum = 0;

/*
* ��`����}�N��ADD_TO_LINEATTR_LIST()�ɂ��Ď�ɃJ�����g�s�v���p�e�B�m�[�h��
* ���������邵�A�J�����g�m�[�h���s�v���p�e�B���X�g�ɃZ�b�g����
*/
#define ADD_TO_LINEATTR_LIST()   \
    AnzMalloc(the_pCurLineAttr,ST_LineAttr*,sizeof(ST_LineAttr)); \
    if (the_pCurLineAttr == NULL){  \
        the_iRet = ANZ_ERR_MEMORY_FAILED;  \
        goto ERR;  \
    }   \
    else{   \
        memset(the_pCurLineAttr,'\0',sizeof(ST_LineAttr));  \
        if (the_pHeadLineAttr == NULL ){   \
            the_pHeadLineAttr = the_pCurLineAttr;  \
            the_pPrevLineAttr = the_pHeadLineAttr;  \
        }   \
        else {  \
            the_pPrevLineAttr->m_next = the_pCurLineAttr;  \
            the_pPrevLineAttr = the_pPrevLineAttr->m_next;  \
            the_pPrevLineAttr->m_next = NULL;  \
        }  \
    }


/*
* ��`����}�N��SET_PREPROCESS_ATTR()�ɂ��Ď�ɃJ�����g�s�Əo�͂���s�̍s�v���p�e�B��
* �Z�b�g����
*/

#define SET_PREPROCESS_ATTR() \
if (the_iIfFlag == 0){ \
    for (the_iLoop = 0;the_iLoop < the_iContPreprocLineNum;the_iLoop++){ \
        the_pPreProcLineAttr->m_attr.PL = 1; \
        if (the_pPreProcLineAttr->m_attr.EL == 1){ \
            the_iExecLOC++; \
        } \
        else if (the_pPreProcLineAttr->m_attr.BL == 1){ \
            the_iBlankLOC++; \
        }  \
        else { \
            the_iComtLOC++;\
        } \
        the_pPreProcLineAttr = the_pPreProcLineAttr->m_next; \
    } \
} \
/* �ȉ��̂悤�ȍs�ł��� \
   ��F#if 0 || # if defined AA */ \
else { \
    for (the_iLoop = 0;the_iLoop < the_iContPreprocLineNum;the_iLoop++){ \
        the_pPreProcLineAttr->m_attr1.IFL = 1; \
        the_pPreProcLineAttr->m_attr.EL = 0; \
        the_pPreProcLineAttr->m_attr.BL = 0; \
        the_pPreProcLineAttr->m_attr.CL = 1; \
        the_iComtLOC++; \
        the_pPreProcLineAttr = the_pPreProcLineAttr->m_next; \
    } \
}

/**
*   GetComplexValue
*  �G�N�X�v���b�V������SUFFIX�G�N�X�v���b�V�����֓]��������
*  @param
*         in_pExprsStr  �]�������G�N�X�v���b�V����
*         io_iValueFlag     �ԋp�l
*  @return
*         �Ȃ�
*  @author tong-huixin
*/
void GetComplexValue(const char *in_pExprsStr,int *io_iValueFlag)
{
    /* �ϐ��錾 */
    char the_cQueue[MAX_STACK_SIZE];    /* heap�̔z�� */
    char the_cStack[MAX_STACK_SIZE];    /* stack�̔z�� */
    int the_iQULoop = 0;    /* heap�̗��Loop�ʁAheap�̖���Point*/
    int the_iSTLoop = -1;   /* stack��Loop�ʁAstack�̐擪��Point*/
    int the_iExpLoop = 0;   /* Expression�pLoop*/
    int the_iLoop4 = 0;
    int the_iCharNum = 0;   /*�J�����g������̕�����*/
    int the_iLeftPos = -1;  /* ���́e�j�f�̈ʒu */
    char the_x = 0;         /* �ꎞ�v�Z�� */
    char the_y = 0;         /* �ꎞ�v�Z�� */
    char the_r = 0;         /* �ꎞ�v�Z�ʂ̌��� */

    /* �ϐ������� */
    the_iCharNum=strlen(in_pExprsStr);
    memset(the_cQueue,0,MAX_STACK_SIZE);
    memset(the_cStack,0,MAX_STACK_SIZE);
    for (the_iExpLoop = 0; the_iExpLoop < the_iCharNum; the_iExpLoop++)
    {
        /* �����ł���ꍇ�AQueue�ɓ��� */
        if (*(in_pExprsStr+the_iExpLoop) == '0'
            || *(in_pExprsStr+the_iExpLoop) == '1'){
            the_cQueue[the_iQULoop++] = *(in_pExprsStr+the_iExpLoop);
            continue;
        }
        /* operator�ł���ꍇ */
        else {
            /* '('�ł���ꍇ */
            if (*(in_pExprsStr+the_iExpLoop) == '('){
                the_cStack[++the_iSTLoop] = *(in_pExprsStr + the_iExpLoop);
                the_iLeftPos = the_iSTLoop;
                continue;
            }
            if (*(in_pExprsStr + the_iExpLoop) == '|'){
                for (the_iLoop4 = the_iSTLoop; the_iLoop4 > the_iLeftPos; the_iLoop4--) {
                    if (the_cStack[the_iLoop4] == '&'
                        || the_cStack[the_iLoop4] == '|'){
                        the_cQueue[the_iQULoop++] = the_cStack[the_iLoop4];
                        the_iSTLoop--;
                    }
                }
                the_cStack[++the_iSTLoop] = *(in_pExprsStr+the_iExpLoop);
                continue;
            }
            if (*(in_pExprsStr + the_iExpLoop) == '&'){
                for (the_iLoop4 = the_iSTLoop; the_iLoop4 > the_iLeftPos;the_iLoop4--)
                {
                    if (the_cStack[the_iLoop4] == '&'){
                        the_cQueue[the_iQULoop++] = the_cStack[the_iLoop4];
                        the_iSTLoop--;
                    }
                }
                the_cStack[++the_iSTLoop] = *(in_pExprsStr+the_iExpLoop);
                continue;
            }
            if (*(in_pExprsStr + the_iExpLoop) == ')'){
                for (the_iLoop4 = the_iSTLoop; the_iLoop4 > the_iLeftPos; the_iLoop4--)
                {
                    the_cQueue[the_iQULoop++] = the_cStack[the_iLoop4];
                    the_iSTLoop--;
                }
                the_iSTLoop--;
                the_iLeftPos = the_iSTLoop;
                continue;
            }
        }
    }
    for (; the_iSTLoop >= 0; the_iSTLoop--)
    {
        the_cQueue[the_iQULoop++] = the_cStack[the_iSTLoop];
    }
    if (the_iQULoop == 1){
        *io_iValueFlag = the_cQueue[0] - '0';
        return;
    }
    memset(the_cStack,0,MAX_STACK_SIZE);

    the_iSTLoop = 0;
    for (the_iExpLoop = 0; the_iExpLoop < the_iQULoop;the_iExpLoop++ )
    {
        /*�����ł���� */
        if(the_cQueue[the_iExpLoop] == '0' || the_cQueue[the_iExpLoop] == '1') {
            the_cStack[the_iSTLoop++] = the_cQueue[the_iExpLoop] - '0';
            continue;
        }
        if(the_cQueue[the_iExpLoop] == '&') {
            the_x = the_cStack[--the_iSTLoop];
            the_y = the_cStack[--the_iSTLoop];
            the_r = the_x & the_y;
            the_cStack[the_iSTLoop++] = the_r;
            continue;
        }
        if(the_cQueue[the_iExpLoop] == '|') {
            the_x = the_cStack[--the_iSTLoop];
            the_y = the_cStack[--the_iSTLoop];
            the_r = the_x | the_y;
            the_cStack[the_iSTLoop++] = the_r;
        }
    }
    /* Stack�̐擪�v�f���擾���� */
    *io_iValueFlag = the_cStack[--the_iSTLoop];
}

/**
*  GetValueFromSymbol
*  �擾�����P�ꂪSymbol�ɑ��݂��邩�ǂ����𔻒f����
*  @param
*         in_pWord    #if�̏�����
*         in_pSymbol  Symbol���
*         in_bDefined Symbol�̒l���擾����K�v���t���O
*         out_pValue  ���f����
*  @return
*          �Ȃ�
*  @author tong-huixin
*/
void  GetValueFromSymbol(char *in_pWord,
						 ST_Symbol *in_pSymbol,
						 bool in_bDefined,
						 int *out_pValue)
{
    ST_Symbol *the_node = NULL;
    int the_iLoop = 0;
    the_node = in_pSymbol;
    *out_pValue = 0;
    if(in_pSymbol == NULL) {
        *out_pValue = 0;
        return;
    }
    while(the_node != NULL) {
        /* �����N���X�g�����݂���ꍇ in_pWord */
        if(strcmp(in_pWord,the_node->m_symName) == 0) {
            /* defined�܂���ifdef�ł͂Ȃ��ꍇ�ɂ�in_pSymbol��out_pValue���擾���� */
            *out_pValue = 1;
            if(in_bDefined == false) {
                if(the_node->m_symValue != NULL) {
                    if(strcmp(the_node->m_symValue,"0") == 0) {
                        *out_pValue = 0;
                    }
                    else {
                        *out_pValue = 1;
                    }
                }
                else {
                    *out_pValue = 0;
                }
            }
            /* Undef����邩���f���� */
            for(the_iLoop = 0;the_iLoop < g_iUndefNum; the_iLoop++) {
                if(strcmp(in_pWord,g_szArrUndef[the_iLoop]) == 0) {
                    *out_pValue = 0;
                    break;
                }
            }
            break;
        } /* end if */
        the_node = the_node->m_next;
    }  /* end while */
}

/**
*  GetWord
*  �P�����擾����
*  @param
*         in_p   ������
*         io_s   ������̈�Ԗ�Word
*  @return
*          �Ȃ�
*  @author tong-huixin
*/
static void GetWord(char *in_p,char *io_s)
{
        while((*(in_p)) != ' ' && (*(in_p)) != '|' && (*(in_p)) != '&'
                && (*(in_p)) != '(' && (*(in_p)) != ')' && (*(in_p)) != '\0' )
        {
            *(io_s)++ = *(in_p)++;
        }
        *(io_s) = '\0';
}

/**
*  GetPreLineStrValue
*  #if�����̔��f���s��
*  @param
*         in_pPreprocLine  #if�̍s���e
*         in_pSymbolList   Symbol���
*         out_pResult      ��������
*  @return
*         ANZ_SUCCESS ����I��
*         ANZ_ERROR   �ُ�I��
*  @author tong-huixin
*/
static int GetPreLineStrValue(char *in_pPreprocLine,
							  ST_Symbol *in_pSymbolList,
							  char *out_pResult)
{
    char *the_pLoop = in_pPreprocLine;
    char the_szTmp[MAX_PRECONT];       /* �ꎞ�p */
    char *the_pTmp = the_szTmp;
    char the_szRes[MAX_PRECONT];       /* ���Ԍ��ʂ�ۑ����� */
    char *the_pRes = the_szRes;
    int  the_iValue = 0;
    bool the_bDefined = false;
    enum {
            ENU_IF,
            ENU_IFDEF,
            ENU_ELIF,
            ENU_IFNDEF,
            ENU_NO
    } the_state = ENU_NO;


    ASSERT(in_pPreprocLine != NULL && out_pResult != NULL);
    if(strlen(in_pPreprocLine) >= MAX_PRECONT) {
        return ANZ_ERROR;
    }

    /*����if ���^�C�@�F#if,#ifdef,#elif,#ifndef */
    memset(the_szTmp,0,MAX_PRECONT);
    strncpy(the_szTmp,the_pLoop,6);
    if(strcmp(the_szTmp,"#ifdef") == 0) {
        the_state = ENU_IFDEF;
        the_pLoop += 6;     /* ����#ifdef�@ */
    }
    else {
        memset(the_szTmp,0,MAX_PRECONT);
        strncpy(the_szTmp,the_pLoop,7);
        if(strcmp(the_szTmp,"#ifndef") == 0) {
            the_state = ENU_IFNDEF;
            the_pLoop += 7;     /* ����#ifndef�@ */
        }
        else {
            memset(the_szTmp,0,MAX_PRECONT);
            strncpy(the_szTmp,the_pLoop,3);
            if(strcmp(the_szTmp,"#if") == 0) {
                the_state = ENU_IF;
                the_pLoop += 3;
            }
            else {
                memset(the_szTmp,0,MAX_PRECONT);
                strncpy(the_szTmp,the_pLoop,5);
                if(strcmp(the_szTmp,"#elif") == 0) {
                    the_state = ENU_ELIF;
                    the_pLoop += 5;
                }
            }
        }
    }

    if(the_state == ENU_NO) {
        return ANZ_SUCCESS2;
    }
    memset(the_szRes,'\0',MAX_PRECONT);
    while(*the_pLoop != '\0') {
        /* �󔒂ł���΁Ajump���� */
        if(*the_pLoop == ' ' || *the_pLoop == '\t') {
            the_pLoop++;
            continue;
        }
        /* �ȉ��ł���΁A�z��ɓ��� */
        if(*the_pLoop == '(' || *the_pLoop == ')' || *the_pLoop == '!' ||
            *the_pLoop == '&' || *the_pLoop == '|' ) {
            *the_pRes++ = *the_pLoop++;
            continue;
        }

        the_pTmp = the_szTmp;
        GetWord(the_pLoop,the_pTmp);
        the_pLoop += strlen(the_pTmp);
        /* defined�ł���΁A�t���O��ݒ肵�A�����擾����*/
        if(strcmp(the_szTmp,"defined") == 0) {
            the_bDefined = true;
            continue;
        }
        if(the_state == ENU_IFDEF || the_state == ENU_IFNDEF) {
            the_bDefined = true;
        }
    /* #if 001 or #if 0x11 */
        if(the_bDefined == false) {
            unsigned int the_iLoop;
            bool the_bOk = true;
            bool the_bTrue = false;
            for(the_iLoop = 0;the_iLoop < strlen(the_pTmp);the_iLoop++) {
                if( (the_pTmp[the_iLoop] < '0') || (the_pTmp[the_iLoop] > '9')) {
                    if(the_iLoop == 1 && the_pTmp[1] == 'x') {
                        continue;
                    }
                    else {
                        the_bOk = false;
                        break;
                    }
                }
                if(the_pTmp[the_iLoop] != '0') {
                    the_bTrue = true;
                }
            }
            if(the_bOk) {
                if(the_bTrue) {
                    *the_pRes++ = '1';
                }
                else {
                    *the_pRes++ = '0';
                }
                continue;
            }
        }

        /* �擾����Word��Symbol���ɑ��݂��邩�A���݂ł���΁A�z��the_iValue[0,1]�ɓ��� */
        if(in_pSymbolList != NULL) {
            GetValueFromSymbol(the_szTmp,in_pSymbolList,the_bDefined,&the_iValue);
        }
        else {
            the_iValue = 0;
        }
        *the_pRes++ = '0' + the_iValue;
        /*�@Loop�I������Ƃ��Athe_bDefined�̃t���O��ݒ肷�� */
        the_bDefined = false;
    }
    *the_pRes = '\0';

    /*�o��?���f�� */
    strcpy(the_szTmp,the_szRes);
    the_pTmp = the_szTmp;
    the_pRes = the_szRes;
    memset(the_szRes,'\0',MAX_PATH);
    for(;*the_pTmp != '\0';the_pTmp++) {
        if(*(the_pTmp + 2) != '\0') {
            if(*the_pTmp == '(' && (*(the_pTmp + 1) == '0' || *(the_pTmp + 1) == '1')
                && *(the_pTmp + 2) == ')')  {
                *the_pRes++ = *(the_pTmp + 1);
                the_pTmp += 2;
                continue;
            }
        }
        /*���'&'�܂���'|'����ɕύX����*/
        if(*(the_pTmp + 1) != '\0') {
            if((*the_pTmp == '&' && *(the_pTmp + 1) == '&')
                || (*the_pTmp == '|' && *(the_pTmp + 1) == '|')) {
                *the_pRes++ = *the_pTmp;
                the_pTmp ++;
                continue;
            }
        }
        *the_pRes++ = *the_pTmp;
    }

    /*'!'���t�Ɏ擾����*/
    strcpy(the_szTmp,the_szRes);
    the_pTmp = the_szTmp;
    the_pRes = the_szRes;
    memset(the_szRes,'\0',MAX_PATH);
    for(;*the_pTmp != '\0';the_pTmp++) {
        if(*(the_pTmp + 1) != '\0') {
            if(*the_pTmp == '!' && *(the_pTmp + 1) == '0') {
                *the_pRes++ = '1';
                the_pTmp++;
                continue;
            }
            if(*the_pTmp == '!' && *(the_pTmp + 1) == '1') {
                *the_pRes++ = '0';
                the_pTmp++;
                continue;
            }
        }
        *the_pRes++ = *the_pTmp;
    }
    strcpy(out_pResult,the_szRes);

return ANZ_SUCCESS;

}

/**
*  CheckPreproc
*  #if�����̔��f���s��
*  @param
*         in_anzInfo      AnalyzeMe�Ǘ����
*         in_pPreprocLine �v���v���Z�X�s���e
*         io_iIfFlag�@    #IF���̃t���O
*                           ANZ_NO_IF   :#if���ł͂Ȃ�
*                           ANZ_IF_TRUE :#if���̔��f���ʂ�True�ł���
*                           ANZ_IF_FALSE:#if���̔��f���ʂ�False�ł���
*         io_ifErrLine    #IF�����Ȃ��s�ԍ�
*         io_iErrFlag  �J�����g�v��File�ɃG���[�����邩�ǂ����̃t���O
  *  @return
        ANZ_SUCCESS ����I��
        ANZ_ERROR   �ُ�I��
*  @author tong-huixin
*/
int CheckPreproc(ST_AnalyzeMe *io_pAnzInfo,
				 char *in_pPreprocLine,
                 int *io_iIfFlag,
				 int *io_ifErrLine)
{
    /* �ϐ��錾 */
    int the_iRet = ANZ_SUCCESS;     /* Return�l */
    int the_iKeyNum= 0;             /* �L�[���[�h�̃C�f�b�N�X*/
    int the_iValueFlag = 0;         /* Expression�̖��̃t���O*/
    int the_iCharNum = 0;           /* ������̕�����*/
    int the_iLoop1 = 0;             /* LOOP�p */
    int the_iLoop2 = 0;             /* LOOP�p */
    int the_iLoop3 = 0;             /* LOOP�p */
    char the_cTempValueStr[MAX_PREPROC_VALUE];  /*�������Expression*/
    char the_cTempStr[MAX_PREPROC_VALUE];           /*Expression�ɏ����ȊO�̕���*/
    bool the_bValueFlag = false;    /*�������x��������\������t���O*/
    char the_cKey[9][8] = {"ifdef","ifndef","if","else",/*�v���v���Z�X�̃L�[���[�h*/
        "define","elif", "endif","undef","include"};
    /* �ϐ������� */
    the_iCharNum = strlen(in_pPreprocLine);
    memset(the_cTempStr,0,MAX_PREPROC_VALUE);
    memset(the_cTempValueStr,0,MAX_PREPROC_VALUE);

    for(the_iLoop1 = 1; the_iLoop1 < the_iCharNum; the_iLoop1++){
        if ( *( in_pPreprocLine + the_iLoop1) != ' '  &&
            *( in_pPreprocLine + the_iLoop1 ) != '\t' &&
			*( in_pPreprocLine + the_iLoop1 ) != ';' &&
            *( in_pPreprocLine + the_iLoop1 ) != '\0'){
            the_cTempStr[the_iLoop2++] = *( in_pPreprocLine + the_iLoop1);
        }
        else {
            if (strlen(the_cTempStr) > 0 ){
                break;
            }

        }
    }

    /* ����#�ȍ~�̃L�[���[�h�𔻒f���� */
    for ( ; the_iKeyNum<9; the_iKeyNum++ ){
        if ( strcmp(the_cTempStr,the_cKey[the_iKeyNum]) == 0 ){
            memset(the_cTempStr,0,MAX_PREPROC_VALUE);
            break;
        }
    }
    switch ( the_iKeyNum){
        /* �J�����g�L�[���[�h��ifdef�ł��� */
    case 0:
        g_iIfNum++;
		if (g_iIfNum > MAX_IFNUM ){
			the_iRet = ANZ_UNKNOWN_ERROR;
			goto EXIT;
		}
        if (g_iIfNum > 1 &&
            g_iPreprocValue[g_iIfNum - 2][strlen(g_iPreprocValue[g_iIfNum - 2]) -1] == 2){
            *io_iIfFlag = 2;
            g_iPreprocValue[g_iIfNum - 1][0] = *io_iIfFlag;
            goto EXIT;
        }
        /*ifdef��̕\������ʂȕ\���ɕύX����*/
        the_iRet = GetPreLineStrValue(in_pPreprocLine,
            io_pAnzInfo->m_symbol,
            the_cTempValueStr);
        if (the_iRet != ANZ_SUCCESS){
            goto EXIT;
        }
        /*�\���̍ŏI�l���擾����*/
        GetComplexValue( the_cTempValueStr, &the_iValueFlag );
        if (the_iValueFlag == 0){
            *io_iIfFlag = 2;
        }
        else {
            *io_iIfFlag = 1;
        }
        g_iPreprocValue[g_iIfNum - 1][0] = *io_iIfFlag;
        the_iCharNum = 0;
        break;
        /* �J�����g�L�[���[�h��ifdef�ł���ꍇ */
    case 1:   /*1:"ifndef"*/
        g_iIfNum++;
		if (g_iIfNum > MAX_IFNUM ){
			the_iRet = ANZ_UNKNOWN_ERROR;
			goto EXIT;
		}
        if (g_iIfNum > 1 &&
            g_iPreprocValue[g_iIfNum - 2][strlen(g_iPreprocValue[g_iIfNum - 2]) - 1] == 2){
            *io_iIfFlag = 2;
            g_iPreprocValue[g_iIfNum - 1][0] = *io_iIfFlag;
            goto EXIT;
        }
        /*ifdef��̕\������ʂȕ\���ɕύX����*/
        the_iRet = GetPreLineStrValue(in_pPreprocLine,
            io_pAnzInfo->m_symbol,
            the_cTempValueStr);
        if (the_iRet != ANZ_SUCCESS){
            goto EXIT;
        }
        /*�\���̍ŏI�l���擾����*/
        GetComplexValue( the_cTempValueStr, &the_iValueFlag );
        if (the_iValueFlag == 0){
            *io_iIfFlag = 1;
        }
        else {
            *io_iIfFlag = 2;
        }
        g_iPreprocValue[g_iIfNum - 1][0] = *io_iIfFlag;
        break;
        /* �J�����g�̃L�[���[�h��if�ł���ꍇ */
    case 2:
        g_iIfNum++;
			if (g_iIfNum > MAX_IFNUM ){
			the_iRet = ANZ_UNKNOWN_ERROR;
			goto EXIT;
		}
        if (g_iIfNum > 1 &&
            g_iPreprocValue[g_iIfNum - 2][strlen(g_iPreprocValue[g_iIfNum - 2]) - 1] == 2){
            *io_iIfFlag = 2;
            g_iPreprocValue[g_iIfNum - 1][0] = *io_iIfFlag;
            goto EXIT;
        }
        /*ifdef��̕\������ʂȕ\���ɕύX����*/
        the_iRet = GetPreLineStrValue(in_pPreprocLine,
            io_pAnzInfo->m_symbol,
            the_cTempValueStr);
        if (the_iRet != ANZ_SUCCESS){
            goto EXIT;
        }
        /*�\���̍ŏI�l���擾����*/
        GetComplexValue( the_cTempValueStr, &the_iValueFlag );
        if (the_iValueFlag == 0){
            *io_iIfFlag = 2;
        }
        else {
            *io_iIfFlag = 1;
        }
        g_iPreprocValue[g_iIfNum - 1][0] = *io_iIfFlag;
        break;
        /* �J�����g�L�[���[�h��else�ł���ꍇ */
    case 3:
		if (g_iIfNum > MAX_IFNUM || 
			strlen(g_iPreprocValue[g_iIfNum - 1 ]) >= MAX_ELIFNUM){
			the_iRet = ANZ_UNKNOWN_ERROR;
			goto EXIT;
		}
        while(g_iPreprocValue[g_iIfNum - 1][the_iLoop3] != '\0'){
            if (g_iPreprocValue[g_iIfNum - 1][the_iLoop3] == 1){
                the_bValueFlag = true;
                break;
            }
            the_iLoop3++;
        }
        if (g_iPreprocValue[g_iIfNum - 2][strlen(g_iPreprocValue[g_iIfNum - 2]) -1] == 2 ||
            the_bValueFlag == true  ){
            *io_iIfFlag = 2;
        }
        else {
            *io_iIfFlag = 1;
        }
        g_iPreprocValue[g_iIfNum - 1][strlen(g_iPreprocValue[g_iIfNum - 1])] = *io_iIfFlag;
        break;
        /*�J�����g�L�[���[�h��define�ł���ꍇ */
    case 4:
		if (g_iIfNum > MAX_IFNUM || 
			strlen(g_iPreprocValue[g_iIfNum - 1 ]) >= MAX_ELIFNUM){
			the_iRet = ANZ_UNKNOWN_ERROR;
			goto EXIT;
		}
        if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1] != 0 &&
            *io_iIfFlag != 0){
            if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1]  == 1
                && *io_iIfFlag == 1){
                *io_iIfFlag = 0;
            }
            goto EXIT;
        }
        else {
            *io_iIfFlag = 0;
            if (g_iIfNum <= 0 ){
                *io_ifErrLine = 0;
            }
            goto EXIT;
        }
        break;
        /*�@�J�����g�L�[���[�h��elif�ł���ꍇ */
    case 5:
		if (g_iIfNum > MAX_IFNUM || 
			strlen(g_iPreprocValue[g_iIfNum - 1]) >= MAX_ELIFNUM){
			the_iRet = ANZ_UNKNOWN_ERROR;
			goto EXIT;
		}
        while(g_iPreprocValue[g_iIfNum - 1][the_iLoop3] != '\0'){
            if (g_iPreprocValue[g_iIfNum - 1][the_iLoop3] == 1){
                the_bValueFlag = true;
                the_iLoop3 = 0;
                break;
            }
            the_iLoop3++;
        }
        if (g_iPreprocValue[g_iIfNum - 2][strlen(g_iPreprocValue[g_iIfNum - 2]) -1] == 2 ||
            the_bValueFlag == true  ){
            *io_iIfFlag = 2;
        }
        else {
            /*ifdef��̕\������ʂȕ\���ɕύX����*/
            the_iRet = GetPreLineStrValue(in_pPreprocLine,
                io_pAnzInfo->m_symbol,
                the_cTempValueStr);
            if (the_iRet != ANZ_SUCCESS){
                goto EXIT;
            }
            /*�\���̍ŏI�l���擾����*/
            GetComplexValue( the_cTempValueStr, &the_iValueFlag );
            if (the_iValueFlag == 0){
                *io_iIfFlag = 2;
            }
            else {
                *io_iIfFlag = 1;
            }
        }
        g_iPreprocValue[g_iIfNum - 1][strlen(g_iPreprocValue[g_iIfNum - 1])] = *io_iIfFlag;
        break;
        /* �J�����g�L�[���[�h��endif�ł��� */
    case 6:
		the_iLoop3 = 0;
		while(g_iPreprocValue[g_iIfNum -1][the_iLoop3] != '\0'){
			g_iPreprocValue[g_iIfNum - 1][the_iLoop3] = '\0';
			the_iLoop3++;
		}
        g_iIfNum--;
        if ( g_iIfNum <= 0 ){
            *io_ifErrLine= 0;
            *io_iIfFlag = 1;
			g_iIfNum = 0;
            memset(g_iPreprocValue,'\0',MAX_IFNUM * MAX_ELIFNUM);
            goto EXIT;
        }
        else {
            if (g_iPreprocValue[g_iIfNum -1 ][strlen(g_iPreprocValue[g_iIfNum -1 ]) - 1] == 2){
                *io_iIfFlag = 2;
            }
            else {
                *io_iIfFlag = 1;
            }
        }

        break;
        /* �J�����g�L�[���[�h��undef�ł��� */
    case 7:
        if(g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1] == 2){
            *io_iIfFlag = 2;
            goto EXIT;
        }

        memset(the_cTempStr,0,MAX_PREPROC_VALUE);
        the_iLoop2 = 0;
        /*undef��ɗL���ȃt�B�[���h��S�Č�������*/
        while( *( in_pPreprocLine + the_iLoop1 ) != '\0' )
        {
            if (*( in_pPreprocLine + the_iLoop1 ) == ' '||
                *( in_pPreprocLine + the_iLoop1 ) == '\t'){
                the_iLoop1++;
                continue;
            }
            else {

                if ( *( in_pPreprocLine + the_iLoop1 )!= ' ' &&
                    *( in_pPreprocLine + the_iLoop1 )!= '\t' &&
                    *( in_pPreprocLine + the_iLoop1 ) != ';' ){

                    the_cTempStr[the_iLoop2++] = *( in_pPreprocLine + the_iLoop1 );
                }
                else {
                    break;
                }
            }
            the_iLoop1++;
        }
        if (strlen(the_cTempStr) > 0){
            the_iLoop2 = 0;
            while( the_iLoop2 < g_iUndefNum )
            {
                if ( strcmp(the_cTempStr,g_szArrUndef[the_iLoop2] ) == 0 ){
                    break;
                }
                else {
					if ((g_iUndefNum >= MAX_UNDEFNUM ) || 
						strlen(the_cTempStr) >= MAX_UNDEFCONT){
						the_iRet = ANZ_UNKNOWN_ERROR;
						goto EXIT;
					}
                    if (the_iLoop2 == g_iUndefNum - 1){
                        strcpy(g_szArrUndef[g_iUndefNum],the_cTempStr);
                        g_iUndefNum++;
                        break;
                    }
                }
                the_iLoop2++;
            }
            if (g_iUndefNum == 0){
				if ((g_iUndefNum >= MAX_UNDEFNUM ) || 
					strlen(the_cTempStr) >= MAX_UNDEFCONT){
					the_iRet = ANZ_UNKNOWN_ERROR;
					goto EXIT;
				}
                strcpy(g_szArrUndef[g_iUndefNum],the_cTempStr);
                g_iUndefNum++;
            }
        }
        if (*io_iIfFlag != 0){
            if (*io_iIfFlag == 1){
                *io_iIfFlag = 0;
            }
            goto EXIT;
        }
        else {
            *io_iIfFlag = 0;
            if (g_iIfNum <= 0 ){
                *io_ifErrLine = 0;
            }
            goto EXIT;
        }
        break;
        /* �J�����g�L�[���[�h��include�ł��� */
    case 8:
        if (*io_iIfFlag != 0){
            if (*io_iIfFlag == 1){
                *io_iIfFlag = 0;
            }
            goto EXIT;
        }
        else {
            *io_iIfFlag = 0;
            if (g_iIfNum <= 0 ){
                *io_ifErrLine = 0;
            }
            goto EXIT;
        }
        break;
    default:
        if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1] != 0 &&
            *io_iIfFlag != 0){
            if (g_iPreprocValue[g_iIfNum - 1][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1] == 1 &&
                *io_iIfFlag == 1){
                *io_iIfFlag = 0;
            }
            goto EXIT;
        }
        else {
            *io_iIfFlag = 0;
            if (g_iIfNum <= 0 ){
                *io_ifErrLine = 0;
            }
            goto EXIT;
        }
        break;
    }
EXIT:
    return the_iRet;

}

/**
*  preprocess1
*  �v���O�K�v�ȏ������s��
*  @param
           io_pAnzInfo  AnalyzeMe�Ǘ����
           in_pFileInfo �J�����g�v��File���
           in_iVerFlag  �J�����g�v��File�̔�(�V�ň��͋���)
           io_iErrFlag  �J�����g�v��File�ɃG���[�����邩�ǂ����̃t���O
*  @return
        ANZ_SUCCESS ����I��
        ANZ_ERROR   �ُ�I��
*  @author tong-huixin
*/
int Preprocess1(ST_AnalyzeMe *io_pAnzInfo,
				ST_MeasureFile *in_pFileInfo,
                int in_iVerFlag,
				int *io_iErrFlag)
{
    /* �ϐ��錾 */
    int   the_iRet = ANZ_SUCCESS;     /* Return�l */
    int   the_iMeasureType = 0;       /* �v����� */
    int   the_iTopBlankNum = 0;       /* �J�����g�s�擪�̋󔒐� */
    int   the_iBlankNum = 0;          /* �J�����g�s�̋󔒐� */
    int   the_iLineNum = 0;           /* File�̑��s�� */
    int   the_iExecLOC = 0;           /* File�̎��s�s�̍s�� */
    int   the_iComtLOC = 0;           /* File��Comment�s�̍s�� */
    int   the_iBlankLOC = 0;          /* File�̋󔒍s�̍s�� */
    int   the_iExecLOCNum = 0;        /* m_execLOC�̔z�� */
    int   the_iTotalLOCNum = 0;       /* m_totalLOC�̔z�� */
    int   the_iComtLOCNum = 0;        /* m_comtLOC�̔z�� */
    int   the_iBlankLOCNum = 0;       /* m_blankLOC�̔z�� */
    int   the_iPrevSeriesBlankNum = 0;/* �O�A���󔒐� */
    int   the_iSeriesBlankNum = 0;    /* �J�����g�s�ɘA���󔒐� */
    int   the_iComtNum = 0;           /* �u/*�v��Comment���̕����� */
    int   the_iCharNum = 0;           /* �u''�v�Ŋ܂ޕ����� */
    int   the_iIfFlag = 0;            /* #IF���̃t���O */
    int   the_iStrErrLine = 0;        /* �u""�v�����Ȃ��s�ԍ� */
    int   the_iCharErrLine = 0;       /* �u''�v�����Ȃ��s�ԍ� */
    int   the_iComtErrLine = 0;       /* Comment�����Ȃ��s�ԍ� */
    int   the_iIfErrLine = 0;         /* #If�����Ȃ��s�ԍ� */
    int   the_iContPreprocLineNum = 0;/* �p���ȃv���v���Z�X�s�� */
    int   the_iLoop = 0;              /* LOOP�p */
    unsigned char  the_cCurChar;      /* �J�����g���� */
    char *the_pFileCont;              /* File���e�̈ꎞPoint */
    char *the_pLineHeadAddr;          /* �J�����g�s��Head�A�h���X */
    char *the_pFileHeadAddr;          /*�J�����g�t�@�C���̊J�n�A�h���X*/
    char  the_szPreprocCont[MAX_PRECONT];/* �v���v���Z�X�s���e */
    char *the_pPreprocCont;           /* �v���v���Z�X�s���e��Point */
    char the_szFileName[MAX_PATH] = {0};/* �J�����g�J��File�� */
    bool  the_bPreprocFlag = false;   /* �J�����g�s���v���v���Z�X�s�ł��邩�̃t���O */
    bool  the_bCC_ComtFlag = false;   /* �u//�v���s�擪�ɂ��邩�̃t���O */
    bool  the_bC_ComtFlag1 = false;   /* �u/*�v���s�擪�ɂ��邩�̃t���O */
    bool  the_bC_ComtFlag2 = false;   /* �u/*�v���s�擪�ɂ���Ȃ��A
                                         �����Ȃ��ꍇ�A���s�����邩�̃t���O */
    bool the_bHeadBlankFlag = false;  /* �s�擪�ɋ󔒂����邩�̃t���O */
    bool the_bSeriesBlankFlag = false;/* �J�����g�s�ɘA���󔒂����邩�̃t���O */
    ST_LineAttr *the_pTempLineAttr;   /* �s����List��Node��\���ꎞ�ϐ� */
    ST_LineAttr *the_pCurLineAttr;    /* �J�����g�s�̍s���� */
    ST_LineAttr *the_pHeadLineAttr;   /* �s����List��Head Node��\�� */
    ST_LineAttr *the_pPrevLineAttr;   /* �s����List��Prev Node��\�� */
    ST_Error *the_pErrInfo;           /* File�̃J�����gError��� */
    ST_Option *the_pOption = NULL;    /* AnalyzeMe�Ǘ�����Option��� */
    char the_cDefStr[MAX_DEFINFE_STR];/*�L�����N�^#���1�ԖڗL���ȃL�[�t�B�[���h*/
    char *the_cTempDefStr;            /*the_cDefStr�ɑΉ�����|�C���g*/
    bool the_bDefFlag = false;        /*�L�����N�^#��ɗL���t�B�[���h��define�̃t���O*/
    bool the_bDefFlag1 = false;       /*�J�����g�s���}�N���̍s�̃t���O*/
    bool the_bPreProcLineAttrFlag = false; /*�J�����g�s���O�����̃t���O*/
    ST_LineAttr *the_pPreProcLineAttr = NULL;/*�O�����s��\������*/

    enum { NORMAL,      /* NORMAL��Ԃ̕\�� */
        CHARLITERAL,    /* �V���O���N�H�[�e�[�V������Ԃ�\�� */
        STRINGLITERAL,  /* �_�u���N�H�[�e�[�V������Ԃ�\�� */
        CC_COMMENT,     /* "//"�̃R�����g��Ԃ�\�� */
        C_COMMENT       /*"/*"�̃R�����g��Ԃ�\��*/
    } state = NORMAL;

    /* �O���[�o���ϐ������� */
    g_iIfNum = 0;   /* #IF�̐� */
	g_iUndefNum = 0;
    memset(g_iPreprocValue,'\0',MAX_IFNUM * MAX_ELIFNUM);
    memset(g_szArrUndef,'\0',MAX_UNDEFNUM * MAX_UNDEFCONT);

    /* ���[�J���ϐ������� */
    /*�J�����g�t�@�C�����V�����Ńt�@�C���̏ꍇ*/
    if(in_iVerFlag == ANZ_NV_FILE ||
        in_iVerFlag == ANZ_CM_FILE){
        the_pFileCont = in_pFileInfo->m_fileCont;
        the_pLineHeadAddr = in_pFileInfo->m_fileCont;
        the_pFileHeadAddr = in_pFileInfo->m_fileCont;
    }
    /*�J�����g�t�@�C�����Â��Ńt�@�C���̏ꍇ*/
    else{
        the_pFileCont = in_pFileInfo->m_ov_FileCont;
        the_pLineHeadAddr = in_pFileInfo->m_ov_FileCont;
        the_pFileHeadAddr = in_pFileInfo->m_ov_FileCont;
    }
    the_pCurLineAttr = NULL;
    the_pHeadLineAttr = NULL;
    the_pPrevLineAttr = NULL;
    the_pErrInfo = NULL;
    the_pTempLineAttr = NULL;
    memset(the_szPreprocCont,'\0',MAX_PRECONT);
    the_pPreprocCont = the_szPreprocCont;
    the_pOption = io_pAnzInfo->m_option;
    memset(the_cDefStr,'\0',MAX_DEFINFE_STR);
    the_cTempDefStr = the_cDefStr;

    ASSERT(io_pAnzInfo != NULL && in_pFileInfo != NULL);
    if (io_pAnzInfo == NULL || in_pFileInfo == NULL){
        the_iRet = ANZ_ERROR;
        goto ERR;
    }

    do {
        if ((the_cCurChar = *the_pFileCont++) == '\0'){
            the_iLineNum++;
            /* �J�����g������File�̍Ō�̕����ł���ꍇ */
            /* �R�����g�����Ȃ� */
            if (state == C_COMMENT){
                ADD_TO_ERROR_LIST();
                strcpy(the_pErrInfo->m_errFileName,in_pFileInfo->m_fileName);
                the_pErrInfo->m_errType = ANZ_COMT_NO_CLOSED;
                the_pErrInfo->m_lineno = the_iComtErrLine;
                *io_iErrFlag = 1;
                the_iRet = ANZ_COMT_NO_CLOSED;
                goto ERR;
            }
            /* "�����Ȃ� */
            else if (state == STRINGLITERAL){
                ADD_TO_ERROR_LIST();
                strcpy(the_pErrInfo->m_errFileName,in_pFileInfo->m_fileName);
                the_pErrInfo->m_errType = ANZ_STRINGLITERAL_N0_CLOSED;
                the_pErrInfo->m_lineno = the_iStrErrLine;
                *io_iErrFlag = 1;
                the_iRet = ANZ_STRINGLITERAL_N0_CLOSED;
                goto ERR;
            }
            else{
                if (strlen(the_cDefStr) > 0 ){
                    if (strcmp(the_cDefStr,"define") == 0){
                        memset(the_cDefStr,0,MAX_DEFINFE_STR);
                        the_cTempDefStr = the_cDefStr;
                        memset(the_szPreprocCont,0,MAX_PRECONT);
                        the_pPreprocCont = the_szPreprocCont;
                        the_bDefFlag = true;
                        if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1] != 0 &&
                            the_iIfFlag != 0){
                            if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1]  == 1
                                && the_iIfFlag == 1){
                                the_iIfFlag = 0;
                            }
                        }
                        else {
                            the_iIfFlag = 0;
                            if (g_iIfNum <= 0 ){
                                the_iIfErrLine = 0;
                            }
                        }

                    }
                    else {
                        memset(the_cDefStr,0,MAX_DEFINFE_STR);
                        the_cTempDefStr = the_cDefStr;
                    }
                    the_bDefFlag1 = true;
                }
                /* �J�����g�s���v���v���Z�X�s */
                if (the_bPreprocFlag == true && strlen(the_szPreprocCont) > 0
                    && *(the_pPreprocCont - (1 + the_iSeriesBlankNum)) != '#'){
                    /* �v���v���Z�X�s�̓��e����͂��� */
                    the_iRet = CheckPreproc(io_pAnzInfo,the_szPreprocCont,
											&the_iIfFlag,&the_iIfErrLine);
                    if (the_iRet != ANZ_SUCCESS){
                        goto ERR;
                    }
                }
                if (the_bPreprocFlag == true && strlen(the_szPreprocCont) > 0
                    && *(the_pPreprocCont - (1 + the_iSeriesBlankNum)) == '#'){
                    memset(the_szPreprocCont,0,MAX_PRECONT);
                    the_pPreprocCont = the_szPreprocCont;
                    if (the_iIfErrLine == the_iLineNum){
                        the_iIfErrLine = 0;
                    }
                    the_bPreprocFlag = false;
                }
                if (the_iIfErrLine == 0){
                    ADD_TO_LINEATTR_LIST();
                }
                /* #if�����Ȃ� */
                if (the_iIfErrLine > 0){
                    ADD_TO_ERROR_LIST();
                    strcpy(the_pErrInfo->m_errFileName,in_pFileInfo->m_fileName);
                    the_pErrInfo->m_errType = ANZ_PREPRC_NO_CLOSED;
                    the_pErrInfo->m_lineno = the_iIfErrLine;
                    *io_iErrFlag = 1;
                    the_iRet = ANZ_PREPRC_NO_CLOSED;
                    goto ERR;
                }
                /* �J�����g�s���󔒍s�ł��� */
                else if ((the_pFileCont - (1 + the_iSeriesBlankNum)) == the_pFileHeadAddr
                    || *(the_pFileCont - (2 + the_iSeriesBlankNum)) == '\0'){
                    the_iPrevSeriesBlankNum = 0;
                    the_iSeriesBlankNum = 0;
                    the_iComtNum = 0;
                    the_iTopBlankNum = 0;
                    the_iBlankNum = 0;
                    the_bSeriesBlankFlag = false;
                    /* �J�����g�̋󔒍s���A���ȃv���v���Z�X�s�̂���s�ł��� */
                    if (the_bPreprocFlag == true){
                        the_iContPreprocLineNum++;
                        the_pCurLineAttr->m_lineno = the_iLineNum;
                        the_pCurLineAttr->m_attr.BL = 1;
                        the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                        if (the_bPreProcLineAttrFlag == false){
                           the_pPreProcLineAttr = the_pCurLineAttr;
                           the_bPreProcLineAttrFlag = true;
                         }
                        SET_PREPROCESS_ATTR();
                        memset(the_szPreprocCont,0,MAX_PRECONT);
                        the_pPreprocCont = the_szPreprocCont;
                        the_iContPreprocLineNum = 0;
                        the_bPreprocFlag = false;
                        the_bPreProcLineAttrFlag = false;
                        the_pPreProcLineAttr = NULL;
                        break;
                    }
                    /* �J�����g�̋󔒍s���A���ȃv���v���Z�X�s�̂���s�ł͂Ȃ� */
                    else {
                        the_iBlankLOC++;
                        the_pCurLineAttr->m_lineno = the_iLineNum;
                        the_pCurLineAttr->m_attr.BL = 1;
                        the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                        break;
                    }
                    break;
                }
                /* �J�����g�s��"/*"�̃R�����g�����ŏI������ */
                else if (*(the_pFileCont - (2+the_iSeriesBlankNum)) == '/' && *(the_pFileCont - (3+the_iSeriesBlankNum)) == '*'){
                    /* �J�����g�s���R�����g�s�ł��� */
                    if (the_bC_ComtFlag1 == true || the_bC_ComtFlag2 == true){
                        the_iPrevSeriesBlankNum = 0;
                        the_iSeriesBlankNum = 0;
                        the_iComtNum = 0;
                        the_iTopBlankNum = 0;
                        the_iBlankNum = 0;
                        the_bSeriesBlankFlag = false;
                        /* �J�����g�̃R�����g�s���A���ȃv���v���Z�X�s�̂���s�ł��� */
                        if (the_bPreprocFlag == true){
                            the_iContPreprocLineNum++;
                            the_pCurLineAttr->m_lineno = the_iLineNum;
                            the_pCurLineAttr->m_attr.CL = 1;
                            the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                            if (the_bPreProcLineAttrFlag == false){
                                the_pPreProcLineAttr = the_pCurLineAttr;
                                the_bPreProcLineAttrFlag = true;
                            }
                            SET_PREPROCESS_ATTR();
                            memset(the_szPreprocCont,0,MAX_PRECONT);
                            the_pPreprocCont = the_szPreprocCont;
                            the_iContPreprocLineNum = 0;
                            the_bPreProcLineAttrFlag = false;
                            the_pPreProcLineAttr = NULL;
                            break;
                        }
                        /* �J�����g�̃R�����g�s���A���ȃv���v���Z�X�s�̂���s�ł͂Ȃ� */
                        else {
                            the_iComtLOC++;
                            the_pCurLineAttr->m_lineno = the_iLineNum;
                            the_pCurLineAttr->m_attr.CL = 1;
                            the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                            break;
                        }
                        break;
                    }
                    /*�J�����g�s�����s������"/*"�ŃR�����g�����̑g�ݍ��킹���s�ł���*/
                    else {
                        the_iPrevSeriesBlankNum = 0;
                        the_iSeriesBlankNum = 0;
                        the_iComtNum = 0;
                        /* �J�����g�s���A���ȃv���v���Z�X�s�̂���s�ł��� */
                        if (the_bPreprocFlag == true){
                            the_iContPreprocLineNum++;
                            the_iTopBlankNum = 0;
                            the_iBlankNum = 0;
                            the_bSeriesBlankFlag = false;
                            the_pCurLineAttr->m_lineno = the_iLineNum;
                            the_pCurLineAttr->m_attr.EL = 1;
                            the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                            if (the_bPreProcLineAttrFlag == false){
                                the_pPreProcLineAttr = the_pCurLineAttr;
                                the_bPreProcLineAttrFlag = true;
                            }
                            SET_PREPROCESS_ATTR();
                            memset(the_szPreprocCont,0,MAX_PRECONT);
                            the_pPreprocCont = the_szPreprocCont;
                            the_iContPreprocLineNum = 0;
                            the_bPreprocFlag = false;
                            the_bPreProcLineAttrFlag = false;
                            the_pPreProcLineAttr = NULL;
                            break;
                        }
                        /* �J�����g�s���A���ȃv���v���Z�X�s�̂���s�ł͂Ȃ� */
                        else {
                            the_iExecLOC++;
                            the_pCurLineAttr->m_lineno = the_iLineNum;
                            the_pCurLineAttr->m_attr.EL = 1;
                            the_pCurLineAttr->m_attr1.BNUM = the_iTopBlankNum;
                            if (the_bSeriesBlankFlag == true || *(the_pFileCont - 2 ) == ' '){
                                the_pCurLineAttr->m_attr1.BFLAG = 1;
                            }
                            the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                            the_iTopBlankNum = 0;
                            the_iBlankNum = 0;
                            the_bSeriesBlankFlag = false;
                            break;
                        }
                        break;
                    }
                    break;
                }
                /* �J�����g�s��"//"�ŃR�����g�����s */
                else if (the_bCC_ComtFlag == true){
                    the_iPrevSeriesBlankNum = 0;
                    the_iSeriesBlankNum = 0;
                    the_iComtNum = 0;
                    /* �J�����g�R�����g�s���A���ȃv���v���Z�X�s�̂���s�ł��� */
                    if (the_bPreprocFlag == true){
                        the_iContPreprocLineNum++;
                        the_iTopBlankNum = 0;
                        the_iBlankNum = 0;
                        the_bSeriesBlankFlag = false;
                        the_pCurLineAttr->m_lineno = the_iLineNum;
                        the_pCurLineAttr->m_attr.CL = 1;
                        the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                        if (the_bPreProcLineAttrFlag == false){
                            the_pPreProcLineAttr = the_pCurLineAttr;
                            the_bPreProcLineAttrFlag = true;
                        }
                        SET_PREPROCESS_ATTR();
                        memset(the_szPreprocCont,0,MAX_PRECONT);
                        the_pPreprocCont = the_szPreprocCont;
                        the_iContPreprocLineNum = 0;
                        the_bPreprocFlag = false;
                        the_bPreProcLineAttrFlag = false;
                        the_pPreProcLineAttr = NULL;
                        break;
                        /* �J�����g�R�����g�s���v���v���Z�X�̈ꕔ�ł͂Ȃ� */
                    } else {
                        the_iComtLOC++;
                        the_pCurLineAttr->m_lineno = the_iLineNum;
                        the_pCurLineAttr->m_attr.CL = 1;
                        the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                        break;
                    }
                    break;
                }
                /* �J�����g�s�����s�s�ł��� */
                else {
                    the_iPrevSeriesBlankNum = 0;
                    the_iSeriesBlankNum = 0;
                    the_iComtNum = 0;
                    /*�J�����g�̎��s�s���v���v���Z�X�̈ꕔ�ł���*/
                    if (the_bPreprocFlag == true){
                        the_iContPreprocLineNum++;
                        the_iTopBlankNum = 0;
                        the_iBlankNum = 0;
                        the_bSeriesBlankFlag = false;
                        the_pCurLineAttr->m_lineno = the_iLineNum;
                        the_pCurLineAttr->m_attr.EL = 1;
                        the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                        if (the_bPreProcLineAttrFlag == false){
                            the_pPreProcLineAttr = the_pCurLineAttr;
                            the_bPreProcLineAttrFlag = true;
                        }
                        SET_PREPROCESS_ATTR();
                        memset(the_szPreprocCont,0,MAX_PRECONT);
                        the_pPreprocCont = the_szPreprocCont;
                        the_iContPreprocLineNum = 0;
                        the_bPreprocFlag = false;
                        the_bPreProcLineAttrFlag = false;
                        the_pPreProcLineAttr = NULL;
                        break;
                    }
                    /*�J�����g���s�s���v���v���Z�X�̈ꕔ�ł͂Ȃ�*/
                    else {
                        the_iExecLOC++;
                        the_pCurLineAttr->m_lineno = the_iLineNum;
                        the_pCurLineAttr->m_attr.EL = 1;
                        the_pCurLineAttr->m_attr1.BNUM = the_iTopBlankNum;
                        if (the_bSeriesBlankFlag == true || *(the_pFileCont - 2) == ' ' ){
                            the_pCurLineAttr->m_attr1.BFLAG = 1;
                        }
                        the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                        if (the_bC_ComtFlag1 == true || the_bC_ComtFlag2 == true){
                            the_pCurLineAttr->m_attr1.OEC = 1;
                        }
                        the_iTopBlankNum = 0;
                        the_iBlankNum = 0;
                        the_bSeriesBlankFlag = false;
                        break;
                    }
                    break;
                }
            }
        }
        /*�J�����g�����͑S�p�����ł��邩�A���p�����ł��邩*/
        if ( my_iskanji(the_cCurChar)){
            if ( state == C_COMMENT || state == CC_COMMENT || STRINGLITERAL){
                *the_pFileCont++;
                continue;
            }
            else {
                ADD_TO_ERROR_LIST();
                strcpy(the_pErrInfo->m_errFileName,in_pFileInfo->m_fileName);
                the_pErrInfo->m_errType = ANZ_KANJI_ERROR;
                the_pErrInfo->m_lineno = the_iLineNum + 1;
                *io_iErrFlag = 1;
                the_iRet =  ANZ_KANJI_ERROR;
                goto ERR;
            }
        }
        switch (state){
            /*�J�����g�̏�Ԃ�NORMAL�ł��邩*/
        case NORMAL:
            if (the_cCurChar != ' ' && the_cCurChar != '\t'){
                if ( the_bHeadBlankFlag == true ){
                    the_bHeadBlankFlag = false;
                }
                if ( the_iBlankNum > 1 ){
                    the_bSeriesBlankFlag = true;
                }
                else {
                    the_iBlankNum = 0;
                }
            }
            /*NORMAL�̏�ԂŃJ�����g��������������*/
            switch (the_cCurChar){
            case '\'':
                if (the_bPreprocFlag == true && the_bDefFlag == false){
					if (strlen(the_szPreprocCont) >= MAX_PRECONT){
						the_iRet = ANZ_UNKNOWN_ERROR;
							goto ERR;
					}
                    *the_pPreprocCont++ = the_cCurChar;
                    if (strlen(the_cDefStr) > 0 ){
                        if (strcmp(the_cDefStr,"define") == 0){
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                            memset(the_szPreprocCont,0,MAX_PRECONT);
                            the_pPreprocCont = the_szPreprocCont;
                            the_bDefFlag = true;
                            if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1] != 0 &&
                                the_iIfFlag != 0){
                                if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1]  == 1
                                    && the_iIfFlag == 1){
                                    the_iIfFlag = 0;
                                }
                            }
                            else {
                                the_iIfFlag = 0;
                                if (g_iIfNum <= 0 ){
                                    the_iIfErrLine = 0;
                                }
                            }
                        }
                        else {
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                        }
                        the_bDefFlag1 = true;
                    }
                    else {
                        the_bDefFlag1 = true;
                    }
                }
                the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                the_iSeriesBlankNum = 0;
                the_iComtNum = 0;
                the_iCharErrLine = the_iLineNum + 1;
                state = CHARLITERAL;
                break;
            case '"':
                if (the_bPreprocFlag == true && the_bDefFlag == false){
					if (strlen(the_szPreprocCont) >= MAX_PRECONT){
						the_iRet = ANZ_UNKNOWN_ERROR;
							goto ERR;
					}
                    *the_pPreprocCont++ = the_cCurChar;
                    if (strlen(the_cDefStr) > 0 ){
                        if (strcmp(the_cDefStr,"define") == 0){
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                            memset(the_szPreprocCont,0,MAX_PRECONT);
                            the_pPreprocCont = the_szPreprocCont;
                            the_bDefFlag = true;
                            if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1] != 0 &&
                                the_iIfFlag != 0){
                                if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1]  == 1
                                    && the_iIfFlag == 1){
                                    the_iIfFlag = 0;
                                }
                            }
                            else {
                                the_iIfFlag = 0;
                                if (g_iIfNum <= 0 ){
                                    the_iIfErrLine = 0;
                                }
                            }
                        }
                        else {
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                        }
                        the_bDefFlag1 = true;
                    }
                    else {
                        the_bDefFlag1 = true;
                    }

                }
                the_iStrErrLine = the_iLineNum + 1;
                the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                the_iSeriesBlankNum = 0;
                the_iComtNum = 0;
                state = STRINGLITERAL;
                break;
            case '#':
                if (the_bPreprocFlag == true && the_bDefFlag == false){
					if (strlen(the_szPreprocCont) >= MAX_PRECONT){
						the_iRet = ANZ_UNKNOWN_ERROR;
							goto ERR;
					}
                    *the_pPreprocCont++ = the_cCurChar;
                    if (strlen(the_cDefStr) > 0 ){
                        if (strcmp(the_cDefStr,"define") == 0){
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                            memset(the_szPreprocCont,0,MAX_PRECONT);
                            the_pPreprocCont = the_szPreprocCont;
                            the_bDefFlag = true;
                            if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1] != 0 &&
                                the_iIfFlag != 0){
                                if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1]  == 1
                                    && the_iIfFlag == 1){
                                    the_iIfFlag = 0;
                                }
                            }
                            else {
                                the_iIfFlag = 0;
                                if (g_iIfNum <= 0 ){
                                    the_iIfErrLine = 0;
                                }
                            }
                        }
                        else {
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                        }
                        the_bDefFlag1 = true;
                    }
                    else {
                        the_bDefFlag1 = true;
                    }

                }
                /*�J�����g�̓v���v���Z�X�s�ł���*/
                if ((the_pFileCont -(1 + the_iSeriesBlankNum + the_iComtNum)) == the_pFileHeadAddr
                    || *(the_pFileCont - (2 + the_iSeriesBlankNum + the_iComtNum)) == '\0'){
                    the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                    the_iSeriesBlankNum = 0;
                    the_iComtNum = 0;
                    the_bPreprocFlag = true;
                    the_bDefFlag = false;
                    the_bDefFlag1 = false;
                    if (the_iIfErrLine == 0){
                        the_iIfFlag = 0;
                        the_iIfErrLine = the_iLineNum + 1;
                    }
					if (strlen(the_szPreprocCont) >= MAX_PRECONT){
						the_iRet = ANZ_UNKNOWN_ERROR;
							goto ERR;
					}
                    *the_pPreprocCont++ = the_cCurChar;
                    break;
                }
                /*�J�����g�̓v���v���Z�X�s�ł͂Ȃ�*/
                else {
                    the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                    the_iSeriesBlankNum = 0;
                    the_iComtNum = 0;
                    break;
                }
                break;
            case ' ':
                /*�J�����g��Space���s�擪�̋󔒂̈ꕔ�ł���*/
                if ((the_pFileCont -1 ) == the_pFileHeadAddr
                    || *(the_pFileCont - 2 ) == '\0'){
                    the_iTopBlankNum++;
                    the_bHeadBlankFlag = true;
                }
                else {
                    if (the_bHeadBlankFlag == true){
                        the_iTopBlankNum++;
                    }
                }
                /*�J�����g��Space���s���Ԃ̋󔒂̈ꕔ�ł���*/
                if (the_bHeadBlankFlag == false && the_bSeriesBlankFlag == false){
                    the_iBlankNum++;
                }
                if (the_bPreprocFlag == true && the_bDefFlag == false){
                    if (*(the_pPreprocCont - 1) != '#'){
						if (strlen(the_szPreprocCont) >= MAX_PRECONT){
							the_iRet = ANZ_UNKNOWN_ERROR;
								goto ERR;
						}
                        *the_pPreprocCont++ = the_cCurChar;
                    }
                    if (strlen(the_cDefStr) > 0 ){
                        if (strcmp(the_cDefStr,"define") == 0){
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                            memset(the_szPreprocCont,0,MAX_PRECONT);
                            the_pPreprocCont = the_szPreprocCont;
                            the_bDefFlag = true;
                            if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1] != 0 &&
                                the_iIfFlag != 0){
                                if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1]  == 1
                                    && the_iIfFlag == 1){
                                    the_iIfFlag = 0;
                                }
                            }
                            else {
                                the_iIfFlag = 0;
                                if (g_iIfNum <= 0 ){
                                    the_iIfErrLine = 0;
                                }
                            }
                        }
                        else {
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                        }
                        the_bDefFlag1 = true;
                    }
                }
                the_iSeriesBlankNum++;
                break;
            case '\t':
                /*�J�����g��'\t'���s�擪�̋󔒂̈ꕔ�ł���*/
                if ((the_pFileCont -1 ) == the_pFileHeadAddr
                    || *(the_pFileCont - 2 ) == '\0'){
                    the_iTopBlankNum++;
                    the_bHeadBlankFlag = true;
                }
                else {
                    if (the_bHeadBlankFlag == true){
                        the_iTopBlankNum++;
                    }
                }
                /*�J�����g��'\t'���s���Ԃ̋󔒂̈ꕔ�ł���*/
                if (the_bHeadBlankFlag == false && the_bSeriesBlankFlag == false){
                    the_iBlankNum++;
                }
                if (the_bPreprocFlag == true && the_bDefFlag == false){
                    if (*(the_pPreprocCont - 1) != '#'){
						if (strlen(the_szPreprocCont) >= MAX_PRECONT){
							the_iRet = ANZ_UNKNOWN_ERROR;
								goto ERR;
						}
                        *the_pPreprocCont++ = the_cCurChar;
                    }

                    if (strlen(the_cDefStr) > 0 && *(the_cTempDefStr - 1) != '\\'){
                        if (strcmp(the_cDefStr,"define") == 0){
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                            memset(the_szPreprocCont,0,MAX_PRECONT);
                            the_pPreprocCont = the_szPreprocCont;
                            the_bDefFlag = true;
                            if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1] != 0 &&
                                the_iIfFlag != 0){
                                if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1]  == 1
                                    && the_iIfFlag == 1){
                                    the_iIfFlag = 0;
                                }
                            }
                            else {
                                the_iIfFlag = 0;
                                if (g_iIfNum <= 0 ){
                                    the_iIfErrLine = 0;
                                }
                            }
                        }
                        else {
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                        }
                        the_bDefFlag1 = true;
                    }
                    if (strlen(the_cDefStr) > 0 && *(the_cTempDefStr - 1) == '\\'){
                        memset(the_cDefStr,0,MAX_DEFINFE_STR);
                        the_cTempDefStr = the_cDefStr;
                    }
                }
                the_iSeriesBlankNum++;
                break;
            case '/':
                if (the_bPreprocFlag == true && the_bDefFlag == false){
                    if (strlen(the_cDefStr) > 0 ){
                        if (strcmp(the_cDefStr,"define") == 0){
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                            memset(the_szPreprocCont,0,MAX_PRECONT);
                            the_pPreprocCont = the_szPreprocCont;
                            the_bDefFlag = true;
                            if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1]) - 1] != 0 &&
                                the_iIfFlag != 0){
                                if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1]  == 1
                                    && the_iIfFlag == 1){
                                    the_iIfFlag = 0;
                                }
                            }
                            else {
                                the_iIfFlag = 0;
                                if (g_iIfNum <= 0 ){
                                    the_iIfErrLine = 0;
                                }
                            }
                        }
                        else {
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                        }
                        the_bDefFlag1 = true;
                    }
                    else {
                        the_bDefFlag1 = true;
                    }
                }
                if (my_iskanji((unsigned char)*the_pFileCont)){
                    break;
                }
                switch (*the_pFileCont){
                    /*"//"�ŊJ�n����R�����g*/
                case '/':
                    /*"//"���s�擪�ɂ���*/
                    if ((the_pFileCont - (1 + the_iSeriesBlankNum + the_iComtNum)) == the_pFileHeadAddr
                        || *(the_pFileCont - (2 + the_iSeriesBlankNum + the_iComtNum)) == '\0'
                        || the_bC_ComtFlag1 == true ){
                        the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                        the_iSeriesBlankNum = 0;
                        the_iComtNum = 0;
                        the_bCC_ComtFlag = true;
                        the_pFileCont++;
                        state = CC_COMMENT;
                        break;
                    }
                    /*"//"���s�擪�ɂ���Ȃ�*/
                    else {
                        the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                        the_iSeriesBlankNum = 0;
                        the_iComtNum = 0;
                        the_bCC_ComtFlag = false;
                        the_pFileCont++;
                        state = CC_COMMENT;
                        break;
                    }
                    break;
                    /*"/*"�ŊJ�n����R�����g*/
                case '*':
                    the_iComtErrLine = the_iLineNum + 1;
                    /*�J�����g��"/*"���s�擪�ɂ���*/
                    if ((the_pFileCont - (1 + the_iSeriesBlankNum + the_iComtNum)) == the_pFileHeadAddr
                        || *(the_pFileCont - (2 + the_iSeriesBlankNum + the_iComtNum)) == '\0'
                        || the_bC_ComtFlag1 == true ){
                        the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                        the_iSeriesBlankNum = 0;
                        the_iComtNum = the_iComtNum + 2;
                        the_bC_ComtFlag1 = true;
                        the_pFileCont++;
                        state = C_COMMENT;
                        break;
                    }
                    /*�J�����g��"/*"���s�擪�ɂ���Ȃ�*/
                    else {
                        the_iComtNum = the_iComtNum + 2;
                        the_bC_ComtFlag1 = false;
                        the_bC_ComtFlag2 = false;
                        the_pFileCont++;
                        state = C_COMMENT;
                        break;
                    }
                    break;
                default:
                    if (the_bPreprocFlag == true && the_bDefFlag == false){
						if (strlen(the_szPreprocCont) >= MAX_PRECONT){
							the_iRet = ANZ_UNKNOWN_ERROR;
								goto ERR;
						}
                        *the_pPreprocCont++ = the_cCurChar;
                        if (strlen(the_cDefStr) > 0 ){
                            if (strcmp(the_cDefStr,"define") == 0){
                                memset(the_cDefStr,0,MAX_DEFINFE_STR);
                                the_cTempDefStr = the_cDefStr;
                                memset(the_szPreprocCont,0,MAX_PRECONT);
                                the_pPreprocCont = the_szPreprocCont;
                                the_bDefFlag = true;
                                if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1]) - 1] != 0 &&
                                    the_iIfFlag != 0){
                                    if (g_iPreprocValue[g_iIfNum - 1][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1]  == 1
                                        && the_iIfFlag == 1){
                                        the_iIfFlag = 0;
                                    }
                                }
                                else {
                                    the_iIfFlag = 0;
                                    if (g_iIfNum <= 0 ){
                                        the_iIfErrLine = 0;
                                    }
                                }
                            }
                            else {
                                memset(the_cDefStr,0,MAX_DEFINFE_STR);
                                the_cTempDefStr = the_cDefStr;
                            }
                            the_bDefFlag1 = true;
                        }
                        else {
                            the_bDefFlag1 = true;
                        }
                    }
                    the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                    the_iSeriesBlankNum = 0;
                    the_iComtNum = 0;
                    break;
                }
                break;
                case '\r':
                    *(the_pFileCont -1 ) = '\0';
                    if (the_bPreprocFlag == true && the_bDefFlag == false){
						if (strlen(the_szPreprocCont) >= MAX_PRECONT){
							the_iRet = ANZ_UNKNOWN_ERROR;
								goto ERR;
						}
                        *the_pPreprocCont++ = ' ';

                        if (strlen(the_cDefStr) > 0 && *(the_cTempDefStr - 1) != '\\'){
                            if (strcmp(the_cDefStr,"define") == 0){
                                memset(the_cDefStr,0,MAX_DEFINFE_STR);
                                the_cTempDefStr = the_cDefStr;
                                memset(the_szPreprocCont,0,MAX_PRECONT);
                                the_pPreprocCont = the_szPreprocCont;
                                the_bDefFlag = true;
                                if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1] != 0 &&
                                    the_iIfFlag != 0){
                                    if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1]  == 1
                                        && the_iIfFlag == 1){
                                        the_iIfFlag = 0;
                                    }
                                }
                                else {
                                    the_iIfFlag = 0;
                                    if (g_iIfNum <= 0 ){
                                        the_iIfErrLine = 0;
                                    }
                                }
                            }
                            else {
                                memset(the_cDefStr,0,MAX_DEFINFE_STR);
                                the_cTempDefStr = the_cDefStr;
                            }
                            the_bDefFlag1 = true;
                        }
                        if (strlen(the_cDefStr) > 0 && *(the_cTempDefStr - 1) == '\\'){
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                        }
                    }
                    the_iSeriesBlankNum++;
                    break;
                    /*Normal�X�e�[�^�X��\n*/
                case '\n':
                    *(the_pFileCont -1 ) = '\0';
                    the_iLineNum++;
                    if (the_bDefFlag == true){

                        if (the_iIfFlag != 0){
                            if (the_iIfFlag == 1){
                                the_iIfFlag = 0;
                            }
                        }
                        else {
                            the_iIfFlag = 0;
                            if (g_iIfNum <= 0 ){
                                the_iIfErrLine = 0;
                            }
                        }
                    }
                    if (strlen(the_cDefStr) > 0 && *(the_cTempDefStr - 1) != '\\'){
                        if (strcmp(the_cDefStr,"define") == 0){
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                            memset(the_szPreprocCont,0,MAX_PRECONT);
                            the_pPreprocCont = the_szPreprocCont;
                            the_bDefFlag = true;
                            if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1] != 0 &&
                                the_iIfFlag != 0){
                                if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1]  == 1
                                    && the_iIfFlag == 1){
                                    the_iIfFlag = 0;
                                }
                            }
                            else {
                                the_iIfFlag = 0;
                                if (g_iIfNum <= 0 ){
                                    the_iIfErrLine = 0;
                                }
                            }
                        }
                        else {
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                            the_bDefFlag = false;
                            the_bDefFlag1 = false;
                        }
                        the_bDefFlag1 = true;
                    }
                    if (strlen(the_cDefStr) > 0 && *(the_cTempDefStr - 1) == '\\'){
                        memset(the_cDefStr,0,MAX_DEFINFE_STR);
                        the_cTempDefStr = the_cDefStr;
                    }

                    /*�J�����g�s���v���v���Z�X�s�ł���*/
                    if (the_bPreprocFlag == true && strlen(the_szPreprocCont) > 0){
                        if ( *(the_pFileCont - (2 + the_iSeriesBlankNum)) != '\\'
                            && *(the_pPreprocCont - (1 + the_iSeriesBlankNum))!= '#' ){

                            /*�v���v���Z�X�s�̓��e����͂���*/
                            the_iRet = CheckPreproc(io_pAnzInfo,the_szPreprocCont,
                                                    &the_iIfFlag,&the_iIfErrLine);
                            if (the_iRet != ANZ_SUCCESS){
                                goto ERR;
                            }
                        }
                        else {
                            if (*(the_pPreprocCont - (1 + the_iSeriesBlankNum)) == '\\'){
                                if (*(the_pPreprocCont - (2 + the_iSeriesBlankNum)) == '#'){
                                    *(the_pPreprocCont - (1 + the_iSeriesBlankNum)) = '\0';
                                    the_pPreprocCont -= 1 + the_iSeriesBlankNum;
                                }
                                else {
                                    *(the_pPreprocCont - (1 + the_iSeriesBlankNum)) = ' ';
                                }
                            }
                            if (*(the_pPreprocCont - (1 + the_iSeriesBlankNum)) == '#'){
                                memset(the_szPreprocCont,0,MAX_PRECONT);
                                the_pPreprocCont = the_szPreprocCont;
                                if (the_iIfErrLine == the_iLineNum){
                                    the_iIfErrLine = 0;
                                }
                                the_bPreprocFlag = false;
                            }
                        }
                    }
                    ADD_TO_LINEATTR_LIST();
                    /*�J�����g�s��#if���őI������Ȃ�����*/
                    if (the_iIfFlag == 2 && strlen(the_szPreprocCont) == 0){
                        the_iPrevSeriesBlankNum = 0;
                        the_iSeriesBlankNum = 0;
                        the_iComtNum = 0;
                        the_iTopBlankNum = 0;
                        the_iBlankNum = 0;
                        the_bSeriesBlankFlag = false;
                        the_iComtLOC++;
                        the_pCurLineAttr->m_lineno = the_iLineNum;
                        the_pCurLineAttr->m_attr.CL = 1;
                        the_pCurLineAttr->m_attr1.IFL = 1;
                        the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                        the_pLineHeadAddr = the_pFileCont;
                        the_bC_ComtFlag1 = false;
                        the_bC_ComtFlag2 = false;
                        break;
                    }
                    /*�J�����g�s���󔒍s�ł���*/
                    else {
                        if ((the_pFileCont - (1 + the_iSeriesBlankNum)) == the_pFileHeadAddr
                            || *(the_pFileCont - (2 + the_iSeriesBlankNum)) == '\0'){
                            the_iPrevSeriesBlankNum = 0;
                            the_iSeriesBlankNum = 0;
                            the_iComtNum = 0;
                            the_iTopBlankNum = 0;
                            the_iBlankNum = 0;
                            the_bSeriesBlankFlag = false;
                            /*�J�����g�̋󔒍s���v���v���Z�X�̈ꕔ�ł���*/
                            if (the_bPreprocFlag == true){
                                the_iContPreprocLineNum++;
                                the_pCurLineAttr->m_lineno = the_iLineNum;
                                the_pCurLineAttr->m_attr.BL = 1;
                                the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                if (the_bPreProcLineAttrFlag == false){
                                    the_pPreProcLineAttr = the_pCurLineAttr;
                                    the_bPreProcLineAttrFlag = true;
                                }
                                the_pLineHeadAddr = the_pFileCont;
                                SET_PREPROCESS_ATTR();
                                the_iContPreprocLineNum = 0;
                                the_bPreprocFlag = false;
                                the_bPreProcLineAttrFlag = false;
                                the_pPreProcLineAttr = NULL;
                            }
                            /*�J�����g�̋󔒍s���v���v���Z�X�̈ꕔ�ł͂Ȃ�*/
                            else {
                                the_iBlankLOC++;
                                the_pCurLineAttr->m_lineno = the_iLineNum;
                                the_pCurLineAttr->m_attr.BL = 1;
                                the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                the_pLineHeadAddr = the_pFileCont;
                            }
                            the_bC_ComtFlag1 = false;
                            the_bC_ComtFlag2 = false;
                            break;
                        }
                        /*�J�����g�s��"/*"�ŃR�����g���������ŏI������*/
                        else if (*(the_pFileCont - (2+the_iSeriesBlankNum)) == '/' && *(the_pFileCont - (3+the_iSeriesBlankNum)) == '*'){
                            /*�J�����g�s���R�����g�s�ł���*/
                            if (the_bC_ComtFlag1 == true || the_bC_ComtFlag2 == true){
                                the_iPrevSeriesBlankNum = 0;
                                the_iSeriesBlankNum = 0;
                                the_iComtNum = 0;
                                /*�J�����g�R�����g�s���v���v���Z�X�̈ꕔ�ł���*/
                                if (the_bPreprocFlag == true){
                                    the_iContPreprocLineNum++;
                                    the_iTopBlankNum = 0;
                                    the_iBlankNum = 0;
                                    the_bSeriesBlankFlag = false;
                                    the_pCurLineAttr->m_lineno = the_iLineNum;
                                    the_pCurLineAttr->m_attr.CL = 1;
                                    the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                    if (the_bPreProcLineAttrFlag == false){
                                        the_pPreProcLineAttr = the_pCurLineAttr;
                                        the_bPreProcLineAttrFlag = true;
                                    }
                                    the_pLineHeadAddr = the_pFileCont;
                                    SET_PREPROCESS_ATTR();
                                    memset(the_szPreprocCont,0,MAX_PRECONT);
                                    the_pPreprocCont = the_szPreprocCont;
                                    the_iContPreprocLineNum = 0;
                                    the_bPreprocFlag = false;
                                    the_bPreProcLineAttrFlag = false;
                                    the_pPreProcLineAttr = NULL;
                                }
                                /*�J�����g���v���v���Z�X�̈ꕔ�ł͂Ȃ�*/
                                else {
                                    the_iComtLOC++;
                                    the_pCurLineAttr->m_lineno = the_iLineNum;
                                    the_pCurLineAttr->m_attr.CL = 1;
                                    the_pCurLineAttr->m_attr1.BNUM = the_iTopBlankNum;
                                    if ( the_bSeriesBlankFlag == true || *(the_pFileCont - 2 ) == ' ' || *(the_pFileCont - 2 ) == '\t'){
                                        the_pCurLineAttr->m_attr1.BFLAG = 1;
                                    }
                                    the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                    the_iTopBlankNum = 0;
                                    the_iBlankNum = 0;
                                    the_bSeriesBlankFlag = false;
                                    the_pLineHeadAddr = the_pFileCont;
                                }
                                the_bC_ComtFlag1 = false;
                                the_bC_ComtFlag2 = false;
                                break;
                            }
                            /*�J�����g�s�����s�����ƃR�����g�̑g�ݍ��킹���s�ł���*/
                            else {
                                the_iPrevSeriesBlankNum = 0;
                                the_iSeriesBlankNum = 0;
                                the_iComtNum = 0;
                                /*�J�����g�s���v���v���Z�X�̈ꕔ�ł���*/
                                if (the_bPreprocFlag == true){
                                    the_iContPreprocLineNum++;
                                    the_iTopBlankNum = 0;
                                    the_iBlankNum = 0;
                                    the_bSeriesBlankFlag = false;
                                    the_pCurLineAttr->m_lineno = the_iLineNum;
                                    the_pCurLineAttr->m_attr.EL = 1;
                                    the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                    if (the_bPreProcLineAttrFlag == false){
                                        the_pPreProcLineAttr = the_pCurLineAttr;
                                        the_bPreProcLineAttrFlag = true;
                                    }
                                    the_pLineHeadAddr = the_pFileCont;
                                    SET_PREPROCESS_ATTR();
                                    memset(the_szPreprocCont,0,MAX_PRECONT);
                                    the_pPreprocCont = the_szPreprocCont;
                                    the_iContPreprocLineNum = 0;
                                    the_bPreprocFlag = false;
                                    the_bPreProcLineAttrFlag = false;
                                    the_pPreProcLineAttr = NULL;
                                }
                                /*�J�����g�s���v���v���Z�X�̈ꕔ�ł͂Ȃ�*/
                                else {
                                    the_iExecLOC++;
                                    the_pCurLineAttr->m_lineno = the_iLineNum;
                                    the_pCurLineAttr->m_attr.EL = 1;
                                    the_pCurLineAttr->m_attr1.BNUM = the_iTopBlankNum;
                                    if ( the_bSeriesBlankFlag == true || *(the_pFileCont - 2 ) == ' ' || *(the_pFileCont - 2 ) == '\t'){
                                        the_pCurLineAttr->m_attr1.BFLAG = 1;
                                    }
                                    the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                    the_iTopBlankNum = 0;
                                    the_iBlankNum = 0;
                                    the_bSeriesBlankFlag = false;
                                    the_pLineHeadAddr = the_pFileCont;
                                }
                                the_bC_ComtFlag1 = false;
                                the_bC_ComtFlag2 = false;
                                break;
                            }
                            break;
                        }
                        /*�J�����g�s��"/*"�ŃR�����g�����ƘA���s�̑g�ݍ��킹��s�ł���*/
                        else if (*(the_pFileCont - (2+the_iSeriesBlankNum)) == '\\'
                            && *(the_pFileCont - (3+the_iSeriesBlankNum+the_iPrevSeriesBlankNum)) == '/'
                            && *(the_pFileCont - (4+the_iSeriesBlankNum+the_iPrevSeriesBlankNum)) == '*'){
                            /*�J�����g�s���R�����g�ƘA���̍s�ł���*/
                            if (the_bC_ComtFlag1 == true || the_bC_ComtFlag2 == true){
                                the_iPrevSeriesBlankNum = 0;
                                the_iSeriesBlankNum = 0;
                                the_iComtNum = 0;
                                /*�J�����g�s���v���v���Z�X�̈ꕔ�ł���*/
                                if (the_bPreprocFlag == true){
                                    //if (the_bDefFlag != true){
                                        //*(the_pPreprocCont - 1) = ' ';
                                    //}
                                    the_iContPreprocLineNum++;
                                    the_iTopBlankNum = 0;
                                    the_iBlankNum = 0;
                                    the_bSeriesBlankFlag = false;
                                    the_pCurLineAttr->m_lineno = the_iLineNum;
                                    the_pCurLineAttr->m_attr.CL = 1;
                                    the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                    if (the_bPreProcLineAttrFlag == false){
                                        the_pPreProcLineAttr = the_pCurLineAttr;
                                        the_bPreProcLineAttrFlag = true;
                                    }
                                    the_pLineHeadAddr = the_pFileCont;
                                }
                                /*�J�����g�s���v���v���Z�X�̈ꕔ�ł���*/
                                else {
                                    the_iComtLOC++;
                                    the_pCurLineAttr->m_lineno = the_iLineNum;
                                    the_pCurLineAttr->m_attr.CL = 1;
                                    the_pCurLineAttr->m_attr.SL = 1;
                                    the_pCurLineAttr->m_attr1.BNUM = the_iTopBlankNum;
                                    the_pCurLineAttr->m_attr1.BFLAG = 1;
                                    the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                    the_iTopBlankNum = 0;
                                    the_iBlankNum = 0;
                                    the_bSeriesBlankFlag = 0;
                                    the_pLineHeadAddr = the_pFileCont;
                                }
                                the_bC_ComtFlag1 = false;
                                the_bC_ComtFlag2 = false;
                                break;
                            }
                            /*�J�����g�s�����s�����ƃR�����g�����ƘA������������s�ł���*/
                            else {
                                the_iPrevSeriesBlankNum = 0;
                                the_iSeriesBlankNum = 0;
                                the_iComtNum = 0;
                                /*�J�����g�s���v���v���Z�X�̈ꕔ�ł���*/
                                if (the_bPreprocFlag == true){
                                    the_iContPreprocLineNum++;
                                    the_iTopBlankNum = 0;
                                    the_iBlankNum = 0;
                                    the_bSeriesBlankFlag = false;
                                    the_pCurLineAttr->m_lineno = the_iLineNum;
                                    the_pCurLineAttr->m_attr.EL = 1;
                                    the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                    if (the_bPreProcLineAttrFlag == false){
                                        the_pPreProcLineAttr = the_pCurLineAttr;
                                        the_bPreProcLineAttrFlag = true;
                                    }
                                    the_pLineHeadAddr = the_pFileCont;
                                }
                                /*�J�����g�s���v���v���Z�X�̈ꕔ�ł͂Ȃ�*/
                                else {
                                    the_iExecLOC++;
                                    the_pCurLineAttr->m_lineno = the_iLineNum;
                                    the_pCurLineAttr->m_attr.EL = 1;
                                    the_pCurLineAttr->m_attr.SL = 1;
                                    the_pCurLineAttr->m_attr1.BNUM = the_iTopBlankNum;
                                    the_pCurLineAttr->m_attr1.BFLAG = 1;
                                    the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                    the_iTopBlankNum = 0;
                                    the_iBlankNum = 0;
                                    the_bSeriesBlankFlag = false;
                                    the_pLineHeadAddr = the_pFileCont;
                                }
                                the_bC_ComtFlag1 = false;
                                the_bC_ComtFlag2 = false;
                                break;
                            }
                            break;
                        }
                        /*�J�����g�s���A���s�����݂̂�����s�ł���*/
                        else {
                            if (*(the_pFileCont - (2+the_iSeriesBlankNum)) == '\\'){
                                if (*(the_pFileCont - (3+the_iSeriesBlankNum+the_iPrevSeriesBlankNum)) == '\0'
                                    || (the_pFileCont - (2+the_iSeriesBlankNum+the_iPrevSeriesBlankNum)) == the_pFileHeadAddr){
                                    the_iPrevSeriesBlankNum = 0;
                                    the_iSeriesBlankNum = 0;
                                    the_iComtNum = 0;
                                    /*�J�����g�s���v���v���Z�X�̈ꕔ�ł���*/
                                    if (the_bPreprocFlag == true){
                                        the_iContPreprocLineNum++;
                                        the_iTopBlankNum = 0;
                                        the_iBlankNum = 0;
                                        the_bSeriesBlankFlag = false;
                                        the_pCurLineAttr->m_lineno = the_iLineNum;
                                        the_pCurLineAttr->m_attr.BL = 1;
                                        the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                        if (the_bPreProcLineAttrFlag == false){
                                            the_pPreProcLineAttr = the_pCurLineAttr;
                                            the_bPreProcLineAttrFlag = true;
                                        }
                                        the_pLineHeadAddr = the_pFileCont;
                                    }
                                    /*�J�����g�s���v���v���Z�X�̈ꕔ�ł͂Ȃ�*/
                                    else {
                                        the_iBlankLOC++;
                                        the_pCurLineAttr->m_lineno = the_iLineNum;
                                        the_pCurLineAttr->m_attr.BL = 1;
                                        the_pCurLineAttr->m_attr.SL = 1;
                                        the_pCurLineAttr->m_attr1.BNUM = the_iTopBlankNum;
                                        the_pCurLineAttr->m_attr1.BFLAG = 1;
                                        the_iTopBlankNum = 0;
                                        the_iBlankNum = 0;
                                        the_bSeriesBlankFlag = false;
                                        the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                        the_pLineHeadAddr = the_pFileCont;
                                    }
                                    the_bC_ComtFlag1 = false;
                                    the_bC_ComtFlag2 = false;
                                    break;
                                }
                                /*�J�����g�s�����s�s�ƘA���s����������s�ł���*/
                                else {
                                    the_iPrevSeriesBlankNum = 0;
                                    the_iSeriesBlankNum = 0;
                                    the_iComtNum = 0;
                                    /*�J�����g�s���v���v���Z�X�̈ꕔ�ł���*/
                                    if (the_bPreprocFlag == true){
                                        the_iContPreprocLineNum++;
                                        the_iTopBlankNum = 0;
                                        the_iBlankNum = 0;
                                        the_bSeriesBlankFlag = 0;
                                        the_pCurLineAttr->m_lineno = the_iLineNum;
                                        the_pCurLineAttr->m_attr.EL = 1;
                                        the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                        if (the_bPreProcLineAttrFlag == false){
                                            the_pPreProcLineAttr = the_pCurLineAttr;
                                            the_bPreProcLineAttrFlag = true;
                                        }
                                        the_pLineHeadAddr = the_pFileCont;
                                    }
                                    /*�J�����g�s���v���v���Z�X�̈ꕔ�ł͂Ȃ�*/
                                    else {
                                        the_iExecLOC++;
                                        the_pCurLineAttr->m_lineno = the_iLineNum;
                                        the_pCurLineAttr->m_attr.EL = 1;
                                        the_pCurLineAttr->m_attr.SL = 1;
                                        the_pCurLineAttr->m_attr1.BNUM = the_iTopBlankNum;
                                        the_pCurLineAttr->m_attr1.BFLAG = 1;
                                        if (the_bC_ComtFlag1 == true || the_bC_ComtFlag2 == true){
                                            the_pCurLineAttr->m_attr1.OEC = 1;
                                        }
                                        the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                        the_iTopBlankNum = 0;
                                        the_iBlankNum = 0;
                                        the_bSeriesBlankFlag = false;
                                        the_pLineHeadAddr = the_pFileCont;
                                    }
                                    the_bC_ComtFlag1 = false;
                                    the_bC_ComtFlag2 = false;
                                    break;
                                }
                                break;
                            }
                            /*�J�����g�s�����s�s�ł���*/
                            else {
                                the_iPrevSeriesBlankNum = 0;
                                the_iSeriesBlankNum = 0;
                                the_iComtNum = 0;
                                /*�J�����g�s���v���v���Z�X�s�ł���*/
                                if (the_bPreprocFlag == true){
                                    the_iContPreprocLineNum++;
                                    the_iTopBlankNum = 0;
                                    the_iBlankNum = 0;
                                    the_bSeriesBlankFlag = false;
                                    the_pCurLineAttr->m_lineno = the_iLineNum;
                                    the_pCurLineAttr->m_attr.EL = 1;
                                    the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                    if (the_bPreProcLineAttrFlag == false){
                                        the_pPreProcLineAttr = the_pCurLineAttr;
                                        the_bPreProcLineAttrFlag = true;
                                    }
                                    the_pLineHeadAddr = the_pFileCont;
                                    SET_PREPROCESS_ATTR();
                                    memset(the_szPreprocCont,0,MAX_PRECONT);
                                    the_pPreprocCont = the_szPreprocCont;
                                    the_iContPreprocLineNum = 0;
                                    the_bPreprocFlag = false;
                                    the_bPreProcLineAttrFlag = false;
                                    the_pPreProcLineAttr = NULL;
                                }
                                /*�J�����g�s���v���v���Z�X�̈ꕔ�ł͂Ȃ�*/
                                else {
                                    the_iExecLOC++;
                                    the_pCurLineAttr->m_lineno = the_iLineNum;
                                    the_pCurLineAttr->m_attr.EL = 1;
                                    the_pCurLineAttr->m_attr1.BNUM = the_iTopBlankNum;
                                    the_pCurLineAttr->m_attr1.BNUM = the_iTopBlankNum;
                                    if (the_bSeriesBlankFlag == true                        ||
                                       *(the_pFileCont - (2 + the_iSeriesBlankNum)) == '\\' ||
                                       *(the_pFileCont - 2 ) == ' '                         ||
                                        *(the_pFileCont - 2 ) == '\t'){
                                        the_pCurLineAttr->m_attr1.BFLAG = 1;
                                    }
                                    the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                                    if (the_bC_ComtFlag1 == true ||
                                        the_bC_ComtFlag2 == true){
                                        the_pCurLineAttr->m_attr1.OEC = 1;
                                    }
                                    the_iTopBlankNum = 0;
                                    the_iBlankNum = 0;
                                    the_bSeriesBlankFlag = false;
                                    the_pLineHeadAddr = the_pFileCont;
                                }
                                the_bC_ComtFlag1 = false;
                                the_bC_ComtFlag2 = false;
                                break;
                            }
                            break;
                        }
                        break;
                }
                break;
            default:
                if (the_bPreprocFlag == true && the_bDefFlag == false){
					if (strlen(the_szPreprocCont) >= MAX_PRECONT){
						the_iRet = ANZ_UNKNOWN_ERROR;
							goto ERR;
					}
                    *the_pPreprocCont++ = the_cCurChar;
                    if (strlen(the_cDefStr) > 0 && the_cCurChar == '\\'){
                        if (strcmp(the_cDefStr,"define") == 0){
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                            memset(the_szPreprocCont,0,MAX_PRECONT);
                            the_pPreprocCont = the_szPreprocCont;
                            the_bDefFlag = true;
                            if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1] != 0 &&
                                the_iIfFlag != 0){
                                if (g_iPreprocValue[g_iIfNum - 1 ][strlen(g_iPreprocValue[g_iIfNum - 1 ]) - 1]  == 1
                                    && the_iIfFlag == 1){
                                    the_iIfFlag = 0;
                                }
                            }
                            else {
                                the_iIfFlag = 0;
                                if (g_iIfNum <= 0 ){
                                    the_iIfErrLine = 0;
                                }
                            }
                        }
                        else {
                            memset(the_cDefStr,0,MAX_DEFINFE_STR);
                            the_cTempDefStr = the_cDefStr;
                        }
                        the_bDefFlag1 = true;
                    }
                    else {
                        if (the_bDefFlag1 == false){
							if (strlen(the_cDefStr) >= MAX_DEFINFE_STR ){
								memset(the_cDefStr,0,MAX_DEFINFE_STR);
								the_cTempDefStr = the_cDefStr;
								the_bDefFlag1 = true;
							}
							else {
								*the_cTempDefStr++ = the_cCurChar;
							}
                        }
                    }
                }
                the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                the_iSeriesBlankNum = 0;
                the_iComtNum = 0;
                break;
            }
            break;
            /*�J�����g��Ԃ�'�����Ȃ���Ԃł���*/
      case CHARLITERAL:
          /*'�����Ȃ�*/
          if (the_bPreprocFlag == true && the_bDefFlag == false){
			  if (strlen(the_szPreprocCont) >= MAX_PRECONT){
				  the_iRet = ANZ_UNKNOWN_ERROR;
					  goto ERR;
			  }
              *the_pPreprocCont++ = the_cCurChar;
          }
          if ((the_iCharNum == MAX_CHARLITERAL_SIZE &&
              the_cCurChar != '\'') ||
              the_cCurChar == '\n'){
              ADD_TO_ERROR_LIST();
              strcpy(the_pErrInfo->m_errFileName,in_pFileInfo->m_fileName);
              the_pErrInfo->m_errType = ANZ_CHARLITERAL_NO_CLOSED;
              the_pErrInfo->m_lineno = the_iCharErrLine;
              *io_iErrFlag = 1;
              the_iRet = ANZ_CHARLITERAL_NO_CLOSED;
              goto ERR;
          }
          /*�J�����g������'\'�ł���*/
          else if (the_cCurChar == '\''){
              if (*(the_pFileCont - 2) == '\\' && *(the_pFileCont - 3) != '\\'){
                  the_iCharNum++;
                  break;
              }
              else {
                  the_iCharNum = 0;
                  the_iCharErrLine = 0;
                  state = NORMAL;
                  break;
              }
          } else {
              the_iCharNum++;
          }
          break;
          /*�J�����g��Ԃ�""�̏�Ԃł���*/

      case STRINGLITERAL:
          /*�J�����g�������S�p�����ł���*/
          if (the_bPreprocFlag == true && the_bDefFlag == false){
              if (the_cCurChar != '\r'){
				  if (strlen(the_szPreprocCont) >= MAX_PRECONT){
					  the_iRet = ANZ_UNKNOWN_ERROR;
						  goto ERR;
				  }
                  *the_pPreprocCont++ = the_cCurChar;
              }
          }
          switch (the_cCurChar){
              /*�J�����g������"�ł���*/
          case '"':
              if (my_iskanji((unsigned char)*(the_pFileCont - 3))){
                  the_iStrErrLine = 0;
                  state = NORMAL;
                  break;
              }
            /*�J�����g�������ŊO��"�ł���*/
              if (*(the_pFileCont - 2) == '\\' && *(the_pFileCont - 3) != '\\'){
                  break;
              }
            the_iStrErrLine = 0;
            state = NORMAL;
              break;
          case '\r':
              *(the_pFileCont - 1) = '\0';
              the_iSeriesBlankNum++;
              break;
          case '\n':
              *(the_pFileCont - 1) = '\0';
              the_iLineNum++;
              ADD_TO_LINEATTR_LIST();
              /*�J�����g�s��#if�őI������Ȃ������ł���*/
              if (the_iIfFlag == 2 && strlen(the_szPreprocCont) == 0){
                  the_iPrevSeriesBlankNum = 0;
                  the_iSeriesBlankNum = 0;
                  the_iComtLOC++;
                  the_iTopBlankNum = 0;
                  the_iBlankNum = 0;
                  the_bSeriesBlankFlag = false;
                  the_pCurLineAttr->m_lineno = the_iLineNum;
                  the_pCurLineAttr->m_attr.CL = 1;
                  the_pCurLineAttr->m_attr1.IFL = 1;
                  the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                  the_pLineHeadAddr = the_pFileCont;
                  the_bC_ComtFlag1 = false;
                  the_bC_ComtFlag2 = false;
                  break;
              }
              /*�J�����g�s��#if�őI������Ȃ������ł͂Ȃ�*/
              else {
                  /*�J�����g�����s�s�ƘA���s����������s�ł���*/
                  if ( *(the_pFileCont - 2 - the_iSeriesBlankNum) == '\\'){
                      the_iPrevSeriesBlankNum = 0;
                      the_iSeriesBlankNum = 0;
                      /*�J�����g�s���v���v���Z�X�̈ꕔ�ł���*/
                      if (the_bPreprocFlag == true){
                          the_iContPreprocLineNum++;
                          the_iTopBlankNum = 0;
                          the_iBlankNum = 0;
                          the_bSeriesBlankFlag = false;
                          the_pCurLineAttr->m_lineno = the_iLineNum;
                          the_pCurLineAttr->m_attr.EL = 1;
                          the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                          if (the_bPreProcLineAttrFlag == false){
                              the_pPreProcLineAttr = the_pCurLineAttr;
                              the_bPreProcLineAttrFlag = true;
                          }
                          the_pLineHeadAddr = the_pFileCont;
                      }
                      /*�J�����g�s���v���v���Z�X�̈ꕔ�ł͂Ȃ�*/
                      else {
                          the_iExecLOC++;
                          the_pCurLineAttr->m_lineno = the_iLineNum;
                          the_pCurLineAttr->m_attr.EL = 1;
                          the_pCurLineAttr->m_attr.SL = 1;
                          the_pCurLineAttr->m_attr1.BNUM = the_iTopBlankNum;
                          the_pCurLineAttr->m_attr1.BFLAG = 1;
                          the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                          the_iTopBlankNum = 0;
                          the_iBlankNum = 0;
                          the_bSeriesBlankFlag = false;
                          the_pLineHeadAddr = the_pFileCont;
                      }
                      the_bC_ComtFlag1 = false;
                      the_bC_ComtFlag2 = false;
                      break;
                  }
                  /*""�����Ȃ�*/
                  else {
                      ADD_TO_ERROR_LIST();
                      strcpy(the_pErrInfo->m_errFileName,in_pFileInfo->m_fileName);
                      the_pErrInfo->m_errType = ANZ_STRINGLITERAL_N0_CLOSED;
                      the_pErrInfo->m_lineno = the_iStrErrLine;
                      *io_iErrFlag = 1;
                      the_iRet = ANZ_STRINGLITERAL_N0_CLOSED;
                      goto ERR;
                  }
                  break;
              }
              break;
          default:
              break;
          }
          break;
          /*�J�����g��Ԃ�"//"�ŃR�����g�����Ԃł���*/

          case CC_COMMENT:
              switch (the_cCurChar){
              case '\r':
                  *(the_pFileCont - 1) = '\0';
                  break;
              case '\n':
                  *(the_pFileCont -1 ) = '\0';
                  the_iLineNum++;
                  /*�J�����g�s���v���v���Z�X�s�ł���*/
                  if (the_bPreprocFlag == true && strlen(the_szPreprocCont) > 0
                      && *(the_pPreprocCont - (1 + the_iSeriesBlankNum)) != '#'){
                      /*�v���v���Z�X�s�̓��e����͂���*/
                      the_iRet = CheckPreproc(io_pAnzInfo,the_szPreprocCont,
											  &the_iIfFlag,&the_iIfErrLine);
                      if (the_iRet != ANZ_SUCCESS){
                          goto ERR;
                      }
                  }
                  if (the_bPreprocFlag == true && strlen(the_szPreprocCont) > 0
                      && *(the_pPreprocCont - (1 + the_iSeriesBlankNum)) == '#'){
                      memset(the_szPreprocCont,0,MAX_PRECONT);
                      the_pPreprocCont = the_szPreprocCont;
                      if (the_iIfErrLine == the_iLineNum){
                          the_iIfErrLine = 0;
                      }
                      the_bPreprocFlag = false;
                  }

                    ADD_TO_LINEATTR_LIST()
                  /*�J�����g�s#if�őI������Ȃ������ł���*/
                  if (the_iIfFlag == 2 && strlen(the_szPreprocCont) == 0){
                      the_iComtLOC++;
                      the_iTopBlankNum = 0;
                      the_iBlankNum = 0;
                      the_bSeriesBlankFlag = false;
                      the_pCurLineAttr->m_lineno = the_iLineNum;
                      the_pCurLineAttr->m_attr.CL = 1;
                      the_pCurLineAttr->m_attr1.IFL = 1;
                      the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                      the_pLineHeadAddr = the_pFileCont;
                      state = NORMAL;
                      the_bC_ComtFlag1 = false;
                      the_bC_ComtFlag2 = false;
                      break;
                  }
                  /*�J�����g�s���R�����g�s�ł���*/
                  else if (the_bCC_ComtFlag == true){
                      /*�J�����g�s���v���v���Z�X�̈ꕔ�ł���*/
                      if (the_bPreprocFlag == true){
                          the_iContPreprocLineNum++;
                          the_iTopBlankNum = 0;
                          the_iBlankNum = 0;
                          the_bSeriesBlankFlag = false;
                          the_pCurLineAttr->m_lineno = the_iLineNum;
                          the_pCurLineAttr->m_attr.CL = 1;
                          the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                          if (the_bPreProcLineAttrFlag == false){
                              the_pPreProcLineAttr = the_pCurLineAttr;
                              the_bPreProcLineAttrFlag = true;
                          }
                          the_pLineHeadAddr = the_pFileCont;
                          SET_PREPROCESS_ATTR();
                          memset(the_szPreprocCont,0,MAX_PRECONT);
                          the_pPreprocCont = the_szPreprocCont;
                          the_iContPreprocLineNum = 0;
                          the_bPreprocFlag = false;
                          the_bPreProcLineAttrFlag = false;
                          the_pPreProcLineAttr = NULL;
                      }
                      /*�J�����g�s���v���v���Z�X�̈ꕔ�ł͂Ȃ�*/
                      else {
                          the_iComtLOC++;
                          the_pCurLineAttr->m_lineno = the_iLineNum;
                          the_pCurLineAttr->m_attr.CL = 1;
                          the_pCurLineAttr->m_attr1.BNUM = the_iTopBlankNum;
                          the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                          the_iTopBlankNum = 0;
                          the_iBlankNum = 0;
                          the_bSeriesBlankFlag = false;
                          the_pLineHeadAddr = the_pFileCont;
                      }
					  state = NORMAL;
                      the_bCC_ComtFlag = false;
                      the_bC_ComtFlag1 = false;
                      the_bC_ComtFlag2 = false;
                      break;
                  }
                  /*�J�����g�s�����s�����ƃR�����g�����̑g�ݍ��킹��s�ł���*/
                  else {
                      the_iPrevSeriesBlankNum = 0;
                      the_iSeriesBlankNum = 0;
                      /*�J�����g�s���v���v���Z�X�̈ꕔ�ł���*/
                      if (the_bPreprocFlag == true){
                          the_iContPreprocLineNum++;
                          the_iTopBlankNum = 0;
                          the_iBlankNum = 0;
                          the_bSeriesBlankFlag = false;
                          the_pCurLineAttr->m_lineno = the_iLineNum;
                          the_pCurLineAttr->m_attr.EL = 1;
                          the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                          if (the_bPreProcLineAttrFlag == false){
                              the_pPreProcLineAttr = the_pCurLineAttr;
                              the_bPreProcLineAttrFlag = true;
                          }
                          the_pLineHeadAddr = the_pFileCont;
                          SET_PREPROCESS_ATTR();
                          memset(the_szPreprocCont,0,MAX_PRECONT);
                          the_pPreprocCont = the_szPreprocCont;
                          the_iContPreprocLineNum = 0;
                          the_bPreprocFlag = false;
                          the_bPreProcLineAttrFlag = false;
                          the_pPreProcLineAttr = NULL;
                      }
                      /*�J�����g�s���v���v���Z�X�̈ꕔ�ł͂Ȃ�*/
                      else {
                          the_iExecLOC++;
                          the_pCurLineAttr->m_lineno = the_iLineNum;
                          the_pCurLineAttr->m_attr.EL = 1;
                          the_pCurLineAttr->m_attr1.BNUM = the_iTopBlankNum;
                          if (the_bSeriesBlankFlag == true){
                              the_pCurLineAttr->m_attr1.BFLAG = 1;
                          }
                          the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                          the_iTopBlankNum = 0;
                          the_iBlankNum = 0;
                          the_bSeriesBlankFlag = false;
                          the_pLineHeadAddr = the_pFileCont;
                      }
					  state = NORMAL;
                      the_bC_ComtFlag1 = false;
                      the_bC_ComtFlag2 = false;
                      break;
                  }
            default:
                break;
            }
            break;
            /*�J�����g��Ԃ�"/*"�ŃR�����g�����Ԃł���*/

      case C_COMMENT:
          /*�J�����g�������S�p�����ł���*/
          if (my_iskanji(the_cCurChar)){
              the_pFileCont += 2;
              break;
          }
          switch (the_cCurChar){
          case '*':
              /*�J�����g�����̎��������S�p�����ł���*/
              if (my_iskanji((unsigned char)*the_pFileCont)){
                  the_pFileCont += 2;
                  break;
              }
              /*�J�����g�����̎��������S�p�����ł͂Ȃ�*/
              else {
                  if (*the_pFileCont == '/'){
                      the_iComtNum = the_iComtNum + 2;
                      state = NORMAL;
                      the_pFileCont++;
                      the_iComtErrLine = 0;
                      break;
                  } else {
                      the_iComtNum++;
                      break;
                  }
              }
              break;
          case '\r':
              *(the_pFileCont - 1) = '\0';
              break;
          case '\n':
              /*�J�����g�s��#if�őI������Ȃ������ł���*/
              *(the_pFileCont - 1) = '\0';
              the_iLineNum++;
              ADD_TO_LINEATTR_LIST();
              if (the_iIfFlag == 2 && strlen(the_szPreprocCont) == 0){
                  the_iComtNum = 0;
                  the_iComtLOC++;
                  the_iTopBlankNum = 0;
                  the_iBlankNum = 0;
                  the_bSeriesBlankFlag = false;
                  the_pCurLineAttr->m_lineno = the_iLineNum;
                  the_pCurLineAttr->m_attr.CL = 1;
                  the_pCurLineAttr->m_attr1.IFL = 1;
                  the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                  the_pLineHeadAddr = the_pFileCont;
                  break;
              }
              /*�J�����g�s���R�����g�s�ł���*/
              else if (the_bC_ComtFlag1 == true || the_bC_ComtFlag2 == true){
                  the_iComtNum = 0;
                  /*�J�����g�s���v���v���Z�X�̈ꕔ�ł���*/
                  if (the_bPreprocFlag == true){
                      the_iContPreprocLineNum++;
                      the_iTopBlankNum = 0;
                      the_iBlankNum = 0;
                      the_bSeriesBlankFlag = false;
                      the_pCurLineAttr->m_lineno = the_iLineNum;
                      the_pCurLineAttr->m_attr.CL = 1;
                      the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                      if (the_bPreProcLineAttrFlag == false){
                          the_pPreProcLineAttr = the_pCurLineAttr;
                          the_bPreProcLineAttrFlag = true;
                      }
                      the_pLineHeadAddr = the_pFileCont;
                      break;
                  }
                  /*�J�����g�s���v���v���Z�X�̈ꕔ�ł͂Ȃ�*/
                  else {
                      the_iComtLOC++;
                      the_pCurLineAttr->m_lineno = the_iLineNum;
                      the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                      the_pCurLineAttr->m_attr.CL = 1;
                      the_pCurLineAttr->m_attr1.BNUM = the_iTopBlankNum;
                      the_iTopBlankNum = 0;
                      the_iBlankNum = 0;
                      the_bSeriesBlankFlag = false;
                      the_pLineHeadAddr = the_pFileCont;
                      break;
                  }
                  break;
              }
              /*�J�����g�s�����s�����ƃR�����g�̑g�ݍ��킹��s�ł���*/
              else {
                  the_iComtNum = 0;
                  /*�J�����g�s���v���v���Z�X�̈ꕔ�ł���*/
                  if (the_bPreprocFlag == true){
                      the_iContPreprocLineNum++;
                      the_pCurLineAttr->m_lineno = the_iLineNum;
                      the_pCurLineAttr->m_attr.EL = 1;
                      the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                      if (the_bPreProcLineAttrFlag == false){
                          the_pPreProcLineAttr = the_pCurLineAttr;
                          the_bPreProcLineAttrFlag = true;
                      }
                      the_pLineHeadAddr = the_pFileCont;
                  }
                  /*�J�����g�s���v���v���Z�X�̈ꕔ�ł͂Ȃ�*/
                  else {
                      the_iExecLOC++;
                      the_pCurLineAttr->m_lineno = the_iLineNum;
                      the_pCurLineAttr->m_attr.EL = 1;
                      the_pCurLineAttr->m_attr1.BNUM = the_iTopBlankNum;
                      if (the_bSeriesBlankFlag == true){
                          the_pCurLineAttr->m_attr1.BFLAG = 1;
                      }
                      the_pCurLineAttr->m_prow = the_pLineHeadAddr;
                  }
                      the_iTopBlankNum = 0;
                      the_iBlankNum = 0;
                      the_bSeriesBlankFlag = false;
                      the_pLineHeadAddr = the_pFileCont;
                      the_bC_ComtFlag2 = true;
                      break;
              }
              break;
          default:
              the_iComtNum++;
              break;
          }
          break;
        }
    } while(the_cCurChar != '\0');
    /*�v����ނ��擾����*/
   the_iRet = GetMeasureType(the_pOption,&the_iMeasureType);
   if (the_iRet != ANZ_SUCCESS){
      the_iRet = ANZ_ERROR;
      goto ERR;
   }
    the_pTempLineAttr = the_pHeadLineAttr;
    /*�ʏ�v��*/
    if (the_iMeasureType == ANZ_COMMON_MEASURE){
        AnzMalloc(in_pFileInfo->m_totalLOC,char**,sizeof(char*)*(the_iLineNum + 1));
        if (in_pFileInfo->m_totalLOC == NULL){
            the_iRet = ANZ_ERR_MEMORY_FAILED;
            goto ERR;
        }
        memset(in_pFileInfo->m_totalLOC,'\0',sizeof(char*)*(the_iLineNum + 1));
        AnzMalloc(in_pFileInfo->m_execLOC,char**,sizeof(char*)*(the_iExecLOC + 1));
        if (in_pFileInfo->m_execLOC == NULL){
            the_iRet = ANZ_ERR_MEMORY_FAILED;
            goto ERR;
        }
        memset(in_pFileInfo->m_execLOC,'\0',sizeof(char*)*(the_iExecLOC + 1));
        AnzMalloc(in_pFileInfo->m_comtLOC,char**,sizeof(char*)*(the_iComtLOC + 1));
        if (in_pFileInfo->m_comtLOC == NULL){
            the_iRet = ANZ_ERR_MEMORY_FAILED;
            goto ERR;
        }
        memset(in_pFileInfo->m_comtLOC,'\0',sizeof(char*)*(the_iComtLOC + 1));
        AnzMalloc(in_pFileInfo->m_blankLOC,char**,sizeof(char*)*(the_iBlankLOC + 1));

        if (in_pFileInfo->m_blankLOC == NULL){
            the_iRet = ANZ_ERR_MEMORY_FAILED;
            goto ERR;
        }
        memset(in_pFileInfo->m_blankLOC,'\0',sizeof(char*)*(the_iBlankLOC + 1));
        while(the_pTempLineAttr!= NULL){
            if (the_pTempLineAttr->m_attr1.IFL == 1){
                *(in_pFileInfo->m_comtLOC + the_iComtLOCNum) = the_pTempLineAttr->m_prow;
                the_iComtLOCNum++;
            }
            else if(the_pTempLineAttr->m_attr.BL == 1)
            {
                *(in_pFileInfo->m_blankLOC + the_iBlankLOCNum) = the_pTempLineAttr->m_prow;
                the_iBlankLOCNum++;
            }
            else if (the_pTempLineAttr->m_attr.CL == 1){
                *(in_pFileInfo->m_comtLOC + the_iComtLOCNum) = the_pTempLineAttr->m_prow;
                the_iComtLOCNum++;
            }
            else {
                *(in_pFileInfo->m_execLOC + the_iExecLOCNum) = the_pTempLineAttr->m_prow;
                the_iExecLOCNum++;
            }
            *(in_pFileInfo->m_totalLOC + the_iTotalLOCNum) = the_pTempLineAttr->m_prow;
            the_iTotalLOCNum++;
            the_pTempLineAttr = the_pTempLineAttr->m_next;
        }
        g_fileLOC->m_blankLOC = the_iBlankLOC;
        g_fileLOC->m_comtLOC = the_iComtLOC;
        g_fileLOC->m_execLOC = the_iExecLOC;
        g_fileLOC->m_totalLOC = the_iLineNum;
        in_pFileInfo->m_lineAttr = the_pHeadLineAttr;

    }
    /*�����v��*/
    else {
        /*�J�����g�t�@�C�����V�ł̃t�@�C���ł���*/
        if (in_iVerFlag == ANZ_NV_FILE){
            AnzMalloc(in_pFileInfo->m_totalLOC,char**,sizeof(char*)*(the_iLineNum + 1));
            if (in_pFileInfo->m_totalLOC == NULL){
                the_iRet = ANZ_ERR_MEMORY_FAILED;
                goto ERR;
            }
            memset(in_pFileInfo->m_totalLOC,'\0',sizeof(char*)*(the_iLineNum + 1));
            AnzMalloc(in_pFileInfo->m_execLOC,char**,sizeof(char*)*(the_iExecLOC + 1));
            if (in_pFileInfo->m_execLOC == NULL){
                the_iRet = ANZ_ERR_MEMORY_FAILED;
                goto ERR;
            }
            memset(in_pFileInfo->m_execLOC,'\0',sizeof(char*)*(the_iExecLOC + 1));
            AnzMalloc(in_pFileInfo->m_comtLOC,char**,sizeof(char*)*(the_iComtLOC + 1));
            if (in_pFileInfo->m_comtLOC == NULL){
                the_iRet = ANZ_ERR_MEMORY_FAILED;
                goto ERR;
            }
            memset(in_pFileInfo->m_comtLOC,'\0',sizeof(char*)*(the_iComtLOC + 1));
            AnzMalloc(in_pFileInfo->m_blankLOC,char**,sizeof(char*)*(the_iBlankLOC + 1));
            if (in_pFileInfo->m_blankLOC == NULL){
                the_iRet = ANZ_ERR_MEMORY_FAILED;
                goto ERR;
            }
            memset(in_pFileInfo->m_blankLOC,'\0',sizeof(char*)*(the_iBlankLOC + 1));
            while(the_pTempLineAttr!= NULL){
                if (the_pTempLineAttr->m_attr1.IFL == 1){
                    *(in_pFileInfo->m_comtLOC + the_iComtLOCNum) = the_pTempLineAttr->m_prow;
                    the_iComtLOCNum++;
                }
                else if(the_pTempLineAttr->m_attr.BL == 1)
                {
                    *(in_pFileInfo->m_blankLOC + the_iBlankLOCNum) = the_pTempLineAttr->m_prow;
                    the_iBlankLOCNum++;
                }
                else if (the_pTempLineAttr->m_attr.CL == 1){
                    *(in_pFileInfo->m_comtLOC + the_iComtLOCNum) = the_pTempLineAttr->m_prow;
                    the_iComtLOCNum++;
                }
                else {
                    *(in_pFileInfo->m_execLOC + the_iExecLOCNum) = the_pTempLineAttr->m_prow;
                    the_iExecLOCNum++;
                }
                *(in_pFileInfo->m_totalLOC + the_iTotalLOCNum) = the_pTempLineAttr->m_prow;
                the_iTotalLOCNum++;
                the_pTempLineAttr = the_pTempLineAttr->m_next;
            }
            if(the_pOption->m_trend == ON){
                g_fileTrend1->m_nv_blankLOC = the_iBlankLOC;
                g_fileTrend1->m_nv_comtLOC = the_iComtLOC;
                g_fileTrend1->m_nv_execLOC = the_iExecLOC;
                g_fileTrend1->m_nv_totalLOC = the_iLineNum;
            }
            in_pFileInfo->m_lineAttr = the_pHeadLineAttr;
        }
        /*�J�����g�t�@�C�������ł̃t�@�C���ł���*/
        else {
            AnzMalloc(in_pFileInfo->m_ov_TotalLOC,char**,sizeof(char*)*(the_iLineNum + 1));
            if ( in_pFileInfo->m_ov_TotalLOC == NULL){
                the_iRet = ANZ_ERR_MEMORY_FAILED;
                goto ERR;
            }
            memset(in_pFileInfo->m_ov_TotalLOC,'\0',sizeof(char*)*(the_iLineNum + 1));
            AnzMalloc(in_pFileInfo->m_ov_ExecLOC,char**,sizeof(char*)*(the_iExecLOC + 1));
            if (in_pFileInfo->m_ov_ExecLOC == NULL){
                the_iRet = ANZ_ERR_MEMORY_FAILED;
                goto ERR;
            }
            memset(in_pFileInfo->m_ov_ExecLOC,'\0',sizeof(char*)*(the_iExecLOC + 1));
            AnzMalloc(in_pFileInfo->m_ov_ComtLOC,char**,sizeof(char*)*(the_iComtLOC + 1));
            if (in_pFileInfo->m_ov_ComtLOC == NULL){
                the_iRet = ANZ_ERR_MEMORY_FAILED;
                goto ERR;
            }
            memset(in_pFileInfo->m_ov_ComtLOC,'\0',sizeof(char*)*(the_iComtLOC + 1));
            AnzMalloc(in_pFileInfo->m_ov_BlankLOC,char**,sizeof(char*)*(the_iBlankLOC + 1));
            if (in_pFileInfo->m_ov_BlankLOC == NULL){
                the_iRet = ANZ_ERR_MEMORY_FAILED;
                goto ERR;
            }
            memset(in_pFileInfo->m_ov_BlankLOC,'\0',sizeof(char*)*(the_iBlankLOC + 1));
            while(the_pTempLineAttr!= NULL){
                if (the_pTempLineAttr->m_attr1.IFL == 1){
                    *(in_pFileInfo->m_ov_ComtLOC + the_iComtLOCNum) = the_pTempLineAttr->m_prow;
                    the_iComtLOCNum++;
                }
                else if(the_pTempLineAttr->m_attr.BL == 1)
                {
                    *(in_pFileInfo->m_ov_BlankLOC + the_iBlankLOCNum) = the_pTempLineAttr->m_prow;
                    the_iBlankLOCNum++;
                }
                else if (the_pTempLineAttr->m_attr.CL == 1){
                    *(in_pFileInfo->m_ov_ComtLOC + the_iComtLOCNum) = the_pTempLineAttr->m_prow;
                    the_iComtLOCNum++;
                }
                else {
                    *(in_pFileInfo->m_ov_ExecLOC + the_iExecLOCNum) = the_pTempLineAttr->m_prow;
                    the_iExecLOCNum++;
                }
                *(in_pFileInfo->m_ov_TotalLOC + the_iTotalLOCNum) = the_pTempLineAttr->m_prow;
                the_iTotalLOCNum++;
                the_pTempLineAttr = the_pTempLineAttr->m_next;
            }
            if(the_pOption->m_trend == ON){
                g_fileTrend1->m_ov_blankLOC = the_iBlankLOC;
                g_fileTrend1->m_ov_comtLOC = the_iComtLOC;
                g_fileTrend1->m_ov_execLOC = the_iExecLOC;
                g_fileTrend1->m_ov_totalLOC = the_iLineNum;
            }
            in_pFileInfo->m_ov_LineAttr = the_pHeadLineAttr;
        }
    }
ERR:
    /* ������"\"�ł͂Ȃ��ꍇ�Ag_szNVPath�̌��"\"��ǉ����� */
    if(in_iVerFlag == ANZ_NV_FILE ){
        if(strcmp(g_szNVPath,"") != 0){
            the_cCurChar = *(g_szNVPath + strlen(g_szNVPath) - 1);
#ifdef __GNUC__
            if(the_cCurChar != '/'){
                strcat(g_szNVPath,"/");
            }
#else
            if(the_cCurChar != '\\'){
                strcat(g_szNVPath,"\\");
            }
#endif
        }
        memset(the_szFileName,'\0',MAX_PATH);
        strcat(the_szFileName,g_szNVPath);
        strcat(the_szFileName,in_pFileInfo->m_fileName);
    }
                /* ������"\"�ł͂Ȃ��ꍇ�Ag_szNVPath�̌��"\"��ǉ����� */
    if(in_iVerFlag == ANZ_OV_FILE ) {
        if(strcmp(g_szOVPath,"") != 0){
            the_cCurChar = *(g_szOVPath + strlen(g_szOVPath) - 1);
#ifdef __GNUC__
            if(the_cCurChar != '/'){
                strcat(g_szOVPath,"/");
            }
#else
            if(the_cCurChar != '\\'){
                strcat(g_szOVPath,"\\");
            }
#endif
        }
        memset(the_szFileName,'\0',MAX_PATH);
        strcat(the_szFileName,g_szOVPath);
        strcat(the_szFileName,in_pFileInfo->m_fileName);
    }
    if(in_iVerFlag == ANZ_CM_FILE ){
		memset(the_szFileName,'\0',MAX_PATH);
        strcat(the_szFileName,in_pFileInfo->m_fileName);
	}
    switch(the_iRet){
        /*�R�����g�u/*�v�����Ȃ�*/
    case ANZ_COMT_NO_CLOSED:
        printf("%s,%s,%d\n",MSG_COMT_NO_CLOSED,
			the_szFileName,the_iComtErrLine);
        break;
        /*�_�u���N�H�[�e�[�V�������}�b�`���Ă��܂���*/
    case ANZ_STRINGLITERAL_N0_CLOSED:
        printf("%s,%s,%d\n",MSG_STRINGLITERAL_NO_CLOSED,
			the_szFileName,the_iStrErrLine);
        break;
        /*#if�̌�ɁA�Ή����Ă���#endif�������ł���*/
    case ANZ_PREPRC_NO_CLOSED:
        printf("%s,%s,%d\n",MSG_PREPRC_NO_CLOSED,
			the_szFileName,the_iIfErrLine);
        break;
        /*�V���O���N�H�[�e�[�V�������}�b�`���Ă��܂���*/
    case ANZ_CHARLITERAL_NO_CLOSED:
        printf("%s,%s,%d\n",MSG_CHARLITERAL_NO_CLOSED,
			the_szFileName,the_iCharErrLine);
        break;
        /*�S�p�����̎g�p���s���ł�*/
    case ANZ_KANJI_ERROR:
        printf("%s,%s,%d\n",MSG_KANJI_ERROR,
			the_szFileName,the_pErrInfo->m_lineno);
        break;
        /*���������蓖�Ă����s���܂���*/
    case ANZ_ERR_MEMORY_FAILED:
        printf("%s\n",MSG_MOMORY_FAILED);
        break;
		/*�s���ȃG���[���������܂���*/
	case ANZ_UNKNOWN_ERROR:
		ADD_TO_ERROR_LIST();
		strcpy(the_pErrInfo->m_errFileName,in_pFileInfo->m_fileName);
		the_pErrInfo->m_errType = ANZ_UNKNOWN_ERROR;
		the_pErrInfo->m_lineno = the_iLineNum + 1;
		*io_iErrFlag = 1;
		printf("%s,%s,%d\n",MSG_UNKNOWN_ERROR,
			the_szFileName,the_pErrInfo->m_lineno);
		break;
    default:
        break;
    }
    return the_iRet;
}
