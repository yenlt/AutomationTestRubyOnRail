/*
 File:
    preprocess2.c
 Copyright:
    Copyright (C) 2004 TOSHIBA CORPORATION. All Rights Reserved.
 Product:
    AnalyzeMe
 Abstract:
    �v���O�K�v�ȏ������s��
 Author:
    tong-huixin
 Date:
    2004/08/15
 REVISION HISTORY:
    2004/08/18        tong-huixin      1st Revision�@
*/

/*
    $AnalyzeMe 1.0.0.1$
*/

#include "common.h"
#include "output.h"
#include "get_process_macro.h"
#include "preprocess1.h"
#include "preprocess2.h"


#define ISIDENT(c) ((c) == ' ' || (c) == '\t' || (c) == '\0')

extern ST_FileMetrics *g_fileMetrics; /* file_metrics.csv */
extern ST_FuncMetrics *g_funcMetrics;   /* func_metrics.csv */
extern ST_Error *g_pErrLstHead;        /*Error List��Head Node��Point*/
extern ST_Error *g_pErrLstPrev;        /*�ONode��Point*/
extern ST_FileTrend2  *g_fileTrend2;  /* file_trend2.csv */
extern char g_szNVPath[MAX_PATH];
extern char g_szOVPath[MAX_PATH];

extern ST_ProcMacro **g_pProcMacro;
extern ST_ProcMacro **g_pOVProcMacro;
extern int g_iProcMacroCount;
extern int g_iOVProcMacroCount;

/**
*  IdentifyMacabeKeyWord
*  MaCabe�v���p�\���𔻒f����
*  @param
*          in_keyStr        ���ʕK�v�ȕ�����
*          io_keyFlag       �ԋp�l
*  @return
*          �Ȃ�
*  @author tong-huixin
*/
void IdentifyMacabeKeyWord(const char *in_keyStr,int *io_keyFlag)
{
    if (strcmp(in_keyStr,"if") == 0){
        *io_keyFlag = 1;
        return;
    }
    if (strcmp(in_keyStr,"while") == 0){
        *io_keyFlag = 1;
        return;
    }
    if (strcmp(in_keyStr,"for") == 0){
        *io_keyFlag = 1;
        return;
    }
    if (strcmp(in_keyStr,"switch") == 0){
        *io_keyFlag = 1;
        return;
    }
    if (strcmp(in_keyStr,"case") == 0){
        *io_keyFlag = 1;
        return;
    }
    if (strcmp(in_keyStr,"do") == 0){
        *io_keyFlag = 2;
        return;
    }
    *io_keyFlag = 0;
}
/**
*  Preprocess2
*  �O����(2)���s��
*  @param
*          io_pAnzInfo          AnalyzeMe�Ǘ����
*          in_pFileInfo         �J�����g�v��File���
*          io_preFileLastFunc   �O�t�@�C���̍Ō�̊֐�����Node
*          in_iVerFlag          �J�����g�t�@�C���̔�
*          io_iErrFlag          �J�����g�v��File�ɃG���[�����邩�ǂ����̃t���O
*  @return
*          ANZ_SUCCESS ����I��
*          ANZ_ERROR   �ُ�I��
*  @author tong-huixin
*/
int Preprocess2(ST_AnalyzeMe *io_pAnzInfo,
				ST_MeasureFile *in_pFileInfo,
                ST_Func **io_preFileLastFunc,
				const int in_iVerFlag,
				int *io_iErrFlag)
{
    int the_iFuncEndLine = 0;           /* �J�����g�֐��ɍŌ�s�̍s�ԍ� */
    int the_iFuncNum = 0;               /* �J�����g�t�@�C���̊֐� */
    int the_iFileELOC = 0;              /* �J�����g�t�@�C���ɑS�Ċ֐���ELOC */
    int the_iMaxMcCabe = 0;             /* �J�����g�t�@�C���ɕ��G�x�̍��v */
    int the_iMccabe10 = 0;              /* �J�����g�t�@�C���ɕ��G�x��10�ȏ�̊֐��̌����v */
    int the_iRet = ANZ_SUCCESS;         /* Return�l */
    int the_iLoop1 = 0;                 /* LOOP�p */
    int the_iLoop2 = 0;                 /* LOOP�p */
    int the_iLoop3 = 0;                 /* LOOP�p */
    int the_iExecNum = 0;               /* ���s�s�̍s�� */
    int the_iMeasureType = 0;           /* �v����� */
    int the_iKeyFlag = 0;               /* �L�[���[�h�̃t���O */
    int the_iLineCharNum = 0;           /* ��s�̕����� */
    int the_iMccabe = 1;                /* �֐��̕��G�x */
    int the_iBigBrkNum = 0;             /* �劇�ʂ̐� */
    int the_iBracketNum = 0;            /* �����ʂ̐� */
    int the_iELOC = 0;                  /* �֐��̎��s�s�� */
    char the_szTempFuncName[MAX_FUNC];  /* �֐�����ێ�����ꎞ�z�� */
    char the_szFuncName[MAX_FUNC];      /* �֐��� */
    char the_szOldFuncName[MAX_FUNC];   /* �O�֐��̊֐��� */
    char the_szBuf[MAXLINE];            /* �󔒂��폜���A��s����̓��e */
    char *the_pTempFuncName = NULL;     /* the_szFuncName��Point */
    char *the_pTempBuf = NULL;          /* the_szBuf��Point */
    char *the_pTempPS = NULL;           /* �J�����g�s�̓��e */
    char the_szFileName[MAX_PATH] = {0};/* �J�����g�J��File�� */
    unsigned char the_cCurChar;         /* �J�����g����*/
    bool the_bBlankFlag = false;        /* �󔒃t���O*/
    bool the_bLastLineFlag = false;     /* File�̖��s�t���O*/
    bool the_bFuncFlag = false;         /* �֐��t���O*/
    bool the_bFuncStateFlag = false;    /* �֐��J�n�t���O*/
    bool the_bFuncELOCFlag = false;     /* �֐����s�s�t���O*/
    bool the_bLineAttrFlag = false;     /* �s�����t���O*/
    bool the_bTempFuncFlag = false;     /* �֐��ŊO��{��������t���O*/
    bool the_bComtFlag = false;         /* �R�����g�t���O*/
    bool the_bEnterFlag = false;        /* ���s�t���O*/
    bool the_bTrendFlag = false;        /* �������������񂪑S���Ő����̃}�[�N */
    bool the_bBracket = false;          /* �u���P�b�g�̃}�[�N */
    ST_Func *the_pHeadFunc= NULL;       /* �֐�List��Head Node��Point*/
    ST_Func *the_pPrevFunc = NULL;      /* �ONode��Point*/
    ST_Func *the_pCurFunc = NULL;       /* �J�����g�֐�Node*/
    ST_Func *the_pTempFunc = NULL;      /* �J�����gFile�̈�Ԗڊ֐�*/
    ST_Error *the_pErrInfo = NULL;      /* �J�����g�G���[����Node*/
    ST_LineAttr *the_pFuncStartLine = NULL;/*�֐��J�n�s*/
    ST_LineAttr *the_pTempLine1 = NULL; /*���s�̊J�n�s*/
    ST_LineAttr *the_pTempLine = NULL;  /*�J�����gFile�̊J�n�s*/
    enum {
            NORMAL,        /*NORMAL��Ԃ�\�� */
            C_COMMENT,     /*"/*"�R�����g��Ԃ�\�� */
            CC_COMMENT,    /* "//"�R�����g��Ԃ�\�� */
            STRINGLITERAL, /* �_�u���N�H�[�e�[�V������Ԃ�\�� */
            CHARLITERAL,   /* �V���O���N�H�[�e�[�V������Ԃ�\�� */
    }state = NORMAL;

    /* �ϐ������� */
    if(in_iVerFlag == ANZ_NV_FILE ||
        in_iVerFlag == ANZ_CM_FILE){
        the_pTempLine = in_pFileInfo->m_lineAttr;
    }
    else {
        the_pTempLine = in_pFileInfo->m_ov_LineAttr;
    }
    memset(the_szTempFuncName,0,MAX_FUNC);
    memset(the_szOldFuncName,0,MAX_FUNC);
    memset(the_szFuncName,0,MAX_FUNC);
    memset(the_szBuf,0,MAXLINE);
    the_pTempFuncName = the_szFuncName;
    the_pTempBuf = the_szBuf;
    while(the_pTempLine != NULL)
    {
        the_bBlankFlag = false;
            /* �J�����g�s�̓J�����g�t�@�C���̍Ō�s */
        if (the_pTempLine->m_next == NULL){
            the_bLastLineFlag = true;
        }
        /*�J�����g�s��#if�őI������Ȃ��������̓v���v���Z�X�s�ł���*/
        if (the_pTempLine->m_attr1.IFL == 1 || the_pTempLine->m_attr.PL == 1){
            the_pTempLine = the_pTempLine->m_next;
            continue;
        }

        /*�J�����g�s���p���s�̊J�n�s�ł���*/
        if (the_pTempLine1 == NULL){
            the_pTempLine1 = the_pTempLine;
            the_iExecNum = 0;
        }
        /* �J�����g�s��"/*"�R�����g�̌㕔�����s��̍s�Ƃ����� */
        if (the_pTempLine->m_attr1.OEC == 1){
            state = C_COMMENT;
        }

        /*�J�����g�s���󔒂̍폜�ƈ�s�����K�v��*/
        if(the_bLineAttrFlag == false && (the_pTempLine->m_attr1.BFLAG == 1
            || the_pTempLine->m_attr.SL == 1)){
            the_bLineAttrFlag = true;
            memset(the_szBuf,0,MAXLINE);
            the_pTempBuf = the_szBuf;
        }
        /*�s�擪�̋󔒕������폜����*/
        if(the_bLineAttrFlag == false && the_pTempLine->m_attr1.BNUM > 0){
            the_pTempLine->m_prow+= the_pTempLine->m_attr1.BNUM;
        }

        the_pTempPS = the_pTempLine->m_prow;

        /* �J�����g�s�͊֐��Ɋ܂܂�Ă��� */
        if (the_bFuncFlag == true){

            /*�p���s�̎��s�s*/
            if (the_pTempLine->m_attr.EL == 1){
                the_iExecNum++;
            }
            /*�֐����̎��s�s */
            if (the_bFuncELOCFlag == false && the_pTempLine->m_attr.EL == 1){
                the_pTempLine1->m_attr1.FEL = 1;
                the_iELOC++;
                the_bFuncELOCFlag = true;
            }

            /*�J�����g�s���֐������s�ł���A���s�s�ł͂Ȃ��A�G���[�����o�͂���*/
            if (the_bLastLineFlag == true && the_pTempLine->m_attr.EL != 1){
				ADD_TO_ERROR_LIST();
                strcpy(the_pErrInfo->m_errFileName,in_pFileInfo->m_fileName);
                the_pErrInfo->m_errType = ANZ_FUNC_NO_CLOSED;
                the_pErrInfo->m_lineno = the_pFuncStartLine->m_lineno;
                *io_iErrFlag = 1;
                the_iRet = ANZ_FUNC_NO_CLOSED;
                goto ERR;
            }
        }
        /*�J�����g�s����������*/
        do{
            the_cCurChar = *the_pTempPS++;
            the_iLoop1++;
            /*�J�����g�������S�p�̕����ł��邩�A���p�̕����ł��邩*/
            if (state != NORMAL &&
                state != CHARLITERAL){
                if ( my_iskanji(the_cCurChar)){
                    if ( the_bLineAttrFlag == true ){
                        *the_pTempBuf++ = the_cCurChar;
                        *the_pTempBuf++ = *the_pTempPS;
                        the_pTempPS++;
                        continue;
                    }
                    else {
                        the_pTempPS++;
                        continue;
                    }
                }
            }
            switch(state)
            {
            case NORMAL:
                /*�֐��̍ŊO�̑劇�ʂ�������Ƃ��̑劇�ʍs�̏���*/
                if ( the_bTempFuncFlag == true ){
                    if ( !ISIDENT(the_cCurChar)){
                        if( the_cCurChar == '}'){
                            the_bTempFuncFlag = false;
                            the_bFuncELOCFlag = false;
                        }
                    else if ( the_cCurChar == '/'){
                        if ((*the_pTempPS) != '/' && (*the_pTempPS) != '*'){
                            the_iLoop3++;
                        }
                    }
                    else if (the_cCurChar == '\\'){
                        the_iLoop2++;
                    }
                    else {
                        the_iLoop3++;
                    }

                    if ( the_iLoop2 > 1 || the_iLoop3 > 0 ){
                        the_pTempLine1->m_attr1.FEL = 1;
                        the_iELOC++;
                        the_bTempFuncFlag = false;
                        the_bFuncELOCFlag = true;
                        the_iLoop3 = 0;
                        the_iLoop2 = 0;
                        }
                    }
                }
                /*NORMAL�̏�ԂŃJ�����g�s�̓��e����������*/
                switch(the_cCurChar)
                {
                case '\'':
                    if (the_bLineAttrFlag == true){
                        *the_pTempBuf++ = the_cCurChar;
                    }
                    state = CHARLITERAL;
                    break;
                case '"':
                    if (the_bLineAttrFlag == true){
                        *the_pTempBuf++ = the_cCurChar;
                    }
                    state = STRINGLITERAL;
                    break;
                case ' ':
                    if(the_bLineAttrFlag == true && (*(the_pTempBuf - 1)) != ' '){
                        *the_pTempBuf++ = the_cCurChar;
                    }
                    if ((strlen(the_szFuncName)) > 0 && *(the_pTempFuncName -1 ) != ')'
                        && the_bBracket == false){
                        IdentifyMacabeKeyWord(the_szFuncName,&the_iKeyFlag);
                        if (the_iKeyFlag != 0){
                            if (the_iKeyFlag == 1 && the_bFuncFlag == true){
                                the_iMccabe++;
                            }
                            if (strlen(the_szTempFuncName) > 0){
                                memset(the_szTempFuncName,0,MAX_FUNC);
                            }
                            memset(the_szFuncName,0,MAX_FUNC);
                            the_pTempFuncName = the_szFuncName;

                        }
                        else {
                            if (the_bBlankFlag == false){
                                the_bBlankFlag = true;
                            }
                        }
                    }
                    break;
                case '\t':
                    if(the_bLineAttrFlag == true && (*(the_pTempBuf - 1)) != ' '){
                        *the_pTempBuf++ = ' ';
                    }
                    if ((strlen(the_szFuncName)) > 0 && *(the_pTempFuncName -1 ) != ')'
                        && the_bBracket == false){
                        IdentifyMacabeKeyWord(the_szFuncName,&the_iKeyFlag);
                        if (the_iKeyFlag != 0){
                            if (the_iKeyFlag == 1 && the_bFuncFlag == true){
                                the_iMccabe++;
                            }
                            if (strlen(the_szTempFuncName) > 0){
                                memset(the_szTempFuncName,0,MAX_FUNC);
                            }
                            memset(the_szFuncName,0,MAX_FUNC);
                            the_pTempFuncName = the_szFuncName;

                        }
                        else {
                            if (the_bBlankFlag == false){
                                the_bBlankFlag = true;
                            }
                        }
                    }
                    break;
                case ';':
                    if (the_bLineAttrFlag == true){
                        *the_pTempBuf++ = the_cCurChar;
                    }
                    if((strlen(the_szFuncName)) > 0 && the_bEnterFlag == false){
                        memset(the_szFuncName,0,MAX_FUNC);
                        the_pTempFuncName = the_szFuncName;
                    }
                    break;
                case '(':
                    if (the_bLineAttrFlag == true){
                        *the_pTempBuf++ = the_cCurChar;
                    }

                    if ( (strlen(the_szFuncName)) > 0 && (*(the_pTempFuncName - 1)) != ')'
                        && the_bBracket == false){
                        /* �擾�����t�B�[���h���L�[�̏ꍇ */
                        IdentifyMacabeKeyWord(the_szFuncName,&the_iKeyFlag);
                        if (the_iKeyFlag != 0){
                            if (the_iKeyFlag == 1 && the_bFuncFlag == true){
                                the_iMccabe++;
                            }
                            if (strlen(the_szTempFuncName) > 0){
                                memset(the_szTempFuncName,0,MAX_FUNC);
                            }
                            memset(the_szFuncName,0,MAX_FUNC);
                            the_pTempFuncName = the_szFuncName;
                        }
                        /* �擾�����t�B�[���h���L�[�ł͂Ȃ��ꍇ */
                        else {
                            /* �J�����g�t�@�C���͐V�����ł̏ꍇ */
                            if(in_iVerFlag == ANZ_NV_FILE ||
                                in_iVerFlag == ANZ_CM_FILE){
                                /* �擾�����t�B�[���h����`�����}�N�� */
                                if (IsFoundInProcMacro(g_pProcMacro,the_szFuncName,g_iProcMacroCount)){
                                    if (the_bFuncFlag == true){
                                        memset(the_szFuncName,0,MAX_FUNC);
                                        if (strlen(the_szTempFuncName) > 0){
                                            memset(the_szTempFuncName,0,MAX_FUNC);
                                        }
                                        the_pTempFuncName = the_szFuncName;
                                    }
                                }
                            }
                            /* �J�����g�t�@�C���͌Â��ł̏ꍇ */
                            else {
                                /* �擾�����t�B�[���h����`�����}�N�� */
                                if (IsFoundInProcMacro(g_pOVProcMacro,the_szFuncName,g_iOVProcMacroCount)){
                                    if (the_bFuncFlag == true){
                                        memset(the_szFuncName,0,MAX_FUNC);
                                        the_pTempFuncName = the_szFuncName;
                                    }
                                }
                            }
                            if(strlen(the_szFuncName) > 0){
								if (strlen(the_szFuncName) >= MAX_FUNC){
									the_iRet = ANZ_UNKNOWN_ERROR;
									goto ERR;
								}
                                *the_pTempFuncName++ = the_cCurChar;
                            }
                            if (the_bBlankFlag == true){
                                the_bBlankFlag = false;
                            }
                        }
                    }
                    if ((strlen(the_szFuncName)) > 0 && (*(the_pTempFuncName - 1)) == ')'
                        && the_bBracket == false){
                        the_bEnterFlag = true;
                    }
                    the_iBracketNum++;
                    the_bBracket = true;
                    break;
                case ')':
                    if (the_bLineAttrFlag == true){
                        *the_pTempBuf++ = the_cCurChar;
                    }
                    the_iBracketNum--;
                    /*�J�����g�������ŊO��')'�ł���ꍇ*/
                    if (the_iBracketNum == 0){
                        if ((strlen(the_szFuncName)) > 0  &&
                            *(the_pTempFuncName - 1) == '('){
							if (strlen(the_szFuncName) >= MAX_FUNC){
								the_iRet = ANZ_UNKNOWN_ERROR;
								goto ERR;
							}
                            *the_pTempFuncName++ = the_cCurChar;
                        }
                        the_bBracket = false;
                        if (the_bEnterFlag == true){
                            the_bEnterFlag = false;
                        }
                    }
                    break;
                case '{':
                    if (the_bLineAttrFlag == true){
                        *the_pTempBuf++ = the_cCurChar;
                    }
                    if (strlen(the_szFuncName) == 0    &&
                        strlen(the_szTempFuncName) > 0 ){
                        strcpy(the_szFuncName,the_szTempFuncName);
                        the_pTempFuncName += strlen(the_szFuncName);
                        memset(the_szTempFuncName,0,MAX_FUNC);
                    }

                    /* �֐������쐬����*/
                    if ((strlen(the_szFuncName)) > 0 &&
                        (*(the_pTempFuncName - 1)) == ')'){
                        /* ���������֐����ʂ̊֐��ɒu���� */
                        if ( the_bFuncFlag == true ){
                            ADD_TO_ERROR_LIST();
                            strcpy(the_pErrInfo->m_errFileName,in_pFileInfo->m_fileName);
                            the_pErrInfo->m_errType = ANZ_FUNC_NO_CLOSED;
                            the_pErrInfo->m_lineno = the_pFuncStartLine->m_lineno;
                            *io_iErrFlag = 1;
                            /* ������"\"�ł͂Ȃ��ꍇ�Ag_szNVPath�̌��"\"��ǉ����� */
                            if(in_iVerFlag == ANZ_NV_FILE ){
                                if(strcmp(g_szNVPath,"") != 0){
                                    the_cCurChar = *(g_szNVPath + strlen(g_szNVPath) - 1);
                                #ifdef __GNUC__
                                    if(the_cCurChar != '/'){
                                        strcat(g_szNVPath,"/");
                                    }
                                #else
                                    if(the_cCurChar != '\\'){
                                        strcat(g_szNVPath,"\\");
                                    }
                                #endif
                                }
                                memset(the_szFileName,'\0',MAX_PATH);
                                strcat(the_szFileName,g_szNVPath);
                                strcat(the_szFileName,in_pFileInfo->m_fileName);
                            }
                            /* ������"\"�ł͂Ȃ��ꍇ�Ag_szNVPath�̌��"\"��ǉ����� */
                            if(in_iVerFlag == ANZ_OV_FILE ){
                                if(strcmp(g_szOVPath,"") != 0){
                                    the_cCurChar = *(g_szOVPath + strlen(g_szOVPath) - 1);
                            #ifdef __GNUC__
                                    if(the_cCurChar != '/'){
                                        strcat(g_szOVPath,"/");
                                    }
                            #else
                                    if(the_cCurChar != '\\'){
                                        strcat(g_szOVPath,"\\");
                                    }
                            #endif
                                }
                                memset(the_szFileName,'\0',MAX_PATH);
                                strcat(the_szFileName,g_szOVPath);
                                strcat(the_szFileName,in_pFileInfo->m_fileName);
                            }
							if(in_iVerFlag == ANZ_CM_FILE ){
								memset(the_szFileName,'\0',MAX_PATH);
								strcat(the_szFileName,in_pFileInfo->m_fileName);
							}
                            printf("%s,%s,%d\n",MSG_FUNC_NO_CLOSED,
	                                the_szFileName,the_pFuncStartLine->m_lineno);
                            the_iELOC = 0;
                            the_iMccabe = 1;
                            the_iBigBrkNum = 0;
                            memset(the_szOldFuncName,0,MAX_FUNC);
                            strcpy(the_szOldFuncName,the_szFuncName);
                            memset(the_szFuncName,0,MAX_FUNC);
                            the_pTempFuncName = the_szFuncName;
                            the_pFuncStartLine = the_pTempLine1;
                            the_pTempLine1->m_attr1.FEL = 0;
                            the_bFuncStateFlag = true;
                            the_bTempFuncFlag = true;
                            the_iExecNum = 0;
                        }
                        else {
                            /*�֐��̊J�n�s*/
                            the_pFuncStartLine = the_pTempLine1;
                            the_pTempLine1->m_attr1.FEL = 0;
                            the_bFuncStateFlag = true;
                            strcpy(the_szOldFuncName,the_szFuncName);
                            memset(the_szFuncName,0,MAX_FUNC);
                            the_pTempFuncName = the_szFuncName;
                            the_bFuncFlag = true;
                            the_bTempFuncFlag = true;
                        }
                        the_iLoop3 = 0;
                        the_iLoop2 = 0;
                        the_iBigBrkNum++;
                        break;
                    }
					if ((strlen(the_szFuncName)) > 0 &&
                        (*(the_pTempFuncName - 1)) != ')'){
						memset(the_szFuncName,0,MAX_FUNC);
						the_pTempFuncName = the_szFuncName;
					}
                    if (the_bFuncFlag == true){
                        the_iBigBrkNum++;
                        break;
                    }
                    break;
                case '}':
                    if (the_bLineAttrFlag == true){
                        *the_pTempBuf++ = the_cCurChar;
                    }
                    /* ���������t�B�[���h���֐����ł͂Ȃ��ꍇ */
                    if (the_bFuncFlag == false && the_iBigBrkNum == 0
                        && strlen(the_szFuncName) > 0){
                        memset(the_szFuncName,0,MAX_FUNC);
                        the_pTempFuncName = the_szFuncName;
                    }
                    if ( the_iBigBrkNum > 0 && the_bFuncFlag == true){
                        the_iBigBrkNum--;
                        /*�֐��̍Ō�̑劇�ʂɂ��񂷂鏈��*/
                        if (the_iBigBrkNum == 0 ){
                            if (the_iExecNum == 1){
                                the_iLoop2 = the_iLoop1;
                                the_iLoop3 = 0;
                                if(the_iLoop2 == 1 && the_pTempLine1->m_attr1.FEL == 1)
                                {
                                    the_pTempLine1->m_attr1.FEL = 0;
                                    the_iELOC--;
                                    the_iLoop2 = 0;
                                }
                                while(the_iLoop2 > 1)
                                {
                                    if (the_pTempLine->m_attr1.OEC == 1){
                                        the_bComtFlag = true;
                                    }
                                    if( !ISIDENT(*(the_pTempPS - the_iLoop2))){
                                        if (the_bComtFlag == true){
                                            if ((*(the_pTempPS - the_iLoop2)) == '*' &&
                                                (*(the_pTempPS - ( the_iLoop2 - 1))) == '/'){
                                                the_bComtFlag = false;
                                                the_iLoop2--;
                                            }
                                            else {
                                                the_iLoop2--;
                                                continue;
                                            }
                                        }
                                        else {
                                            if ((*(the_pTempPS - the_iLoop2)) == '/' &&
                                                (*(the_pTempPS - ( the_iLoop2 - 1))) == '*'){
                                                the_bComtFlag = true;
                                                the_iLoop2--;
                                                continue;
                                            }
                                            else {
                                                the_iLoop3++;
                                            }
                                        }
                                    }
                                    the_iLoop2--;
                                }
                                if ( the_iLoop3 == 0 && the_iLoop1 > 0
                                    && the_pTempLine1->m_attr1.FEL == 1){
                                    the_pTempLine1->m_attr1.FEL = 0;
                                    the_iELOC--;
                                    the_iLoop2 = 0;
                                    the_iLoop3 = 0;
                                }

                            }
                            the_iFuncEndLine = the_pTempLine->m_lineno;
                            /* �֐������o�͂��� */
                            the_iFuncNum++;
                            the_iFileELOC += the_iELOC;
                            if(the_iMaxMcCabe < the_iMccabe){
                                the_iMaxMcCabe = the_iMccabe;
                            }
                            if (the_iMccabe >= 10){
                                the_iMccabe10++;
                            }
                            /*�֐��ގ��xOption���w�肵���ꍇ�̏���*/
                            if (io_pAnzInfo->m_option->m_similar == ON){
                                io_pAnzInfo->m_simfuncNum++;
                                AnzMalloc(the_pCurFunc,ST_Func*,sizeof(ST_Func));
                                if ( the_pCurFunc == NULL){
                                    the_iRet = ANZ_ERR_MEMORY_FAILED;
                                    goto ERR;
                                }
                                else {
                                    memset(the_pCurFunc,'\0',sizeof(ST_Func));
                                    if (io_pAnzInfo->m_simfunc == NULL){
                                        io_pAnzInfo->m_simfunc = the_pCurFunc;
                                        the_pPrevFunc = io_pAnzInfo->m_simfunc;
                                    }
                                    else {
                                        the_pPrevFunc = *io_preFileLastFunc;
                                        the_pPrevFunc->m_next = the_pCurFunc;
                                        the_pPrevFunc = the_pPrevFunc->m_next;
                                    }
                                }

                                AnzMalloc(the_pCurFunc->m_execloc,char**,sizeof(char*)*(the_iELOC + 1));
                                if ( the_pCurFunc->m_execloc == NULL){
                                    the_iRet = ANZ_ERR_MEMORY_FAILED;
                                    goto ERR;
                                }
                                memset(the_pCurFunc->m_execloc,'\0',sizeof(char*)*(the_iELOC + 1));
                                the_pCurFunc->m_eloc = the_iELOC;
                                strcpy(the_pCurFunc->m_funcName,the_szOldFuncName);
                                the_pCurFunc->m_parent = in_pFileInfo;
                                the_iLoop2 = 0;
                                while(the_pFuncStartLine->m_lineno <= the_iFuncEndLine){
                                    if (the_pFuncStartLine->m_attr1.FEL == 1 ){
                                        *(the_pCurFunc->m_execloc + the_iLoop2) = the_pFuncStartLine->m_prow;
                                        the_iLoop2++;
                                    }
                                    the_pFuncStartLine = the_pFuncStartLine->m_next;
                                    if(the_pFuncStartLine == NULL){
                                        break;
                                    }
                                }
                                *io_preFileLastFunc = the_pCurFunc;
                            }
                            /*�ʏ�v���ł���ꍇ�̏���*/
                            if(io_pAnzInfo->m_option->m_eloc == ON ||
                                io_pAnzInfo->m_option->m_mccabe == ON){
                                g_funcMetrics->m_eloc = the_iELOC;
                                g_funcMetrics->m_mccabe = the_iMccabe;
                                g_funcMetrics->m_fileName = in_pFileInfo->m_fileName;
                                g_funcMetrics->m_funcName = the_szOldFuncName;
                                the_iRet = OutResultFile(ANZ_OUT_FUNC_METRICS);
                                if(the_iRet != ANZ_SUCCESS) {
                                    goto ERR;
                                }
                            }
                            /*�v����ނ��擾����*/
                            GetMeasureType(io_pAnzInfo->m_option,&the_iMeasureType);

                            /*�����v���ł���ꍇ�̏���*/
                            if(the_iMeasureType == ANZ_TREND_MEASURE){
                                /*�J�����gFile���V�łł���ꍇ*/
                                if (in_iVerFlag == ANZ_NV_FILE){
                                    AnzMalloc(the_pCurFunc,ST_Func*,sizeof(ST_Func));
                                    if ( the_pCurFunc == NULL){
                                        the_iRet = ANZ_ERR_MEMORY_FAILED;
                                        goto ERR;
                                    }
                                    else {
                                        memset(the_pCurFunc,'\0',sizeof(ST_Func));
                                        if (the_pHeadFunc == NULL){
                                            the_pHeadFunc = the_pCurFunc;
                                            in_pFileInfo->m_func = the_pHeadFunc;
                                            the_pPrevFunc = the_pHeadFunc;
                                        }
                                        else {
                                            the_pPrevFunc->m_next = the_pCurFunc;
                                            the_pPrevFunc = the_pPrevFunc->m_next;
                                        }
                                    }
                                    AnzMalloc(the_pCurFunc->m_execloc,char**,sizeof(char*)*(the_iELOC + 1));
                                    if (the_pCurFunc->m_execloc == NULL){
                                        the_iRet = ANZ_ERR_MEMORY_FAILED;
                                        goto ERR;
                                    }
                                    memset(the_pCurFunc->m_execloc,'\0',sizeof(char*)*(the_iELOC + 1));
                                    the_pCurFunc->m_eloc = the_iELOC;
                                    strcpy(the_pCurFunc->m_funcName,the_szOldFuncName);
                                    the_pCurFunc->m_parent = in_pFileInfo;
                                    the_pCurFunc->m_state = ANZ_PAIR_NEW;
                                    the_iLoop2 = 0;
                                    while(the_pFuncStartLine->m_lineno <= the_iFuncEndLine ){
                                        if (the_pFuncStartLine->m_attr1.FEL == 1 ){
                                            *(the_pCurFunc->m_execloc + the_iLoop2) = the_pFuncStartLine->m_prow;
                                            the_iLoop2++;
                                        }
                                        the_pFuncStartLine = the_pFuncStartLine->m_next;
                                        if(the_pFuncStartLine == NULL){
                                            break;
                                        }
                                    }

                                }

                                /*����File�̏���*/
                                else {
                                    the_pHeadFunc = in_pFileInfo->m_func;
                                    the_pTempFunc = in_pFileInfo->m_func;
                                    while(the_pTempFunc != NULL){

                                        /*����File�̃J�����g�֐����V��File�ɂ���ꍇ*/
                                        if(strcmp(the_pTempFunc->m_funcName,the_szOldFuncName) == 0){
                                            the_pTempFunc->m_state = ANZ_PAIR_NOCHANGE;
                                            the_pTempFunc->m_ov_eloc = the_iELOC;
                                            AnzMalloc(the_pTempFunc->m_ov_execloc,char**,sizeof(char*)*(the_iELOC + 1));
                                            if (the_pTempFunc->m_ov_execloc == NULL){
                                                the_iRet = ANZ_ERR_MEMORY_FAILED;
                                                goto ERR;
                                            }
                                            memset(the_pTempFunc->m_ov_execloc,'\0',sizeof(char*)*(the_iELOC + 1));
                                            the_iLoop2 = 0;
                                            while(the_pFuncStartLine->m_lineno <= the_iFuncEndLine ){
                                                if (the_pFuncStartLine->m_attr1.FEL == 1 ){
                                                    *(the_pTempFunc->m_ov_execloc + the_iLoop2) = the_pFuncStartLine->m_prow;
                                                    the_iLoop2++;
                                                }
                                                the_pFuncStartLine = the_pFuncStartLine->m_next;
                                                if(the_pFuncStartLine == NULL){
                                                    break;
                                                }
                                            }
                                            the_bTrendFlag = true;
                                        }
                                        the_pPrevFunc = the_pTempFunc;
                                        the_pTempFunc = the_pTempFunc->m_next;
                                    }
                                        /*����File�̃J�����g�֐����V��File�ɂȂ��ꍇ*/
                                    if( the_bTrendFlag != true){
                                            AnzMalloc(the_pCurFunc,ST_Func*,sizeof(ST_Func));
                                            if ( the_pCurFunc == NULL){
                                                the_iRet = ANZ_ERR_MEMORY_FAILED;
                                                goto ERR;
                                            }
                                            else {
                                                memset(the_pCurFunc,'\0',sizeof(ST_Func));
                                                if (the_pHeadFunc == NULL){
                                                    the_pHeadFunc = the_pCurFunc;
                                                    in_pFileInfo->m_func = the_pHeadFunc;
                                                    the_pPrevFunc = the_pHeadFunc;
                                                }
                                                else {
                                                    the_pPrevFunc->m_next = the_pCurFunc;
                                                    the_pPrevFunc = the_pPrevFunc->m_next;
                                                }
                                            }
                                            AnzMalloc(the_pCurFunc->m_ov_execloc,char**,sizeof(char*)*(the_iELOC + 1));
                                            if (the_pCurFunc->m_ov_execloc == NULL){
                                                the_iRet = ANZ_ERR_MEMORY_FAILED;
                                                goto ERR;
                                            }
                                            memset(the_pCurFunc->m_ov_execloc,'\0',sizeof(char*)*(the_iELOC + 1));
                                            the_pCurFunc->m_ov_eloc = the_iELOC;
                                            strcpy(the_pCurFunc->m_funcName,the_szOldFuncName);
                                            the_pCurFunc->m_state = ANZ_PAIR_DELETE;
                                            the_pCurFunc->m_parent = in_pFileInfo;
                                            the_iLoop2 = 0;
                                            while( the_pFuncStartLine->m_lineno <= the_iFuncEndLine )
                                            {
                                                if (the_pFuncStartLine->m_attr1.FEL == 1 ){
                                                    *(the_pCurFunc->m_ov_execloc + the_iLoop2) = the_pFuncStartLine->m_prow;
                                                    the_iLoop2++;
                                                }
                                                the_pFuncStartLine = the_pFuncStartLine->m_next;
                                                if(the_pFuncStartLine == NULL){
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                                /* �֐����I�����Ă���A�ϐ������������� */
                                memset(the_szOldFuncName,0,MAX_FUNC);
                                memset(the_szFuncName,0,MAX_FUNC);
                                the_pTempFuncName = the_szFuncName;
                                the_iMccabe = 1;
                                the_iELOC = 0;
                                the_bFuncFlag = false;
                                the_bFuncStateFlag = false;
                                the_bTrendFlag = false;
                                the_bBlankFlag = false;
                                the_bFuncELOCFlag = false;
                                the_bTempFuncFlag = false;
                                the_bEnterFlag = false;
                                the_iFuncEndLine = 0;
                        }
                    }
                    break;
                case '/':
                    if (the_bLineAttrFlag == true){
                        *the_pTempBuf++ = the_cCurChar;
                    }
                    switch(*the_pTempPS)
                    {
                    case '/':
                        if (the_bLineAttrFlag == true){
                            *the_pTempBuf++ = *the_pTempPS;
                        }
                        the_pTempPS++;
                        state = CC_COMMENT;
                        break;
                    case '*':
                        if (the_bLineAttrFlag == true){
                            *the_pTempBuf++ = *the_pTempPS;
                        }
                        the_pTempPS++;
                        state = C_COMMENT;
                        break;
                    default:
                        if (the_bLineAttrFlag == true){
                            *the_pTempBuf++ = the_cCurChar;
                        }
                        break;
                    }
                    break;
                    case '\0':
                        the_iLoop1 = 0;
                        /*�J�����g�s��File�̖��s�A���֐������̍s�ł���ꍇ*/
                        if (the_bLastLineFlag == true && the_bFuncFlag == true ){
                            ADD_TO_ERROR_LIST();
                            strcpy(the_pErrInfo->m_errFileName,in_pFileInfo->m_fileName);
                            the_pErrInfo->m_errType = ANZ_FUNC_NO_CLOSED;
                            the_pErrInfo->m_lineno = the_pFuncStartLine->m_lineno;
                            *io_iErrFlag = 1;
                            the_iRet = ANZ_FUNC_NO_CLOSED;
                            goto ERR;
                        }
                        if (the_bBracket == false){
                            the_bEnterFlag = true;
                            the_bTempFuncFlag = false;
                            if ( strlen(the_szFuncName) > 0 && the_pTempLine->m_attr.SL != 1){
                                IdentifyMacabeKeyWord(the_szFuncName,&the_iKeyFlag);
                                if (the_iKeyFlag != 0){
                                    if (the_iKeyFlag == 1 && the_bFuncFlag == true){
                                        the_iMccabe++;
                                    }
                                    if (strlen(the_szTempFuncName) > 0){
                                        memset(the_szTempFuncName,0,MAX_FUNC);
                                    }
                                    memset(the_szFuncName,0,MAX_FUNC);
                                    the_pTempFuncName = the_szFuncName;
                                }
                                else {
                                    if (strlen(the_szFuncName) > 0 && *(the_pTempFuncName - 1) == ')'
                                        && the_bFuncFlag == true){
                                        memset(the_szTempFuncName,0,MAX_FUNC);
                                        strcpy(the_szTempFuncName,the_szFuncName);
                                        memset(the_szFuncName,0,MAX_FUNC);
                                        the_pTempFuncName = the_szFuncName;
                                    }

                                }
                            }
                            if ( strlen(the_szFuncName) > 0 && the_pTempLine->m_attr.SL == 1){
                                *(--the_pTempFuncName) = '\0';
                                IdentifyMacabeKeyWord(the_szFuncName,&the_iKeyFlag);
                                if (the_iKeyFlag != 0){
                                    if (the_iKeyFlag == 1 && the_bFuncFlag == true){
                                        the_iMccabe++;
                                    }
                                    if (strlen(the_szTempFuncName) > 0){
                                        memset(the_szTempFuncName,0,MAX_FUNC);
                                    }
                                    memset(the_szFuncName,0,MAX_FUNC);
                                    the_pTempFuncName = the_szFuncName;
                                }
                                else {
                                    the_bEnterFlag = false;
                                }
                            }
                            /*�J�����g�s����s�����s��*/
                            if (the_bLineAttrFlag == true){
                                /*�J�����g�s���p���s�ł���*/
                                if ( the_pTempLine->m_attr.SL == 1){
                                    if ((*(the_pTempBuf - 1)) == ' ' ){
                                        if ((*(the_pTempBuf - 3)) == ' '){
                                            *(the_pTempBuf - 2) = '\0';
                                            the_pTempBuf -= 2;
                                        }
                                        else {
                                            *(the_pTempBuf - 2) = ' ';
                                            *(--the_pTempBuf) = '\0';
                                        }
                                        break;
                                    }
                                    else {
                                        if ( (*(the_pTempBuf - 2)) == ' '){
                                            *(--the_pTempBuf) = '\0';
                                            break;
                                        }
                                        else {
                                            *(--the_pTempBuf) = ' ';
                                        }
                                        break;
                                    }

                                }
                                /*�J�����g�s���p���s�ł͂Ȃ�*/
                                else {
                                    if ((*(the_pTempBuf - 1)) == ' ' ){
                                        *(--the_pTempBuf) = '\0';
                                    }
                                    else {
                                        *the_pTempBuf++ = the_cCurChar;
                                    }
                                    strcpy(the_pTempLine1->m_prow,the_szBuf);
                                    the_pTempLine1 = NULL;
                                    memset(the_szBuf,0,MAXLINE);
                                    the_pTempBuf = the_szBuf;
                                    the_bLineAttrFlag = false;
                                }
                            }
                            else {
                                the_pTempLine1 = NULL;
                                memset(the_szBuf,0,MAXLINE);
                                the_pTempBuf = the_szBuf;
                                the_bLineAttrFlag = false;
                            }
                            if ( the_bFuncFlag == true && the_pTempLine->m_attr.SL != 1 ){
                                the_bFuncELOCFlag = false;
                            }
                            break;
                        }
                        else {
                            if (the_bLineAttrFlag == true){
                                /*�J�����g�s���p���s�ł���*/
                                if ( the_pTempLine->m_attr.SL == 1){
                                    if ((*(the_pTempBuf - 1)) == ' ' ){
                                        if ((*(the_pTempBuf - 3)) == ' '){
                                            *(the_pTempBuf - 2) = '\0';
                                            the_pTempBuf -= 2;
                                        }
                                        else {
                                            *(the_pTempBuf - 2) = ' ';
                                            *(--the_pTempBuf) = '\0';
                                        }
                                        break;
                                    }
                                    else {
                                        if ( (*(the_pTempBuf - 2)) == ' '){
                                            *(--the_pTempBuf) = '\0';
                                            break;
                                        }
                                        else {
                                            *(--the_pTempBuf) = ' ';
                                        }
                                        break;
                                    }
                                }
                                /*�J�����g�s���p���s�ł͂Ȃ�*/
                                else {
                                    if ((*(the_pTempBuf - 1)) == ' ' ){
                                        *(--the_pTempBuf) = '\0';
                                    }
                                    else {
                                        *the_pTempBuf++ = the_cCurChar;
                                    }
                                    strcpy(the_pTempLine1->m_prow,the_szBuf);
                                    memset(the_szBuf,0,MAXLINE);
                                    the_pTempBuf = the_szBuf;
                                    the_bLineAttrFlag = false;
                                }
                            }
                            if (the_pTempLine1 != NULL){
                                the_pTempLine1 = NULL;
                            }
                            if ( the_bFuncFlag == true){
                                the_bFuncELOCFlag = false;
                            }
                            break;
                        }
                        break;
                    default:
                        /*case:int func()�̂悤�Ȋ֐��̏���*/
                        if ( strlen(the_szFuncName) > 0 && the_bBlankFlag == true ){
                            memset(the_szFuncName,0,MAX_FUNC);
                            the_pTempFuncName = the_szFuncName;
                            the_bBlankFlag = false;
                        }

                        /*case:A() func()�̂悤�Ȋ֐��̏��� */
                        if ( strlen(the_szFuncName) > 0 && the_bEnterFlag == false
                            && *(the_pTempFuncName - 1) == ')' ){
                            memset(the_szFuncName,0,MAX_FUNC);
                            the_pTempFuncName = the_szFuncName;
                        }
                        /*case:int    */
                        /*               func()�̂悤�Ȋ֐��̏���*/
                        if ( strlen(the_szFuncName) > 0 && (*(the_pTempFuncName - 1) != ')')
                            && the_bEnterFlag == true){
                            memset(the_szFuncName,0,MAX_FUNC);
                            the_pTempFuncName = the_szFuncName;
                            the_bEnterFlag = false;
                        }

                        if (the_bLineAttrFlag == true){
                            *the_pTempBuf++ = the_cCurChar;
                        }
                        if (the_bBracket == false && *(the_pTempFuncName - 1) != ')'){
                            if (strlen(the_szFuncName) == 0 && the_cCurChar == '*'){

                            }
                            else {
								if (strlen(the_szFuncName) >= MAX_FUNC){
									the_iRet = ANZ_UNKNOWN_ERROR;
									goto ERR;
								}
                                *the_pTempFuncName++ = the_cCurChar;
                            }
                        }
                        if(the_bEnterFlag == true &&
                            the_bBracket == false &&
                            *(the_pTempFuncName - 1) != ')'){
                            the_bEnterFlag = false;
                        }
						if (the_bBracket == false){
							the_bBlankFlag = false;
						}
                        break;

                    }/* end normal switch 1*/
                    break;
                    /*""��Ԃł̏���*/
            case CHARLITERAL:
                if (the_bLineAttrFlag == true){
                    *the_pTempBuf++ = the_cCurChar;
                }
                /*�J�����g������'\''�ł���ꍇ*/
                if (the_cCurChar == '\''){
                    if (*(the_pTempPS - 2) == '\\' && *(the_pTempPS - 3) != '\\'){
                        break;
                    }
                    else {
                        state = NORMAL;
                        break;
                    }
                }
                break;
                /*""��Ԃł̏���*/
            case STRINGLITERAL:
                if (the_bLineAttrFlag == true){
                    if (the_cCurChar == '\0'){
                        /*�J�����g�s���p���s�ł���*/
                        if ( the_pTempLine->m_attr.SL == 1){
                            if ((*(the_pTempBuf - 1)) == ' ' ){
                                if ((*(the_pTempBuf - 3)) == ' '){
                                    *(the_pTempBuf - 2) = '\0';
                                    the_pTempBuf -= 2;
                                }
                                else {
                                    *(the_pTempBuf - 2) = ' ';
                                    *(--the_pTempBuf) = '\0';
                                }
                                break;
                            }
                            else {
                                if ( (*(the_pTempBuf - 2)) == ' '){
                                    *(--the_pTempBuf) = '\0';
                                    break;
                                }
                                else {
                                    *(--the_pTempBuf) = ' ';
                                }
                                break;
                            }
                        }
                    }
                    else {
                        *the_pTempBuf++ = the_cCurChar;
                    }
                }

                /*�J�����g������'"'�ł���ꍇ*/
                if (the_cCurChar == '"'){
                    if ( my_iskanji((unsigned char)*(the_pTempPS - 2))){
                        state = NORMAL;
                        break;
                    }
                    else {
                        if (*(the_pTempPS - 2) == '\\' && *(the_pTempPS - 3) != '\\'){
                            break;
                        }
                        state = NORMAL;
                    }
                }
                break;

                /*//�ŃR�����g�̏�Ԃł̏���*/
                case CC_COMMENT:
                    /* �J�����g������[//]�R�����g��[\0]�̏ꍇ */
                    if (the_bLineAttrFlag == true){
                        /* ��s���̌��ʂ��o�͂��� */
                        if (the_cCurChar == '\0'){
                            the_iLoop1 = 0;
                            if ((*(the_pTempBuf - 1)) == ' '){
                                *(--the_pTempBuf) = '\0';
                            }
                            else {
                                *the_pTempBuf++ = the_cCurChar;
                            }
                            strcpy(the_pTempLine1->m_prow,the_szBuf);
                            the_pTempLine1 = NULL;
                            memset(the_szBuf,0,MAXLINE);
                            the_pTempBuf = the_szBuf;
                            the_bLineAttrFlag = false;
                            if (the_bFuncFlag == true){
                                the_bFuncELOCFlag = false;
                            }
							the_bEnterFlag = true;
                            the_bTempFuncFlag = false;
                            the_bTempFuncFlag = false;
                            state = NORMAL;
                        }
                        else {
                            *the_pTempBuf++ = the_cCurChar;
                        }
                        break;
                    }
                    else {
                        if (the_cCurChar == '\0'){
                            the_iLoop1 = 0;
							the_bEnterFlag = true;
                            the_bTempFuncFlag = false;
                            the_bTempFuncFlag = false;
                            the_pTempLine1 = NULL;
                            state = NORMAL;
                        }
                        break;
                    }
                    break;
                    /*/*�ŃR�����g�̏�Ԃł̏���*/
                case C_COMMENT:
                    switch(the_cCurChar)
                    {
                    case '*':
                        if (the_bLineAttrFlag == true){
                            *the_pTempBuf++ = the_cCurChar;
                        }
                        /*�J�����g�����̎��������S�p�����ł���ꍇ*/
                        if ( my_iskanji((unsigned char)*(the_pTempPS))){
                            if ( the_bLineAttrFlag == true ){
                                *the_pTempBuf++ = *the_pTempPS;
                                *the_pTempBuf++ = *the_pTempPS++;
                                the_pTempPS++;
                            }
                            else {
                                the_pTempPS += 2;
                                continue;
                            }
                        }
                        /*�J�����g�����̎��������S�p�����ł͂Ȃ��ꍇ*/
                        else {
                            /*�J�����g�����̎�������'/'�ł���ꍇ*/
                            if ( (*the_pTempPS) == '/'){
                                if (the_bLineAttrFlag == true){
                                    *the_pTempBuf++ = *the_pTempPS;
                                }
                                the_pTempPS++;
                                state = NORMAL;
                            }
                        }
                        break;
                        /* �J�����g������[/*]�R�����g��[\0]�̏ꍇ */
                    case '\0':
                        the_iLoop1 = 0;
                        /* ��s���̌��ʂ��o�͂��� */
                        if (the_bLineAttrFlag == true){
                            if ((*(the_pTempBuf - 1 )) == ' ' ){
                                *(--the_pTempBuf) = '\0';
                            }
                            else {
                                *the_pTempBuf++ = the_cCurChar;
                            }
                            strcpy(the_pTempLine1->m_prow,the_szBuf);
                            memset(the_szBuf,0,MAXLINE);
                            the_pTempBuf = the_szBuf;
                            the_bLineAttrFlag = false;

                        }
                        if (the_pTempLine1 != NULL){
                            the_pTempLine1 = NULL;
                        }
                        if (the_bFuncFlag == true){
                            the_bFuncELOCFlag = false;
                        }
                        break;
                    default:
                        if ( the_bLineAttrFlag == true ){
                            *the_pTempBuf++ = the_cCurChar;
                        }
                        break;
                    }
                    break;
            } /*end switch 1 */
        }while(the_cCurChar != '\0');
        the_pTempLine = the_pTempLine->m_next;
    }/* end while 1 */

    /* �v�����ʂ��o�͂��� */
    if(io_pAnzInfo->m_option->m_funcNum == ON  ||
        io_pAnzInfo->m_option->m_mccabe == ON  ||
        io_pAnzInfo->m_option->m_eloc == ON    ||
        io_pAnzInfo->m_option->m_redundancy == ON){
        g_fileMetrics->m_eloc = the_iFileELOC;
        g_fileMetrics->m_fileName = in_pFileInfo->m_fileName;
        g_fileMetrics->m_funcNum = the_iFuncNum;
        g_fileMetrics->m_maxMcCabe = the_iMaxMcCabe;
        g_fileMetrics->m_mccabe10 = the_iMccabe10;
    }
    if(io_pAnzInfo->m_option->m_funcTrend == ON){

        if(in_iVerFlag == ANZ_NV_FILE ||
            in_iVerFlag == ANZ_CM_FILE){
            g_fileTrend2->m_nv_eloc = the_iFileELOC;
        }
        else {
            g_fileTrend2->m_ov_eloc = the_iFileELOC;
        }
    }

ERR:
    /* ������"\"�ł͂Ȃ��ꍇ�Ag_szNVPath�̌��"\"��ǉ����� */
    if(in_iVerFlag == ANZ_NV_FILE ){
        if(strcmp(g_szNVPath,"") != 0){
            the_cCurChar = *(g_szNVPath + strlen(g_szNVPath) - 1);
#ifdef __GNUC__
            if(the_cCurChar != '/'){
                strcat(g_szNVPath,"/");
            }
#else
            if(the_cCurChar != '\\'){
                strcat(g_szNVPath,"\\");
            }
#endif
        }
        memset(the_szFileName,'\0',MAX_PATH);
        strcat(the_szFileName,g_szNVPath);
        strcat(the_szFileName,in_pFileInfo->m_fileName);
    }
                /* ������"\"�ł͂Ȃ��ꍇ�Ag_szNVPath�̌��"\"��ǉ����� */
    if(in_iVerFlag == ANZ_OV_FILE ) {
        if(strcmp(g_szOVPath,"") != 0){
            the_cCurChar = *(g_szOVPath + strlen(g_szOVPath) - 1);
#ifdef __GNUC__
            if(the_cCurChar != '/'){
                strcat(g_szOVPath,"/");
            }
#else
            if(the_cCurChar != '\\'){
                strcat(g_szOVPath,"\\");
            }
#endif
        }
        memset(the_szFileName,'\0',MAX_PATH);
        strcat(the_szFileName,g_szOVPath);
        strcat(the_szFileName,in_pFileInfo->m_fileName);
    }
    if(in_iVerFlag == ANZ_CM_FILE ){
		memset(the_szFileName,'\0',MAX_PATH);
        strcat(the_szFileName,in_pFileInfo->m_fileName);
	}
    switch(the_iRet){
        /* �J�����g�֐������Ȃ� */
    case ANZ_FUNC_NO_CLOSED:
        printf("%s,%s,%d\n",MSG_FUNC_NO_CLOSED,
            the_szFileName,the_pFuncStartLine->m_lineno);
        break;
        /* �������𕪔z���Ɏ��s���� */
    case ANZ_ERR_MEMORY_FAILED:
        printf("%s\n",MSG_MOMORY_FAILED);
        break;
		/*�s���ȃG���[���������܂���*/
	case ANZ_UNKNOWN_ERROR:
		ADD_TO_ERROR_LIST();
		strcpy(the_pErrInfo->m_errFileName,in_pFileInfo->m_fileName);
		the_pErrInfo->m_errType = ANZ_UNKNOWN_ERROR;
		the_pErrInfo->m_lineno = the_pTempLine->m_lineno;
		*io_iErrFlag = 1;
		printf("%s,%s,%d\n",MSG_UNKNOWN_ERROR,
			the_szFileName,the_pErrInfo->m_lineno);
		break;
    default:
        break;
    }
    return the_iRet;
}
