/*
 File:
      preprocess2.h
 Copyright:
      Copyright (C) 2004 TOSHIBA CORPORATION. All Rights Reserved.
 Product:
      AnalyzeMe
 Abstract:
      �O����(2)�̊֐���錾����
 Author:
      tong-huixin
 Date:
      2004/08/20
 REVISION HISTORY:

*/

/*
    $AnalyzeMe 1.0.0.1$
*/

#ifndef PREPROCESS2_H
#define PREPROCESS2_H

#include "analyzeme_type.h"

int Preprocess2(ST_AnalyzeMe *io_anzInfo,ST_MeasureFile *io_fileInfo,
				ST_Func **io_preFileLastFunc,const int in_verFlag,int *io_errFlag);

#endif  /* end for ifndef PREPROCESS2_H */
