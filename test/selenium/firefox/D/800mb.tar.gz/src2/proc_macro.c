/*
 File:
    proc_macro.c
 Copyright:
    Copyright (C) 2004 TOSHIBA CORPORATION. All Rights Reserved.
 Product:
    AnalyzeMe
 Abstract:

 Author:
    tong-huixin
 Date:
    2004/08/15
 REVISION HISTORY:
    2004/08/18        tong-huixin      1st Revision�@
*/

/*
    $AnalyzeMe 1.0.0.0$
*/

#include "common.h"

/**
*  proc_macro
*  
*  @param
*          in_anzInfo          AnalyzeMe�Ǘ����
*          io_fileInfo         �J�����g�v��File���
*          io_procMacroNode    �O�̃t�@�C���ɍŌ�̃}�N����`�m�[�h
*          in_verFlag          �J�����g�t�@�C���̔� 
*  @return
*          ANZ_SUCCESS ����I�� 
*          ANZ_ERROR   �ُ�I��
*  @author tong-huixin
*/
int proc_macro(ST_AnalyzeMe *io_pAnzInfo,ST_MeasureFile *in_pFileInfo,
                    ST_ProcMacro **io_procMacroNode,const int in_iVerFlag)
{
    int the_iRet = ANZ_SUCCESS;         /*Return�l*/
    int the_iProcMacroNum = 0;
    int the_iSeriesBlankNum = 0;
    int the_iComtNum = 0;
    int the_iPrevSeriesBlankNum = 0;
    
    char  the_cCurChar;
    char the_szProcMacroStr[100];
    char *the_pTempProcMacroStr;
    char *the_pFileCont = NULL;
    bool the_bPreprocFlag = false;
    bool the_bDefFlag = false;
    bool the_bBracketFlag = false;
    ST_ProcMacro *the_pPrevProcMacro = NULL;
    ST_ProcMacro *the_pCurProcMacro = NULL;
  
        enum {
            NORMAL,        /*NORMAL��Ԃ�\�� */
            C_COMMENT,     /*"/*"�R�����g��Ԃ�\�� */
            CC_COMMENT,    /* "//"�R�����g��Ԃ�\�� */
    }state = NORMAL;
    /* �J�����g�t�@�C���͐V�����ł̏ꍇ */
    if(in_iVerFlag == ANZ_NV_FILE ||
        in_iVerFlag == ANZ_CM_FILE){
        the_pFileCont = in_pFileInfo->m_fileCont;
    }
    /* �J�����g�t�@�C���͌Â��ł̏ꍇ */
    else {
        the_pFileCont = in_pFileInfo->m_ov_FileCont;
    }
    do{
        the_cCurChar = *the_pFileCont++;
        switch(state)
        {
        case NORMAL:
            switch(the_cCurChar)
            {
            case '#':
                if (the_bPreprocFlag == true && the_bDefFlag == false){
                    memset(the_szProcMacroStr,0,100);
                    the_pTempProcMacroStr = the_szProcMacroStr;
                    state = CC_COMMENT;
                    break;
                }
                if ((the_pFileCont -(1 + the_iSeriesBlankNum + the_iPrevSeriesBlankNum + the_iComtNum)) == in_pFileInfo->m_fileCont
                    || *(the_pFileCont - (2 + the_iSeriesBlankNum + the_iPrevSeriesBlankNum + the_iComtNum)) == '\n'){
                    the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                    the_iSeriesBlankNum = 0;
                    the_iComtNum = 0;
                    the_bPreprocFlag = true;
                    the_bDefFlag = false;
                    break;
                }
                /*�J�����g�̓v���v���Z�X�s�ł͂Ȃ�*/
                else {
                    the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                    the_iSeriesBlankNum = 0;
                    the_iComtNum = 0;
                    break;
                }
                break;
            case ' ':
                if (the_bPreprocFlag == true && the_bDefFlag == false
                    && strlen(the_szProcMacroStr) > 0){
                    if ((the_szProcMacroStr,"define") == 0){
                        the_bDefFlag = true;
                        memset(the_szProcMacroStr,0,100);
                        the_pTempProcMacroStr = the_szProcMacroStr;
                    }
                    else {
                        memset(the_szProcMacroStr,0,100);
                        the_pTempProcMacroStr = the_szProcMacroStr;
                        state = CC_COMMENT;
                    }
                }
                the_iSeriesBlankNum++;
                break;
            case '\t':
                if (the_bPreprocFlag == true && the_bDefFlag == false
                    && strlen(the_szProcMacroStr) > 0){
                    if ((the_szProcMacroStr,"define") == 0){
                        the_bDefFlag = true;
                        memset(the_szProcMacroStr,0,100);
                        the_pTempProcMacroStr = the_szProcMacroStr;
                    }
                    else {
                        memset(the_szProcMacroStr,0,100);
                        the_pTempProcMacroStr = the_szProcMacroStr;
                        state = CC_COMMENT;
                    }
                }
                the_iSeriesBlankNum++;
                break;
            case '(':
                the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                the_iSeriesBlankNum = 0;
                if (the_bPreprocFlag == true && the_bDefFlag == true
                    && strlen(the_szProcMacroStr) > 0 ){
                    the_bBracketFlag = true;
                    AnzMalloc(the_pCurProcMacro,ST_ProcMacro*,sizeof(ST_ProcMacro));
                    if (the_pCurProcMacro == NULL){
                        the_iRet = ANZ_ERR_MEMORY_FAILED;
                        goto ERR;
                    }
                    else {
                        memset(the_pCurProcMacro,'\0',sizeof(ST_ProcMacro));
                        if(in_iVerFlag == ANZ_NV_FILE ||
                            in_iVerFlag == ANZ_CM_FILE){
                            if (io_pAnzInfo->m_procMacro == NULL){
                                io_pAnzInfo->m_procMacro = the_pCurProcMacro;
                                the_pPrevProcMacro = io_pAnzInfo->m_procMacro;
                            }
                            else {
                                the_pPrevProcMacro = *io_procMacroNode;
                                the_pPrevProcMacro->m_next = the_pCurProcMacro;
                                the_pPrevProcMacro = the_pPrevProcMacro->m_next;
                            }
                        }
                        else {
                            if (io_pAnzInfo->m_ov_procMacro == NULL){
                                io_pAnzInfo->m_ov_procMacro = the_pCurProcMacro;
                                the_pPrevProcMacro = io_pAnzInfo->m_ov_procMacro;
                            }
                            else {
                                the_pPrevProcMacro = *io_procMacroNode;
                                the_pPrevProcMacro->m_next = the_pCurProcMacro;
                                the_pPrevProcMacro = the_pPrevProcMacro->m_next;
                            }

                        }
                                
                        AnzMalloc(the_pCurProcMacro->m_procName ,char*,strlen(the_szProcMacroStr));
                        strcpy(the_pCurProcMacro->m_procName,the_szProcMacroStr);
                        memset(the_szProcMacroStr,0,100);
                        the_pTempProcMacroStr = the_szProcMacroStr;
                        state = CC_COMMENT;
                        *io_procMacroNode = the_pCurProcMacro;
                        break;
                    }
                }
                if (the_bPreprocFlag == true && the_bDefFlag == false){
                    
                    memset(the_szProcMacroStr,0,100);
                    the_pTempProcMacroStr = the_szProcMacroStr;
                    state = CC_COMMENT;
                    
                }
            case '/':
                the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                the_iSeriesBlankNum = 0;
                switch(*the_pFileCont)
                {
                case '/':
                    state = CC_COMMENT;
                    the_pFileCont++;
                    break;
                case '*':
                    state = C_COMMENT;
                    the_pFileCont++;
                    break;
                default:
                    if (the_bPreprocFlag == true ){
                        *the_pTempProcMacroStr++ = the_cCurChar;
                    }
                    break;

                }
            case '\r':
                the_iSeriesBlankNum++;
                break;
            case '\n':
                 the_bPreprocFlag = false;
                 the_bDefFlag = false;
                 memset(the_szProcMacroStr,0,100);
                 the_pTempProcMacroStr = the_szProcMacroStr;
                 break;
            default:
                if (the_bPreprocFlag == true ){
                    *the_pTempProcMacroStr++ = the_cCurChar;
                }
                the_iPrevSeriesBlankNum = the_iSeriesBlankNum;
                the_iSeriesBlankNum = 0;
                break;

            }
            break;
        case C_COMMENT:
            if (the_cCurChar == '\n'){
                state = NORMAL;
                the_bPreprocFlag = false;
                the_bDefFlag = false;
                the_bBracketFlag = false;
                memset(the_szProcMacroStr,0,100);
                the_pTempProcMacroStr = the_szProcMacroStr;
            }
            break;
        case CC_COMMENT:
            if (the_cCurChar == '*' && *the_pFileCont == '/'){
                state = NORMAL;
                the_pFileCont++;
                the_iComtNum += 2;
                the_bPreprocFlag = false;
                the_bDefFlag = false;
                the_bBracketFlag = false;
                memset(the_szProcMacroStr,0,100);
                the_pTempProcMacroStr = the_szProcMacroStr;
                break;
            }
            if (the_cCurChar == '\n'){
                the_iComtNum = 0;
                break;
            }
            the_iComtNum++;
            break;
        }

    }while(the_cCurChar != '\0');
ERR:
    return the_iRet;
}
