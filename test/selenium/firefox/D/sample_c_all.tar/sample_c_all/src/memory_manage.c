/*
 File:
      memory_manage.c
 Copyright:
      Copyright (C) 2004 TOSHIBA CORPORATION. All Rights Reserved.
 Product:
      AnalyzeMe
 Abstract:
      ���ʂ̕ϐ��A�֐��̐錾�A���ʂ̃}�N�����`����
 Author:
      luo-jirong
 Date:
      2004/08/13
 REVISION HISTORY:

*/

/*
    $AnalyzeMe 1.0.0.1$
*/

#include "memory_manage.h"

#ifdef _DEBUG

static FILE *the_fpMemLog = NULL;			/* ��������Trace�t�@�C���̃n���h�� */
static ST_MemoryInfo *the_miHeader = NULL;	/* ST_MemoryInfo��Head point */
static ST_MemoryInfo *the_miPreNode = NULL;	/* �ONode */
const char *MEMLOGFILE = "memlog.txt";		/* ��������Trace�t�@�C���� */

/**
*  InitMemMan
*  ������MemMan 
*  @param  
*          �Ȃ�
*  @return 
*          �Ȃ�
*  @author luo-jirong
*/
void InitMemMan()
{
	the_fpMemLog = fopen(MEMLOGFILE,"w");
	if(the_fpMemLog == NULL) {
		printf("\nCreate MemLog.txt failed!");
	}
}

/**
*  DestoryMemMan
*  ���������   
*  @param  
*          �Ȃ�
*  @return 
*          �Ȃ�
*  @author luo-jirong
*/
void DestoryMemMan()
{
	if(the_fpMemLog != NULL ) {
		fclose(the_fpMemLog);
	}
}


/**
*  TraceMem
*  �������g���[�X   
*  @param  
*          �Ȃ�
*  @return 
*          �Ȃ�
*  @author luo-jirong
*/
static void TraceMem(const char *in_fmt,...)
{
	if(the_fpMemLog == NULL) {
		return;
	}
	
	{
		va_list the_args;
		char the_szBuffer[MAXLINE];
		va_start( the_args, in_fmt );
		vsprintf( the_szBuffer, in_fmt, the_args );
		fputs(the_szBuffer,the_fpMemLog);
	}
}


/**
*  NewMalloc
*  �������m��   
*  @param  
*          �Ȃ�
*  @return 
*          �Ȃ�
*  @author luo-jirong
*/
void *RecordMalloc(long in_size,char *in_name)
{
#undef malloc
	void * the_pv ;
	ST_MemoryInfo *the_miTmp ;
	the_pv = malloc(in_size);
	if(the_pv == NULL) {
		goto EXIT;
	}
	/* ������Block�̏����� */
	memset(the_pv,GFILLVALUE,in_size);

	the_miTmp = (ST_MemoryInfo *)malloc(sizeof(ST_MemoryInfo));
	if(the_miTmp == NULL) {
		goto EXIT;
	}
	memset(the_miTmp,'\0',sizeof(ST_MemoryInfo));
	TraceMem("\n<%s> [%ld] allocated success!",in_name,the_pv);
	/* Node��List�ɒu�� */
	if(the_miHeader == NULL) {
		the_miHeader = the_miTmp;
		the_miPreNode = the_miTmp;
	}
	else {
		the_miPreNode->m_next = the_miTmp;
		the_miPreNode = the_miTmp;
	}
	the_miTmp->m_ps = the_pv;
	the_miTmp->m_size = in_size;
	if(strlen(in_name) > 30) {
		strncpy(the_miTmp->m_name,in_name,30);
	}
	else {
		strcpy(the_miTmp->m_name,in_name);
	}
	the_miTmp->m_next = NULL;

EXIT:
#define malloc NewMalloc
		return the_pv;

}

/**
*  NewFree
*  ���������   
*  @param  
*          �Ȃ�
*  @return 
*          �Ȃ�
*  @author luo-jirong
*/
void NewFreeMem(void *in_memblock,char *in_pStr)
{
#undef free
	ST_MemoryInfo *the_miTmp = NULL;	
	ST_MemoryInfo *the_miPrev = NULL;	
	int the_iHeapStatus = 0;
	short the_bFound = 0;
	
	/* Heap�̃`�F�b�N */
#ifndef __GNUC__
	the_iHeapStatus = _heapchk();
	switch( the_iHeapStatus )
	{
	case _HEAPOK:
      TraceMem("\n <%s> [%ld]:OK - heap is fine. deleted" ,in_pStr,in_memblock);
      break;
	case _HEAPBADBEGIN:
		TraceMem( "\n<%s> [%ld]: bad start of heap. deleted",in_pStr,in_memblock );
		break;
	case _HEAPBADNODE:
		TraceMem( "\n<%s> [%ld]: bad node in heap.deleted",in_pStr,in_memblock );
		break;
	}
#endif	
	the_miTmp = the_miHeader;
	the_miPrev = NULL;
	/* Node�̃��������������A���̃�������������� */
	while( the_miTmp!=NULL) {
		if(the_miTmp->m_ps == in_memblock) {
			the_bFound = 1;
			break;
		}
		the_miPrev = the_miTmp;
		the_miTmp = the_miTmp->m_next;
	}
	
	if(the_bFound == 0){/* ������Ȃ� */
		TraceMem("\nERROR-<%s> [%ld] : Free again or this address is not exists!",in_pStr,in_memblock);
	}
	else{
		if(the_miTmp == the_miPreNode) {
			the_miPreNode = the_miPrev;
			if(the_miPrev == NULL) {
				the_miPreNode = the_miHeader;
			}
		}
		if(the_miPrev == NULL) {
			the_miHeader = the_miHeader->m_next;
		}
		else {
			the_miPrev->m_next = the_miTmp->m_next;
		}
		free(the_miTmp->m_ps);
		the_miTmp->m_ps = NULL;
		free(the_miTmp);
		the_miTmp = NULL;
	}
#define free NewFree
}


/**
*  CheckAllMem
*  ���ׂẴ��������`�F�b�N   
*  @param  
*          �Ȃ�
*  @return 
*          �Ȃ�
*  @author luo-jirong
*/
void CheckAllMem()
{
#undef free
	ST_MemoryInfo *the_miTmp = NULL;	/* �ꎞNode */
	ST_MemoryInfo *the_miPrev = NULL;	/* �ONode */
	long the_lTotalSize = 0;
	
	the_miTmp = the_miHeader;
	the_miPrev = the_miHeader;
	TraceMem("\n\n\t***************Check Memory**********************");
	/* Node�����`�F�b�N�ANULL�ł͂Ȃ��ꍇ�A��������������� */
	while(the_miTmp != NULL) {
		TraceMem("\n\t%s [%ld size:%d] is not be free",the_miTmp->m_name,the_miTmp->m_ps,the_miTmp->m_size);  
		the_lTotalSize += the_miTmp->m_size;
		free(the_miTmp->m_ps);
		the_miTmp->m_ps = NULL;
		the_miPrev = the_miTmp;
		the_miTmp = the_miTmp->m_next;
		free(the_miPrev);
		the_miPrev = NULL;
	}
	the_miHeader = NULL;
	TraceMem("\n\nTotal size :%ld byte",the_lTotalSize);
#define free NewFree
}

#endif  /* end of _DEBUG */
