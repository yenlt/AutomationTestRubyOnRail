/*
 File:
      similar.h
 Copyright:
      Copyright (C) 2004 TOSHIBA CORPORATION. All Rights Reserved.
 Product:
      AnalyzeMe
 Abstract:
	  �֐��ގ��x�v�����s���B
 Author:
      luo-jirong
 Date:
      2004/08/17
 REVISION HISTORY:
      2004/08/17        luo-jirong     1st Revision
*/

/*
    $AnalyzeMe 1.0.0.1$
*/

#ifndef SIMILAR_H
#define SIMILAR_H

#include "analyzeme_type.h"

int MeasureSimFunc(const ST_AnalyzeMe * in_panzInfo);

#endif /* end of SIMILAR_H */
