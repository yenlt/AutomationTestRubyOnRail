/*
 File:
      preprocess1.h
 Copyright:
      Copyright (C) 2004 TOSHIBA CORPORATION. All Rights Reserved.
 Product:
      AnalyzeMe
 Abstract:
      �O����(1)�̊֐���錾����
 Author:
      tong-huixin
 Date:
      2004/08/20
 REVISION HISTORY:

*/

/*
    $AnalyzeMe 1.0.0.0$
*/

#ifndef PROC_MACRO_H
#define PROC_MACRO_H

#include "analyzeme_type.h"

int proc_macro(ST_AnalyzeMe *io_pAnzInfo,ST_MeasureFile *in_pFileInfo,
					ST_ProcMacro **io_procMacroNode,const int in_iVerFlag);

#endif  /* end for ifndef PROC_MACRO_H */
