/*
 File:
     memory_manage.h
 Copyright:
      Copyright (C) 2004 TOSHIBA CORPORATION. All Rights Reserved.
 Product:
      AnalyzeMe
 Abstract:
      ���ʂ̕ϐ��A�֐��̐錾�A���ʂ̃}�N�����`����
 Author:
      luo-jirong
 Date:
      2004/08/13
 REVISION HISTORY:

*/

/*
    $AnalyzeMe 1.0.0.1$
*/

#ifndef MEMORY_MANAGE_H
#define MEMORY_MANAGE_H

#ifndef _DEBUG /* Release */

#define AnzMalloc(name,type,size) 	name = (type)malloc(size)	

#endif	/* end of Release */

#ifdef _DEBUG

#include <stdio.h>
#include <malloc.h>
#include <memory.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include "analyzeme_type.h"

#define GFILLVALUE 0xA3			/* �������������̒l */
#define size_t unsigned int

#define malloc		33_Err_DontUseMalloc
#define free		NewFree
#define realloc		33_Err_DontUseRealloc
#define calloc		33_Err_DontUseCalloc

#define NewFree(block)   NewFreeMem(block,#block)

#define AnzMalloc(name,type,size)		name = (type)RecordMalloc(size,#name)

struct _ST_MemoryInfo
{
	struct			_ST_MemoryInfo *m_next;	 /* ��Node */
	void			* m_ps;					 /* �m�ۂ�����������Head�A�h���X */
	char			m_name[30];				 /* Name */
	unsigned long	m_size;					 /* �m�ۂ����������̃T�C�Y */
};
typedef struct _ST_MemoryInfo ST_MemoryInfo;

void InitMemMan();
void DestoryMemMan();
static void TraceMem(const char *in_fmt,...);
void *RecordMalloc(long in_size,char *in_name);
void NewFreeMem(void *in_memblock,char *in_pStr);
void CheckAllMem();


#endif  /* end of _Debug */


#endif  /* end of ifndef MEMORY_MANAGE_H */
